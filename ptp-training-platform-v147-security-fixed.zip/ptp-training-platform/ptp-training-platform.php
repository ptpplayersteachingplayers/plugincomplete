<?php
/**
 * Plugin Name: PTP Training Platform
 * Plugin URI: https://ptpsummercamps.com
 * Description: Complete soccer training platform - camps, 1-on-1 training marketplace, and membership packages. Connects families with elite NCAA and professional trainers. Features booking funnel, sibling/team discounts, referral system, and Stripe Connect payouts.
 * Version: 147.0.0
 * Author: PTP Soccer Camps
 * Author URI: https://ptpsummercamps.com
 * Text Domain: ptp-training
 * Requires at least: 6.0
 * Requires PHP: 8.2
 */

defined('ABSPATH') || exit;

// Plugin constants
define("PTP_VERSION", "147.0.0");
define('PTP_V71_VERSION', '71.0.0');
define('PTP_V72_VERSION', '72.0.0');
define('PTP_V73_VERSION', '73.0.0');
define('PTP_V81_VERSION', '81.0.0');
define('PTP_PLUGIN_FILE', __FILE__);
define('PTP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('PTP_PLUGIN_PATH', plugin_dir_path(__FILE__)); // Alias for templates
define('PTP_PLUGIN_URL', plugin_dir_url(__FILE__));
define('PTP_PLUGIN_BASENAME', plugin_basename(__FILE__));

// v130.3: Platform fee now configurable via admin (PTP Settings > General)
// Fallback to 20% if not set - use ptp_get_platform_fee() function instead of constant
define('PTP_PLATFORM_FEE_PERCENT_DEFAULT', 0.20);

/**
 * Get platform fee as decimal (e.g., 0.20 for 20%)
 * Uses wp_options for admin configurability
 */
function ptp_get_platform_fee() {
    $fee_percent = get_option('ptp_platform_fee', 20);
    return floatval($fee_percent) / 100;
}

/**
 * Get platform fee as percentage (e.g., 20 for 20%)
 */
function ptp_get_platform_fee_percent() {
    return floatval(get_option('ptp_platform_fee', 20));
}

/**
 * Main Plugin Class
 */
final class PTP_Training_Platform {
    
    private static $instance = null;
    
    public static function instance() {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->includes();
        $this->init_hooks();
    }
    
    private function includes() {
        // Core classes
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-database.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-images.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-image-optimizer.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-user.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-trainer.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-trainer-profile.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-parent.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-player.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-booking.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-availability.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-reviews.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-payments.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-trainer-payouts.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-notifications.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-ajax.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-shortcodes.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-templates.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-performance.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-mobile-optimization.php';
        require_once PTP_PLUGIN_DIR . 'includes/ptp-elementor-header-fix.php';
        
        // Header component v88
        require_once PTP_PLUGIN_DIR . 'templates/components/ptp-header.php';
        
        // Integration classes
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-email.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-email-templates.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-stripe.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-escrow.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-session-confirmation.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-seo.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-seo-locations.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-seo-sitemap.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-seo-content.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-seo-titles.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-social.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-push-notifications.php';
        // v126: Enhanced schedule calendar (v2 only)
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-schedule-calendar-v2.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-geocoding.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-maps.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-cron.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-onboarding-reminders.php'; // v133: Trainer onboarding reminders
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-camps-bridge.php'; // v146: PTP Camps integration
        
        // v145: WooCommerce classes - only load if WC is active
        if (class_exists('WooCommerce')) {
            require_once PTP_PLUGIN_DIR . 'includes/class-ptp-woocommerce.php';
            require_once PTP_PLUGIN_DIR . 'includes/class-ptp-woocommerce-camps.php';
        }
        
        // v146: WooCommerce-Free Camp System - Stripe-direct checkout
        // This loads regardless of WooCommerce status
        require_once PTP_PLUGIN_DIR . 'includes/ptp-camp-system-loader.php';
        
        // Advanced features
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-recurring.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-groups.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-calendar-sync.php';
        // require_once PTP_PLUGIN_DIR . 'includes/class-ptp-calendar-enhancements.php'; // Disabled - needs testing
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-training-plans.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-tax-reporting.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-rest-api.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-faq.php';
        
        // New features v45
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-happy-score.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-gift-cards.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-subscriptions.php';
        
        // v88: Referral system
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-referral-system.php';
        
        // v48: TeachMe.to-style booking wizard
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-booking-wizard.php';
        
        // v122: Critical booking/email fix - schema mismatch
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-booking-fix-v122.php';
        
        // Mobile App API classes (Supabase handles mobile - see ptp-app-sync plugin)
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-app-config.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-social-login.php';
        // require_once PTP_PLUGIN_DIR . 'includes/class-ptp-google-web-login.php'; // v128: Disabled - causing critical errors
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-camps-api.php';
        // REMOVED: class-ptp-mobile-api.php - Mobile uses Supabase directly
        
        // Admin class
        require_once PTP_PLUGIN_DIR . 'admin/class-ptp-admin.php';
        require_once PTP_PLUGIN_DIR . 'admin/class-ptp-admin-ajax.php';
        require_once PTP_PLUGIN_DIR . 'admin/class-ptp-app-control.php';
        require_once PTP_PLUGIN_DIR . 'admin/class-ptp-admin-tools-v72.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-admin-payouts-v2.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-admin-payouts-v3.php';
        require_once PTP_PLUGIN_DIR . 'admin/stripe-diagnostic.php';
        require_once PTP_PLUGIN_DIR . 'admin/class-ptp-analytics-dashboard.php';
        
        // v88: PWA Support
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-pwa.php';
        
        // v50: Enhanced profile components
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-photo-upload.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-quick-profile-editor.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-camps-crosssell.php';
        
        // v52: Analytics, Email Automation & Conversion Optimization
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-analytics.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-email-automation.php';
        // require_once PTP_PLUGIN_DIR . 'includes/class-ptp-popups.php'; // v126: Disabled - exit intent popup removed
        
        // v53: Growth Engine - Trainer Referrals, Pixels, Upsells, Reviews
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-trainer-referrals.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-pixels.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-growth.php';
        // require_once PTP_PLUGIN_DIR . 'includes/class-ptp-google-reviews.php'; // Disabled - needs testing
        
        // v56: Salesmsg AI Integration for SMS Booking (optional - disabled by default)
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-salesmsg-api.php';
        
        // v57: Cross-Sell Engine, Viral Sharing, and Instant Pay
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-crosssell-engine.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-viral-engine.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-instant-pay.php';
        
        // v116: Viral Enhancements - Share prompts, review+share flow, trainer share buttons, SMS share links
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-viral-enhancements.php';
        
        // v133: NEW Clean Training Thank You Handler - simple, bulletproof
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-training-thankyou.php';
        
        // v100/v133: Old Thank You loaders - DISABLED, replaced by class-ptp-training-thankyou
        // require_once PTP_PLUGIN_DIR . 'includes/ptp-thankyou-v100-loader.php';
        // require_once PTP_PLUGIN_DIR . 'includes/class-ptp-thankyou-handler.php';
        
        // v121: Booking Fix - emails, parent linking, thank you page
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-booking-fix-v121.php';
        
        // v57.1: Supabase Bridge for mobile app
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-supabase-bridge.php';
        
        // v58: Checkout UX Improvements
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-checkout-ux.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-packages-display.php';
        
        // v59: Flow Engine - centralized conversion tracking
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-flow-engine.php';
        
        // v59.3: Quality Control System - trainer accountability
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-quality-control.php';
        
        // v59.3: Trainer Loyalty System - keep trainers on platform
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-trainer-loyalty.php';
        
        // v59.4: Unified Bundle Checkout - consolidated training + camps checkout
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-bundle-checkout.php';
        
        // v145: WooCommerce-dependent v60 classes
        if (class_exists('WooCommerce')) {
            // v59.5: Camp Cross-Sell Everywhere - camps visible at every touchpoint
            require_once PTP_PLUGIN_DIR . 'includes/class-ptp-camp-crosssell-everywhere.php';
            
            // v60.1: Unified Cart - combined WooCommerce + PTP training cart widget
            require_once PTP_PLUGIN_DIR . 'includes/class-ptp-unified-cart.php';
            
            // v60.2: WooCommerce Cart Enhancement - professional training upsell in WC cart
            require_once PTP_PLUGIN_DIR . 'includes/class-ptp-woocommerce-cart-enhancement.php';
            
            // v60.2: Unified Checkout Handler - custom cart/checkout with debug logging
            require_once PTP_PLUGIN_DIR . 'includes/class-ptp-unified-checkout-handler.php';
            require_once PTP_PLUGIN_DIR . 'includes/class-ptp-unified-checkout.php';
        }
        
        // v60.3: Cart Helper - centralized cart state, nonces, and discount calculation
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-cart-helper.php';
        
        // v60.5: Checkout Diagnostic Tool (admin only)
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-checkout-diagnostic.php';
        
        // v60.2: N8N Integration Endpoints - REST API for workflow automation
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-n8n-endpoints.php';
        
        // v71: Enhanced Features - SMS, Messaging, Calendar, Stripe Connect, SPA Dashboards
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-availability-v71.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-sms.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-messaging.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-google-calendar-v71.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-stripe-connect-v71.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-ajax-v71.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-spa-dashboard.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-order-integration-v71.php';
        
        // v145: WooCommerce-dependent v71 classes
        if (class_exists('WooCommerce')) {
            require_once PTP_PLUGIN_DIR . 'includes/class-ptp-cart-checkout-v71.php';
            require_once PTP_PLUGIN_DIR . 'includes/class-ptp-woocommerce-orders-v71.php';
            
            // v85: WooCommerce Email Integration
            require_once PTP_PLUGIN_DIR . 'includes/class-ptp-woocommerce-emails.php';
            
            // v115: Order Email Wiring
            require_once PTP_PLUGIN_DIR . 'includes/class-ptp-order-email-wiring.php';
            
            // v116: Training WooCommerce Integration
            require_once PTP_PLUGIN_DIR . 'includes/class-ptp-training-woo-integration.php';
            
            // v116: Unified Order Email
            require_once PTP_PLUGIN_DIR . 'includes/class-ptp-unified-order-email.php';
            
            // v99: Mobile-first checkout with upsells
            require_once PTP_PLUGIN_DIR . 'includes/class-ptp-camp-checkout-v99.php';
        }
        
        // Camp Product Template v10.3.5 - Loads automatically for camp/clinic products
        // Disable by adding: define('PTP_DISABLE_CAMP_TEMPLATE', true); to wp-config.php
        // Or use Code Snippets method instead (upload PHP/CSS to /uploads/)
        if (!defined('PTP_DISABLE_CAMP_TEMPLATE') || !PTP_DISABLE_CAMP_TEMPLATE) {
            if (file_exists(PTP_PLUGIN_DIR . 'templates/camp/ptp-camp-product-v10.3.5.php')) {
                require_once PTP_PLUGIN_DIR . 'templates/camp/ptp-camp-product-v10.3.5.php';
            }
        }
        
        // v86: Page creator tool for recreating all PTP pages
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-page-creator.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-admin-settings-v71.php';
        
        // v72: Comprehensive Fixes
        // - 10.1: Auto-repair missing table columns
        // - 10.2: Nonce refresh system for idle pages
        // - 10.3: Stripe Connect onboarding reminders
        // - 10.4: Template version consolidation
        // - 10.5: Autoloader for large class files
        // - 10.6: Cache exclusion for dynamic pages
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-autoloader.php';
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-fixes-v72.php';
        
        // v129: Comprehensive fixes
        // - Map shows training locations (not home locations)
        // - SMS wired for booking confirmation, reminder, post-training follow-up
        // - Parent dashboard name display improvements
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-fixes-v129.php';
        
        // v77: Bulletproof Checkout - Complete payment flow rewrite
        // - Single source of truth for payment handling
        // - Proper Payment Intent flow with 3D Secure support
        // - Unified nonce handling
        // - Comprehensive error logging
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-checkout-v77.php';
        
        // v94: All-Access Pass Membership System
        // - Tiered memberships with value-stack pricing (Starter/All-Access/Elite)
        // - Credits system for camps, private training, clinics
        // - Individual service purchases (Video Analysis, Mentorship)
        // - Composite pricing psychology for anchor-based value perception
        // - Stripe Checkout integration with subscriptions
        require_once PTP_PLUGIN_DIR . 'includes/class-ptp-all-access-pass.php';
        // REMOVED v100: Camp pack upsell popup disabled
        // require_once PTP_PLUGIN_DIR . 'includes/class-ptp-camp-pack-upsell.php';

    }
    
    private function init_hooks() {
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        // SECURITY: Add security headers to all responses
        add_action('send_headers', array($this, 'add_security_headers'));
        
        add_action('init', array($this, 'init'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_enqueue_scripts', array($this, 'dequeue_theme_on_ptp_pages'), 999);
        add_action('admin_enqueue_scripts', array($this, 'admin_scripts'));
        
        // Handle simple trainer application form (no account creation - admin review first)
        add_action('admin_post_nopriv_ptp_trainer_apply', array($this, 'handle_simple_application'));
        add_action('admin_post_ptp_trainer_apply', array($this, 'handle_simple_application'));
        
        // AJAX handler for trainer application (new clean version)
        add_action('wp_ajax_ptp_submit_application', array($this, 'ajax_submit_application'));
        add_action('wp_ajax_nopriv_ptp_submit_application', array($this, 'ajax_submit_application'));
        
        // New coach application handler (avoids conflict with class-ptp-ajax.php)
        add_action('wp_ajax_ptp_coach_application', array($this, 'ajax_coach_application'));
        add_action('wp_ajax_nopriv_ptp_coach_application', array($this, 'ajax_coach_application'));
        
        // Early hook to catch /apply/ POST before WordPress returns 404
        add_action('parse_request', array($this, 'intercept_apply_post'), 1);
        
        // v130.3: Early hook to catch /signout/ and /sign-out/ URLs
        add_action('parse_request', array($this, 'intercept_signout'), 1);
        
        // Intercept login/register pages to show full-page templates - run early (priority 1)
        add_action('template_redirect', array($this, 'maybe_override_template'), 1);
        
        // v145: WooCommerce login redirect - only if WC is active
        if (class_exists('WooCommerce')) {
            add_filter('woocommerce_login_redirect', array($this, 'woo_login_redirect'), 99, 2);
            add_filter('woocommerce_registration_redirect', array($this, 'woo_login_redirect'), 99, 2);
        }
        
        // Handle WordPress login failures - redirect back to custom login page
        add_action('wp_login_failed', array($this, 'handle_login_failure'));
        add_filter('login_redirect', array($this, 'custom_login_redirect'), 99, 3);
        
        // Always instantiate admin
        PTP_Admin::instance();
        
        // Initialize v57 growth engines
        PTP_Crosssell_Engine::instance();
        PTP_Viral_Engine::instance();
        PTP_Instant_Pay::instance();
        
        // v145: WooCommerce-dependent class instantiations
        if (class_exists('WooCommerce')) {
            // Initialize v59.5 camp cross-sell everywhere
            if (class_exists('PTP_Camp_Crosssell_Everywhere')) {
                PTP_Camp_Crosssell_Everywhere::instance();
            }
            
            // Initialize v60.1 unified cart
            if (class_exists('PTP_Unified_Cart')) {
                PTP_Unified_Cart::instance();
            }
            
            // Initialize v71 cart/checkout
            if (class_exists('PTP_Cart_Checkout_V71')) {
                PTP_Cart_Checkout_V71::instance();
            }
        }
        
        // Initialize v71 enhanced features (WooCommerce-independent)
        PTP_Availability_V71::init();
        PTP_SMS_V71::init();
        PTP_Messaging_V71::init();
        PTP_Admin_Payouts_V3::init();
        
        // Classes with instance() singleton pattern
        PTP_Google_Calendar_V71::instance();
        PTP_Stripe_Connect_V71::instance();
        PTP_SPA_Dashboard::instance();
        PTP_Admin_Settings_V71::instance();
        
        // Classes with constructor
        new PTP_Ajax_V71();
        
        // v86: Page Creator admin tool
        new PTP_Page_Creator();

        // Add admin notice to confirm plugin is loaded
        add_action('admin_notices', array($this, 'check_plugin_status'));
    }
    
    /**
     * Intercept /apply/ POST requests early before WordPress returns 404
     */
    public function intercept_apply_post($wp) {
        // Check if this is a POST to /apply/
        $request_uri = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?? '', '/');
        
        if ($request_uri === 'apply' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            // Load the apply template directly - it handles the POST
            include PTP_PLUGIN_DIR . 'templates/apply.php';
            exit;
        }
    }
    
    /**
     * v130.3: Intercept /signout/ and /sign-out/ URLs
     * Redirects to /logout/ page or processes logout directly
     */
    public function intercept_signout($wp) {
        $request_uri = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?? '', '/');
        
        // Match signout, sign-out, or signout/ 
        if (in_array($request_uri, array('signout', 'sign-out'))) {
            // If user is logged in, redirect to logout confirmation
            if (is_user_logged_in()) {
                wp_redirect(home_url('/logout/'));
            } else {
                // Already logged out, go to login
                wp_redirect(home_url('/login/?logged_out=1'));
            }
            exit;
        }
    }
    
    /**
     * Handle simple trainer application (no account creation - for admin review)
     * This is called via admin-post.php from the simple apply form
     */
    public function handle_simple_application() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['ptp_apply_nonce'] ?? '', 'ptp_trainer_apply')) {
            wp_send_json_error(array('message' => 'Security check failed'));
            exit;
        }
        
        global $wpdb;
        
        // Auto-create applications table if needed
        $table = $wpdb->prefix . 'ptp_applications';
        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") !== $table) {
            PTP_Database::create_tables();
        }
        
        // Build data
        $first_name = sanitize_text_field($_POST['first_name'] ?? '');
        $last_name = sanitize_text_field($_POST['last_name'] ?? '');
        $full_name = trim($first_name . ' ' . $last_name);
        
        $city = sanitize_text_field($_POST['city'] ?? '');
        $state = sanitize_text_field($_POST['state'] ?? '');
        $location = trim($city . ', ' . $state, ', ');
        
        $email = sanitize_email($_POST['email'] ?? '');
        
        if (empty($full_name) || empty($email)) {
            wp_send_json_error(array('message' => 'Name and email are required'));
            exit;
        }
        
        // Check if already applied
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$table} WHERE email = %s", 
            $email
        ));
        
        if ($existing) {
            wp_send_json_success(array('message' => 'Application already received!'));
            exit;
        }
        
        // Insert application
        $data = array(
            'name' => $full_name,
            'email' => $email,
            'phone' => sanitize_text_field($_POST['phone'] ?? ''),
            'location' => $location,
            'playing_level' => sanitize_text_field($_POST['playing_level'] ?? ''),
            'bio' => sanitize_textarea_field($_POST['bio'] ?? ''),
            'status' => 'pending',
            'created_at' => current_time('mysql')
        );
        
        $result = $wpdb->insert($table, $data);
        
        if ($result === false) {
            error_log('PTP Application Error: ' . $wpdb->last_error);
            wp_send_json_error(array('message' => 'Error saving application'));
            exit;
        }
        
        // Send confirmation email
        if (class_exists('PTP_Email')) {
            PTP_Email::send_application_received($email, $full_name);
        }
        
        // Notify admin
        wp_mail(
            get_option('admin_email'),
            'New Trainer Application - ' . $full_name,
            sprintf(
                "New trainer application received:\n\nName: %s\nEmail: %s\nPhone: %s\nLocation: %s\nPlaying Level: %s\n\nReview: %s",
                $full_name, $email, $data['phone'], $location, $data['playing_level'],
                admin_url('admin.php?page=ptp-applications')
            )
        );
        
        wp_send_json_success(array('message' => 'Application submitted successfully!'));
        exit;
    }
    
    /**
     * AJAX handler for trainer application
     */
    public function ajax_submit_application() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['ptp_apply_nonce'] ?? '', 'ptp_submit_application')) {
            wp_send_json_error(array('message' => 'Security check failed. Please refresh and try again.'));
            return;
        }
        
        global $wpdb;
        
        // Auto-create applications table if needed
        $table = $wpdb->prefix . 'ptp_applications';
        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") !== $table) {
            if (class_exists('PTP_Database')) {
                PTP_Database::create_tables();
            } else {
                // Create table manually
                $charset = $wpdb->get_charset_collate();
                $sql = "CREATE TABLE IF NOT EXISTS $table (
                    id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                    name varchar(255) NOT NULL,
                    email varchar(255) NOT NULL,
                    phone varchar(50) DEFAULT '',
                    location varchar(255) DEFAULT '',
                    playing_level varchar(100) DEFAULT '',
                    current_team varchar(255) DEFAULT '',
                    bio text,
                    status varchar(50) DEFAULT 'pending',
                    created_at datetime DEFAULT CURRENT_TIMESTAMP,
                    reviewed_at datetime DEFAULT NULL,
                    reviewed_by bigint(20) unsigned DEFAULT NULL,
                    notes text,
                    PRIMARY KEY (id),
                    KEY email (email),
                    KEY status (status)
                ) $charset;";
                require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
                dbDelta($sql);
            }
        }
        
        // Build data
        $first_name = sanitize_text_field($_POST['first_name'] ?? '');
        $last_name = sanitize_text_field($_POST['last_name'] ?? '');
        $full_name = trim($first_name . ' ' . $last_name);
        
        $city = sanitize_text_field($_POST['city'] ?? '');
        $state = sanitize_text_field($_POST['state'] ?? '');
        $location = trim($city . ', ' . $state, ', ');
        
        $email = sanitize_email($_POST['email'] ?? '');
        $phone = sanitize_text_field($_POST['phone'] ?? '');
        
        // Validate required fields
        if (empty($first_name)) {
            wp_send_json_error(array('message' => 'First name is required.'));
            return;
        }
        if (empty($last_name)) {
            wp_send_json_error(array('message' => 'Last name is required.'));
            return;
        }
        if (empty($email) || !is_email($email)) {
            wp_send_json_error(array('message' => 'Valid email is required.'));
            return;
        }
        if (empty($phone)) {
            wp_send_json_error(array('message' => 'Phone number is required.'));
            return;
        }
        if (empty($_POST['playing_level'])) {
            wp_send_json_error(array('message' => 'Playing level is required.'));
            return;
        }
        if (empty($city) || empty($state)) {
            wp_send_json_error(array('message' => 'City and state are required.'));
            return;
        }
        
        // Check if already applied
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$table} WHERE email = %s", 
            $email
        ));
        
        if ($existing) {
            wp_send_json_error(array('message' => 'An application with this email already exists. We\'ll be in touch soon!'));
            return;
        }
        
        // Insert application
        $data = array(
            'name' => $full_name,
            'email' => $email,
            'phone' => $phone,
            'location' => $location,
            'playing_level' => sanitize_text_field($_POST['playing_level'] ?? ''),
            'current_team' => sanitize_text_field($_POST['current_team'] ?? ''),
            'bio' => sanitize_textarea_field($_POST['bio'] ?? ''),
            'status' => 'pending',
            'created_at' => current_time('mysql')
        );
        
        $result = $wpdb->insert($table, $data);
        
        if ($result === false) {
            error_log('PTP Application Error: ' . $wpdb->last_error);
            wp_send_json_error(array('message' => 'Error saving application. Please try again.'));
            return;
        }
        
        $application_id = $wpdb->insert_id;
        
        // Send confirmation email to applicant
        $site_name = get_bloginfo('name');
        $applicant_subject = 'Application Received - ' . $site_name;
        $applicant_body = "Hi {$first_name},\n\n";
        $applicant_body .= "Thanks for applying to become a PTP Coach! We've received your application and will review it within 24-48 hours.\n\n";
        $applicant_body .= "What happens next:\n";
        $applicant_body .= "1. We'll review your playing background\n";
        $applicant_body .= "2. If approved, you'll receive an email with login credentials\n";
        $applicant_body .= "3. Complete your profile at " . home_url('/trainer-onboarding/') . "\n";
        $applicant_body .= "4. Start getting booked!\n\n";
        $applicant_body .= "If you have any questions, just reply to this email.\n\n";
        $applicant_body .= "— The PTP Team\n";
        $applicant_body .= home_url();
        
        wp_mail($email, $applicant_subject, $applicant_body);
        
        // Send notification to admin
        $admin_email = get_option('admin_email');
        $admin_subject = '🆕 New Trainer Application - ' . $full_name;
        $admin_body = "New trainer application received!\n\n";
        $admin_body .= "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
        $admin_body .= "Name: {$full_name}\n";
        $admin_body .= "Email: {$email}\n";
        $admin_body .= "Phone: {$phone}\n";
        $admin_body .= "Location: {$location}\n";
        $admin_body .= "Playing Level: {$data['playing_level']}\n";
        $admin_body .= "Current Team: {$data['current_team']}\n";
        $admin_body .= "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n";
        if (!empty($data['bio'])) {
            $admin_body .= "Bio:\n{$data['bio']}\n\n";
        }
        $admin_body .= "👉 Review & Approve: " . admin_url('admin.php?page=ptp-applications') . "\n";
        
        wp_mail($admin_email, $admin_subject, $admin_body);
        
        // Log success
        error_log("PTP: New trainer application #{$application_id} from {$email}");
        
        wp_send_json_success(array(
            'message' => 'Application submitted successfully!',
            'application_id' => $application_id
        ));
    }
    
    /**
     * New coach application AJAX handler (v118.8)
     * Uses unique action to avoid conflicts with class-ptp-ajax.php
     */
    public function ajax_coach_application() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['ptp_coach_nonce'] ?? '', 'ptp_coach_application')) {
            wp_send_json_error(array('message' => 'Security check failed. Please refresh and try again.'));
            return;
        }
        
        global $wpdb;
        
        // Auto-create applications table if needed
        $table = $wpdb->prefix . 'ptp_applications';
        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") !== $table) {
            if (class_exists('PTP_Database')) {
                PTP_Database::create_tables();
            }
        }
        
        // Build data
        $first_name = sanitize_text_field($_POST['first_name'] ?? '');
        $last_name = sanitize_text_field($_POST['last_name'] ?? '');
        $full_name = trim($first_name . ' ' . $last_name);
        
        $city = sanitize_text_field($_POST['city'] ?? '');
        $state = sanitize_text_field($_POST['state'] ?? '');
        $location = trim($city . ', ' . $state, ', ');
        
        $email = sanitize_email($_POST['email'] ?? '');
        $phone = sanitize_text_field($_POST['phone'] ?? '');
        $password = $_POST['password'] ?? '';
        $password_confirm = $_POST['password_confirm'] ?? '';
        
        // Validate required fields
        if (empty($first_name)) {
            wp_send_json_error(array('message' => 'First name is required.'));
            return;
        }
        if (empty($last_name)) {
            wp_send_json_error(array('message' => 'Last name is required.'));
            return;
        }
        if (empty($email) || !is_email($email)) {
            wp_send_json_error(array('message' => 'Valid email is required.'));
            return;
        }
        if (empty($phone)) {
            wp_send_json_error(array('message' => 'Phone number is required.'));
            return;
        }
        
        // Validate password
        if (empty($password)) {
            wp_send_json_error(array('message' => 'Password is required.'));
            return;
        }
        if (strlen($password) < 8) {
            wp_send_json_error(array('message' => 'Password must be at least 8 characters.'));
            return;
        }
        if ($password !== $password_confirm) {
            wp_send_json_error(array('message' => 'Passwords do not match.'));
            return;
        }
        
        if (empty($_POST['playing_level'])) {
            wp_send_json_error(array('message' => 'Playing level is required.'));
            return;
        }
        if (empty($city) || empty($state)) {
            wp_send_json_error(array('message' => 'City and state are required.'));
            return;
        }
        
        // v124: Validate contract agreement
        if (empty($_POST['agree_contract']) || $_POST['agree_contract'] !== '1') {
            wp_send_json_error(array('message' => 'You must agree to the Trainer Agreement to apply.'));
            return;
        }
        
        // Check if email already exists as WordPress user
        if (email_exists($email)) {
            wp_send_json_error(array('message' => 'An account with this email already exists. Please log in or use a different email.'));
            return;
        }
        
        // Check if already applied
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$table} WHERE email = %s", 
            $email
        ));
        
        if ($existing) {
            wp_send_json_error(array('message' => 'An application with this email already exists. We\'ll be in touch soon!'));
            return;
        }
        
        // Hash the password for storage
        $password_hash = wp_hash_password($password);
        
        // Insert application - use 'team' column (matches database schema)
        $data = array(
            'name' => $full_name,
            'email' => $email,
            'phone' => $phone,
            'password_hash' => $password_hash,
            'location' => $location,
            'playing_level' => sanitize_text_field($_POST['playing_level'] ?? ''),
            'team' => sanitize_text_field($_POST['team'] ?? ''),
            'bio' => sanitize_textarea_field($_POST['bio'] ?? ''),
            'contractor_agreement_signed' => 1,
            'contractor_agreement_signed_at' => current_time('mysql'),
            'contractor_agreement_ip' => sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? ''),
            'status' => 'pending',
            'created_at' => current_time('mysql')
        );
        
        $result = $wpdb->insert($table, $data);
        
        if ($result === false) {
            error_log('PTP Application Error: ' . $wpdb->last_error);
            wp_send_json_error(array('message' => 'Error saving application. Please try again.'));
            return;
        }
        
        $application_id = $wpdb->insert_id;
        
        // Log the contract signing
        error_log(sprintf(
            'PTP Contract Signed (Application): %s (%s) signed agreement at %s from IP %s',
            $full_name,
            $email,
            current_time('mysql'),
            $_SERVER['REMOTE_ADDR'] ?? 'unknown'
        ));
        
        // Log success
        error_log("PTP: New trainer application #{$application_id} from {$email}");
        
        // v134: AUTO-APPROVE - Create WordPress user and trainer record immediately
        $auto_approve = true; // Set to false to require manual approval
        
        if ($auto_approve) {
            // Create WordPress user
            $user_data = array(
                'user_login' => $email,
                'user_email' => $email,
                'user_pass' => $password, // Use the plain password, WP will hash it
                'first_name' => $first_name,
                'last_name' => $last_name,
                'display_name' => $full_name,
                'role' => 'ptp_trainer'
            );
            
            $user_id = wp_insert_user($user_data);
            
            if (is_wp_error($user_id)) {
                // User creation failed, but application was saved - they can still be approved manually
                error_log("PTP: Auto-approve user creation failed for {$email}: " . $user_id->get_error_message());
                
                // Send "pending review" email since auto-approve failed
                $site_name = get_bloginfo('name');
                wp_mail($email, 'Application Received - ' . $site_name, 
                    "Hi {$first_name},\n\nThanks for applying to become a PTP Coach! We've received your application and will review it within 24-48 hours.\n\nIf you have any questions, just reply to this email.\n\n— The PTP Team\n" . home_url()
                );
            } else {
                // User created - now create trainer record
                $trainers_table = $wpdb->prefix . 'ptp_trainers';
                
                // Generate slug
                $slug = sanitize_title($full_name);
                $original_slug = $slug;
                $counter = 1;
                while ($wpdb->get_var($wpdb->prepare("SELECT id FROM {$trainers_table} WHERE slug = %s", $slug))) {
                    $slug = $original_slug . '-' . $counter;
                    $counter++;
                }
                
                // Insert trainer record with status 'pending' (needs to complete onboarding)
                $trainer_data = array(
                    'user_id' => $user_id,
                    'name' => $full_name,
                    'slug' => $slug,
                    'email' => $email,
                    'phone' => $phone,
                    'city' => $city,
                    'state' => $state,
                    'playing_level' => $data['playing_level'],
                    'bio' => $data['bio'],
                    'hourly_rate' => 75, // Default rate
                    'status' => 'pending', // Pending until they complete onboarding
                    'created_at' => current_time('mysql')
                );
                
                $wpdb->insert($trainers_table, $trainer_data);
                $trainer_id = $wpdb->insert_id;
                
                // Update application status
                $wpdb->update($table, array('status' => 'approved'), array('id' => $application_id));
                
                // Save trainer ID to user meta
                update_user_meta($user_id, 'ptp_trainer_id', $trainer_id);
                update_user_meta($user_id, 'ptp_needs_onboarding', 1);
                
                // v134: Send "Welcome - Complete Your Profile" email
                $site_name = get_bloginfo('name');
                $welcome_subject = "Welcome to PTP - Complete Your Profile ⚽";
                $welcome_body = "Hi {$first_name},\n\n";
                $welcome_body .= "Thanks for applying to train with PTP! Your account is ready.\n\n";
                $welcome_body .= "NEXT STEPS:\n";
                $welcome_body .= "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
                $welcome_body .= "1. Complete your profile (photo, bio, availability)\n";
                $welcome_body .= "2. Connect your Stripe account for payouts\n";
                $welcome_body .= "3. Set your hourly rate\n";
                $welcome_body .= "4. Submit for approval\n";
                $welcome_body .= "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n";
                $welcome_body .= "👉 Complete Your Profile Now: " . home_url('/trainer-onboarding/') . "\n\n";
                $welcome_body .= "Once you submit your profile, we'll review it and activate your account (usually within 24 hours). Then you'll appear on our trainer directory and families can start booking you!\n\n";
                $welcome_body .= "HOW IT WORKS:\n";
                $welcome_body .= "• You set your own rate and availability\n";
                $welcome_body .= "• We handle marketing, booking, and payments\n";
                $welcome_body .= "• Earn 50% on first sessions, 75% on repeats\n";
                $welcome_body .= "• Weekly Stripe payouts\n\n";
                $welcome_body .= "Questions? Just reply to this email.\n\n";
                $welcome_body .= "— The PTP Team\n";
                $welcome_body .= home_url();
                
                wp_mail($email, $welcome_subject, $welcome_body);
                
                // v135.9: REMOVED duplicate admin email here
                // Admin will receive ONE email when trainer completes onboarding via PTP_Trainer::complete_onboarding()
                // This prevents email spam during the signup flow
                
                // Auto-login the user
                wp_set_current_user($user_id);
                wp_set_auth_cookie($user_id, true);
                
                error_log("PTP: Auto-approved trainer #{$trainer_id} for user #{$user_id} ({$email})");
                
                wp_send_json_success(array(
                    'message' => 'Application approved!',
                    'application_id' => $application_id,
                    'trainer_id' => $trainer_id,
                    'redirect' => home_url('/trainer-onboarding/')
                ));
                return;
            }
        }
        
        // Manual approval flow - send "pending review" emails
        $site_name = get_bloginfo('name');
        $applicant_subject = 'Application Received - ' . $site_name;
        $applicant_body = "Hi {$first_name},\n\n";
        $applicant_body .= "Thanks for applying to become a PTP Coach! We've received your application and will review it within 24-48 hours.\n\n";
        $applicant_body .= "What happens next:\n";
        $applicant_body .= "1. We'll review your playing background\n";
        $applicant_body .= "2. If approved, you'll receive an email notification\n";
        $applicant_body .= "3. Log in with the password you created\n";
        $applicant_body .= "4. Complete your profile and start getting booked!\n\n";
        $applicant_body .= "If you have any questions, just reply to this email.\n\n";
        $applicant_body .= "— The PTP Team\n";
        $applicant_body .= home_url();
        
        wp_mail($email, $applicant_subject, $applicant_body);
        
        // Send notification to admin
        $admin_email = get_option('admin_email');
        $admin_subject = '🆕 New Trainer Application - ' . $full_name;
        $admin_body = "New trainer application received!\n\n";
        $admin_body .= "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
        $admin_body .= "Name: {$full_name}\n";
        $admin_body .= "Email: {$email}\n";
        $admin_body .= "Phone: {$phone}\n";
        $admin_body .= "Location: {$location}\n";
        $admin_body .= "Playing Level: {$data['playing_level']}\n";
        $admin_body .= "Team: {$data['team']}\n";
        $admin_body .= "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n";
        if (!empty($data['bio'])) {
            $admin_body .= "Bio:\n{$data['bio']}\n\n";
        }
        $admin_body .= "👉 Review & Approve: " . admin_url('admin.php?page=ptp-applications') . "\n";
        
        wp_mail($admin_email, $admin_subject, $admin_body);
        
        wp_send_json_success(array(
            'message' => 'Application submitted successfully!',
            'application_id' => $application_id
        ));
    }
    
    /**
     * Check plugin status and show notice if tables missing
     */
    public function check_plugin_status() {
        // Only show to admins
        if (!current_user_can('manage_options')) {
            return;
        }
        
        // Check if tables exist
        global $wpdb;
        $trainers_table = $wpdb->prefix . 'ptp_trainers';
        $tables_exist = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $trainers_table)) == $trainers_table;
        
        if (!$tables_exist) {
            echo '<div class="notice notice-warning is-dismissible">';
            echo '<p><strong>PTP Training Platform:</strong> Database tables not found. ';
            echo '<a href="' . esc_url(admin_url('admin.php?page=ptp-tools')) . '">Go to Tools</a> to create them, or deactivate and reactivate the plugin.</p>';
            echo '</div>';
        }
        
        // Show error notice on PTP pages if admin class failed
        $page = isset($_GET['page']) ? sanitize_text_field($_GET['page']) : '';
        if (strpos($page, 'ptp') === 0) {
            $admin_loaded = class_exists('PTP_Admin');
            if (!$admin_loaded) {
                echo '<div class="notice notice-error">';
                echo '<p><strong>PTP Training Platform:</strong> Admin class failed to load. Please check for PHP errors.</p>';
                echo '</div>';
            }
        }
    }
    
    /**
     * Override template for login/register pages to show full-page design
     */
    public function maybe_override_template() {
        // Redirect WooCommerce My Account to PTP dashboard
        if (function_exists('is_account_page') && is_account_page()) {
            if (is_user_logged_in()) {
                wp_redirect(PTP_User::get_dashboard_url());
                exit;
            } else {
                wp_redirect(home_url('/login/'));
                exit;
            }
        }
        
        // Also catch /my-account/ by page slug
        if (is_page('my-account')) {
            if (is_user_logged_in()) {
                wp_redirect(PTP_User::get_dashboard_url());
                exit;
            } else {
                wp_redirect(home_url('/login/'));
                exit;
            }
        }
        
        if (is_page('login')) {
            // Redirect logged-in non-admin users to dashboard
            if (is_user_logged_in() && !current_user_can('manage_options')) {
                wp_redirect(PTP_User::get_dashboard_url());
                exit;
            }
            // Load full-page login template
            include PTP_PLUGIN_DIR . 'templates/login.php';
            // Template calls exit, but just in case
            exit;
        }
        
        if (is_page('register')) {
            // Redirect logged-in non-admin users to dashboard
            if (is_user_logged_in() && !current_user_can('manage_options')) {
                wp_redirect(PTP_User::get_dashboard_url());
                exit;
            }
            // Load full-page register template
            include PTP_PLUGIN_DIR . 'templates/register.php';
            // Template calls exit, but just in case
            exit;
        }
        
        // Handle social-login page - Google/Apple OAuth
        if (is_page('social-login')) {
            include PTP_PLUGIN_DIR . 'templates/social-login.php';
            exit;
        }
        
        // Handle apply page - full-page template like login/register
        if (is_page('apply')) {
            // Check if already logged in and already a trainer
            if (is_user_logged_in()) {
                $current_user_id = get_current_user_id();
                $current_user = wp_get_current_user();
                
                // Check if already a trainer
                $trainer = PTP_Trainer::get_by_user_id($current_user_id);
                if ($trainer) {
                    wp_redirect(home_url('/trainer-dashboard/'));
                    exit;
                }
                
                // Check if they have the trainer role (means they already applied)
                if (in_array('ptp_trainer', (array) $current_user->roles)) {
                    wp_redirect(home_url('/trainer-dashboard/'));
                    exit;
                }
            }
            
            // Load full-page apply template (handles form POST processing)
            include PTP_PLUGIN_DIR . 'templates/apply.php';
            exit;
        }
        
        // Handle logout page - full-page template
        if (is_page('logout')) {
            include PTP_PLUGIN_DIR . 'templates/logout.php';
            exit;
        }
        
        // v130.3: Handle signout slug - redirect to logout
        if (is_page('signout') || is_page('sign-out')) {
            wp_redirect(home_url('/logout/'));
            exit;
        }
        
        // Handle trainer-dashboard - full-page template for trainers
        if (is_page('trainer-dashboard')) {
            if (!is_user_logged_in()) {
                wp_redirect(home_url('/login/'));
                exit;
            }
            
            $current_user_id = get_current_user_id();
            $current_user = wp_get_current_user();
            $trainer = PTP_Trainer::get_by_user_id($current_user_id);
            
            // If no trainer found by user_id, try email
            if (!$trainer) {
                global $wpdb;
                $trainer = $wpdb->get_row($wpdb->prepare(
                    "SELECT * FROM {$wpdb->prefix}ptp_trainers WHERE email = %s",
                    $current_user->user_email
                ));
                
                // If found by email, link to user_id
                if ($trainer && (empty($trainer->user_id) || $trainer->user_id == 0)) {
                    $wpdb->update(
                        $wpdb->prefix . 'ptp_trainers',
                        array('user_id' => $current_user_id),
                        array('id' => $trainer->id)
                    );
                    $trainer->user_id = $current_user_id;
                }
            }
            
            // Admin bypass - can view any trainer's dashboard with ?trainer_id=X
            if (!$trainer && current_user_can('manage_options')) {
                if (isset($_GET['trainer_id'])) {
                    $trainer = PTP_Trainer::get(intval($_GET['trainer_id']));
                } else {
                    // Admin with no trainer_id - get first active trainer or any trainer
                    global $wpdb;
                    $trainer = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}ptp_trainers WHERE status = 'active' ORDER BY id DESC LIMIT 1");
                    if (!$trainer) {
                        $trainer = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}ptp_trainers ORDER BY id DESC LIMIT 1");
                    }
                }
            }
            
            if (!$trainer) {
                // No trainer record - check if they have the trainer role (means they applied)
                if (in_array('ptp_trainer', (array) $current_user->roles)) {
                    // They have the role but no trainer record = pending approval
                    include PTP_PLUGIN_DIR . 'templates/trainer-pending.php';
                    exit;
                }
                // No trainer role and no trainer record - redirect to apply
                wp_redirect(home_url('/apply/'));
                exit;
            }
            
            // Ensure trainer has a slug
            if (empty($trainer->slug)) {
                $trainer = PTP_Trainer::ensure_slug($trainer);
            }
            
            // Check if new trainer needs onboarding (skip for admin viewing other trainers)
            $is_own_dashboard = ($trainer->user_id == $current_user_id);
            if ($is_own_dashboard && PTP_Trainer::is_new_trainer($trainer->id) && !isset($_GET['skip_onboarding'])) {
                wp_redirect(home_url('/trainer-onboarding/'));
                exit;
            }
            
            // Safely get data with fallbacks for the template
            $upcoming = array();
            $pending_confirmations = array();
            $earnings = array('this_month' => 0, 'total_earnings' => 0, 'pending_payout' => 0);
            $availability = array();
            $completion = array('percentage' => 100, 'missing' => array());
            
            if (class_exists('PTP_Booking')) {
                if (method_exists('PTP_Booking', 'get_trainer_bookings')) {
                    $upcoming = PTP_Booking::get_trainer_bookings($trainer->id, null, true) ?: array();
                }
                if (method_exists('PTP_Booking', 'get_pending_confirmations')) {
                    $pending_confirmations = PTP_Booking::get_pending_confirmations($trainer->id) ?: array();
                }
            }
            
            if (class_exists('PTP_Payments') && method_exists('PTP_Payments', 'get_trainer_earnings')) {
                $earnings = PTP_Payments::get_trainer_earnings($trainer->id) ?: $earnings;
            }
            
            if (class_exists('PTP_Availability') && method_exists('PTP_Availability', 'get_weekly')) {
                $availability = PTP_Availability::get_weekly($trainer->id) ?: array();
            }
            
            if (method_exists('PTP_Trainer', 'get_profile_completion_status')) {
                $completion = PTP_Trainer::get_profile_completion_status($trainer) ?: $completion;
            }
            
            $show_welcome = isset($_GET['welcome']) && $_GET['welcome'] == '1';
            
            // Load full-page trainer dashboard template (v88 - enhanced mobile)
            include PTP_PLUGIN_DIR . 'templates/trainer-dashboard-v117.php';
            exit;
        }
        
        // Handle account page - user settings
        if (is_page('account')) {
            if (!is_user_logged_in()) {
                wp_redirect(home_url('/login/'));
                exit;
            }
            
            // Load account settings template
            include PTP_PLUGIN_DIR . 'templates/account.php';
            exit;
        }
        
        // Handle parent-dashboard - full-page template for parents
        if (is_page('parent-dashboard') || is_page('my-training')) {
            if (!is_user_logged_in()) {
                wp_redirect(home_url('/login/'));
                exit;
            }
            
            // Load full-page parent dashboard template (v88 - enhanced mobile)
            include PTP_PLUGIN_DIR . 'templates/parent-dashboard-v117.php';
            exit;
        }
    }
    
    /**
     * Override WooCommerce login/registration redirect
     * Send users to proper PTP dashboard instead of my-account
     */
    public function woo_login_redirect($redirect, $user) {
        // Use PTP dashboard redirect logic
        return PTP_User::get_dashboard_url($user->ID);
    }
    
    /**
     * Handle login failures - redirect back to custom login page with error
     */
    public function handle_login_failure($username) {
        $referrer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';
        
        // Only redirect if they came from our custom login page
        if (strpos($referrer, '/login/') !== false || strpos($referrer, 'wp-login.php') !== false) {
            wp_redirect(home_url('/login/?login=failed'));
            exit;
        }
    }
    
    /**
     * Custom login redirect - send to appropriate dashboard
     */
    public function custom_login_redirect($redirect_to, $requested_redirect, $user) {
        // If there's an error, user will be WP_Error
        if (is_wp_error($user)) {
            return $redirect_to;
        }
        
        // If a specific redirect was requested, honor it (unless it's wp-admin for non-admins)
        if (!empty($requested_redirect) && strpos($requested_redirect, 'wp-admin') === false) {
            return $redirect_to;
        }
        
        // Check if user is a trainer or parent and redirect appropriately
        if ($user && isset($user->ID)) {
            $trainer = PTP_Trainer::get_by_user_id($user->ID);
            if ($trainer) {
                return home_url('/trainer-dashboard/');
            }
            return home_url('/parent-dashboard/');
        }
        
        return $redirect_to;
    }
    
    /**
     * SECURITY: Add security headers to all responses
     * Helps prevent XSS, clickjacking, and MIME sniffing attacks
     */
    public function add_security_headers() {
        // Don't add headers in admin or for REST API responses
        if (is_admin() || (defined('REST_REQUEST') && REST_REQUEST)) {
            return;
        }
        
        // Prevent MIME type sniffing
        header('X-Content-Type-Options: nosniff');
        
        // Prevent clickjacking (except for pages that need framing)
        if (!is_page('ptp-checkout') && !is_page('checkout')) {
            header('X-Frame-Options: SAMEORIGIN');
        }
        
        // Enable XSS filter in browsers that support it
        header('X-XSS-Protection: 1; mode=block');
        
        // Referrer policy - send referrer only to same origin
        header('Referrer-Policy: strict-origin-when-cross-origin');
        
        // Permissions policy - restrict sensitive browser features
        header('Permissions-Policy: geolocation=(self), microphone=(), camera=()');
    }
    
    public function init() {
        load_plugin_textdomain('ptp-training', false, dirname(PTP_PLUGIN_BASENAME) . '/languages');
        
        // Quick repair tables if needed (runs once per request, cached)
        if (class_exists('PTP_Database')) {
            PTP_Database::quick_repair();
        }
        
        // Ensure custom roles exist (needed for application approval)
        $this->ensure_roles_exist();
        
        // Auto-create missing pages (check on admin or if critical pages missing)
        $critical_pages_missing = !get_page_by_path('trainer') 
            || !get_page_by_path('ptp-cart') 
            || !get_page_by_path('ptp-checkout')
            || !get_page_by_path('training-checkout');
        
        if (is_admin() || $critical_pages_missing) {
            $this->maybe_create_pages();
        }
        
        // Core functionality
        PTP_Ajax::init();
        PTP_Shortcodes::init();
        PTP_Templates::init();
        PTP_Availability::init(); // CRITICAL: Schedule/availability AJAX handlers
        PTP_Trainer_Payouts::init(); // Stripe Connect payout handlers
        
        // Integrations
        PTP_Email::init();
        // PTP_SMS auto-initializes via plugins_loaded hook
        PTP_Stripe::init();
        PTP_SEO::init();
        PTP_Social::init();
        PTP_Geocoding::init();
        PTP_Cron::init();
        PTP_Onboarding_Reminders::init(); // v133: Trainer onboarding reminders
        PTP_WooCommerce::init();
        PTP_WooCommerce_Emails::instance();
        PTP_Order_Email_Wiring::instance(); // v115: Comprehensive email hooks
        PTP_Unified_Checkout::instance();
        PTP_Social_Announcement::instance(); // v118.2: Instagram announcement opt-in handler
        
        // Hook for sending booking emails asynchronously
        add_action('ptp_send_booking_emails', array('PTP_Ajax', 'do_send_booking_emails'));
        
        // Advanced features
        PTP_Recurring::init();
        PTP_Groups::init();
        PTP_Calendar_Sync::init();
        PTP_Training_Plans::init();
        PTP_Tax_Reporting::init();
        PTP_REST_API::init();
        PTP_Push_Notifications::init();
        // PTP_Schedule_Calendar::init(); // v128: Removed - v1 deleted, v2 self-initializes
        
        // Rewrite rules for trainer profiles
        // Route /trainer/<slug>/ to the trainer page with trainer_slug query var
        add_rewrite_rule('^trainer/([^/]+)/?$', 'index.php?pagename=trainer&trainer_slug=$matches[1]', 'top');
        add_rewrite_tag('%trainer_slug%', '([^&]+)');
        
        // SEO: Rewrite rules for find-trainers location pages
        // Route /find-trainers/<location>/ to find-trainers page with trainer_location query var
        add_rewrite_rule('^find-trainers/([^/]+)/?$', 'index.php?pagename=find-trainers&trainer_location=$matches[1]', 'top');
        add_rewrite_tag('%trainer_location%', '([^&]+)');
        
        // Register query var so WordPress recognizes it
        add_filter('query_vars', array($this, 'add_query_vars'));
        
        // Filter request to properly handle trainer URLs (fallback if rewrite rules don't work)
        add_filter('request', array($this, 'filter_trainer_request'), 1);
        
        // Flush rewrite rules if needed (once per version)
        $flush_version = get_option('ptp_rewrite_flush_version', '0');
        if (version_compare($flush_version, PTP_VERSION, '<')) {
            flush_rewrite_rules();
            update_option('ptp_rewrite_flush_version', PTP_VERSION);
        }
        
        // Redirect old trainer-profile URLs to new format
        add_action('template_redirect', array($this, 'redirect_old_trainer_urls'));
        
        // Redirect /checkout/?trainer_id=... to /training-checkout/
        add_action('template_redirect', array($this, 'redirect_checkout_with_trainer'), 1);
        
        // Aggressive fallback: catch 404s for trainer URLs
        add_action('template_redirect', array($this, 'catch_trainer_404'), 1);
    }
    
    /**
     * Catch 404s for trainer URLs and force correct page load
     * This is the most aggressive fallback if rewrite rules don't work
     */
    public function catch_trainer_404() {
        // Only run if this looks like a 404
        if (!is_404()) {
            return;
        }
        
        $request_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
        $path = trim(parse_url($request_uri, PHP_URL_PATH) ?? '', '/');
        
        // Remove site subdirectory if present
        $home_path = trim(parse_url(home_url(), PHP_URL_PATH) ?? '', '/');
        if ($home_path && strpos($path, $home_path) === 0) {
            $path = trim(substr($path, strlen($home_path)), '/');
        }
        
        // Check if this is a trainer URL
        if (preg_match('#^trainer/([^/]+)/?$#', $path, $matches)) {
            $trainer_slug = sanitize_text_field($matches[1]);
            
            // Skip if this looks like a static file
            if (strpos($trainer_slug, '.') !== false) {
                return;
            }
            
            // Set the query var for the shortcode to use
            set_query_var('trainer_slug', $trainer_slug);
            
            // Ensure trainer page exists
            $trainer_page = get_page_by_path('trainer');
            if (!$trainer_page) {
                wp_insert_post(array(
                    'post_title' => 'Trainer Profile',
                    'post_name' => 'trainer',
                    'post_content' => '[ptp_trainer_profile]',
                    'post_status' => 'publish',
                    'post_type' => 'page',
                ));
                $trainer_page = get_page_by_path('trainer');
            }
            
            if ($trainer_page) {
                // Force WordPress to load the trainer page instead of 404
                global $wp_query, $post;
                
                $wp_query->is_404 = false;
                $wp_query->is_page = true;
                $wp_query->is_singular = true;
                $wp_query->queried_object = $trainer_page;
                $wp_query->queried_object_id = $trainer_page->ID;
                $post = $trainer_page;
                
                // Set up the posts array
                $wp_query->posts = array($trainer_page);
                $wp_query->post_count = 1;
                $wp_query->found_posts = 1;
                
                status_header(200);
                
                // Load the page template
                include(get_page_template());
                exit;
            }
        }
    }
    
    /**
     * Redirect old /trainer-profile/?trainer=slug URLs to /trainer/slug/
     */
    public function redirect_old_trainer_urls() {
        if (is_page('trainer-profile') && !empty($_GET['trainer'])) {
            $trainer_slug = sanitize_text_field($_GET['trainer']);
            wp_redirect(home_url('/trainer/' . $trainer_slug . '/'), 301);
            exit;
        }
    }
    
    /**
     * Redirect /checkout/?trainer_id=X URLs to /training-checkout/
     * This catches old booking links and sends them to the new unified flow
     */
    public function redirect_checkout_with_trainer() {
        // Check if we're on the WooCommerce checkout page with trainer params
        if (!is_page('checkout') && !is_page('woocommerce-checkout')) {
            return;
        }
        
        // If trainer_id is present, redirect to training-checkout
        if (!empty($_GET['trainer_id'])) {
            $params = array();
            if (!empty($_GET['trainer_id'])) $params['trainer_id'] = intval($_GET['trainer_id']);
            if (!empty($_GET['date'])) $params['date'] = sanitize_text_field($_GET['date']);
            if (!empty($_GET['time'])) $params['time'] = sanitize_text_field($_GET['time']);
            if (!empty($_GET['location'])) $params['location'] = sanitize_text_field($_GET['location']);
            if (!empty($_GET['type'])) $params['type'] = sanitize_text_field($_GET['type']);
            if (!empty($_GET['package'])) $params['package'] = sanitize_text_field($_GET['package']);
            
            $redirect_url = add_query_arg($params, home_url('/training-checkout/'));
            wp_redirect($redirect_url, 302);
            exit;
        }
    }
    
    /**
     * Filter request to handle trainer profile URLs
     */
    public function filter_trainer_request($query_vars) {
        // Only intercept if we don't already have the trainer_slug set
        if (!empty($query_vars['trainer_slug'])) {
            return $query_vars;
        }
        
        $request_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
        $path = trim(parse_url($request_uri, PHP_URL_PATH) ?? '', '/');
        
        // Remove site subdirectory if present
        $home_path = trim(parse_url(home_url(), PHP_URL_PATH) ?? '', '/');
        if ($home_path && strpos($path, $home_path) === 0) {
            $path = trim(substr($path, strlen($home_path)), '/');
        }
        
        if (preg_match('#^trainer/([^/]+)/?$#', $path, $matches)) {
            $trainer_slug = sanitize_text_field($matches[1]);
            
            // Skip if this looks like a static file
            if (strpos($trainer_slug, '.') !== false) {
                return $query_vars;
            }
            
            // Ensure the trainer page exists - create it if missing
            $trainer_page = get_page_by_path('trainer');
            if (!$trainer_page) {
                $page_id = wp_insert_post(array(
                    'post_title' => 'Trainer Profile',
                    'post_name' => 'trainer',
                    'post_content' => '[ptp_trainer_profile]',
                    'post_status' => 'publish',
                    'post_type' => 'page',
                ));
                
                if ($page_id && !is_wp_error($page_id)) {
                    // Flush rewrite rules after creating the page
                    flush_rewrite_rules();
                }
            }
            
            // Set up query vars to load the trainer page
            $query_vars['pagename'] = 'trainer';
            $query_vars['trainer_slug'] = $trainer_slug;
            
            // Remove any 404 indicators
            unset($query_vars['error']);
            unset($query_vars['name']); // Important: prevent 404 by removing post name lookup
        }
        
        return $query_vars;
    }
    
    /**
     * Add custom query vars
     */
    public function add_query_vars($vars) {
        $vars[] = 'trainer_slug';
        $vars[] = 'trainer_location'; // SEO location pages
        return $vars;
    }
    
    /**
     * Ensure custom roles exist (runs on every init to catch any missing roles)
     */
    private function ensure_roles_exist() {
        if (!get_role('ptp_trainer')) {
            add_role('ptp_trainer', 'PTP Trainer', array(
                'read' => true,
                'upload_files' => true,
            ));
        }
        
        if (!get_role('ptp_parent')) {
            add_role('ptp_parent', 'PTP Parent', array(
                'read' => true,
            ));
        }
    }
    
    public function enqueue_scripts() {
        // v134: UNIVERSAL SCROLL FIX - Add inline CSS/JS to fix scroll blocking on all pages
        add_action('wp_head', function() {
            echo '<style id="ptp-universal-scroll-fix-v135">
/* PTP Universal Scroll Fix v135.2 - Prevents scroll blocking */
/* DESKTOP SPECIFIC - Must allow scrolling */
@media screen and (min-width: 1025px) {
    html, html.no-scroll, html.modal-open, html.menu-open, html.overflow-hidden,
    html[style*="overflow: hidden"], html[style*="overflow:hidden"] {
        overflow-y: scroll !important;
        overflow-x: hidden !important;
        height: auto !important;
        position: static !important;
    }
    body, body.no-scroll, body.modal-open, body.menu-open, body.overflow-hidden,
    body[style*="overflow: hidden"], body[style*="overflow:hidden"],
    body[style*="position: fixed"], body[style*="position:fixed"] {
        overflow-y: auto !important;
        overflow-x: hidden !important;
        height: auto !important;
        min-height: 100vh !important;
        position: static !important;
        top: auto !important;
        width: 100% !important;
    }
}
/* ALL SCREENS - Base scroll fix */
html, body {
    scroll-behavior: auto !important;
}
/* Fix common theme wrappers */
#page, .site-content, .ast-container, .flavor-wrapper, #flavor-wrapper,
.entry-content, .page-content, main, article {
    overflow: visible !important;
    height: auto !important;
    position: static !important;
}
/* Fix Elementor containers */
.elementor-section-wrap, .elementor-section, .elementor-container {
    overflow: visible !important;
}
/* Ensure PTP templates can scroll */
.ptp-page, .ptp-template {
    overflow: visible !important;
}
/* Remove any stuck transforms that prevent scroll */
body:not(.ptp-modal-open) {
    transform: none !important;
}
</style>';
            // JS to remove blocking classes immediately - desktop focus
            echo '<script>
(function(){
    var b=document.body,h=document.documentElement,d=window.innerWidth>=1025;
    if(d){
        h.style.cssText+="overflow-y:scroll!important;overflow-x:hidden!important;height:auto!important;position:static!important;";
        if(b){b.style.cssText+="overflow-y:auto!important;overflow-x:hidden!important;height:auto!important;position:static!important;";}
    }
    if(b){b.classList.remove("menu-open","modal-open","no-scroll","overflow-hidden");b.style.overflow="";b.style.position="";}
    if(h){h.style.overflow="";h.style.overflowY=d?"scroll":"auto";}
})();
</script>';
        }, 1);
        
        // v135.2: Also add to wp_footer for late-loading issues - desktop focused
        add_action('wp_footer', function() {
            echo '<script>
(function(){
    var b=document.body,h=document.documentElement,d=window.innerWidth>=1025;
    function fix(){
        if(!document.querySelector(".ptp-modal-overlay.open,.modal.show")){
            b.classList.remove("menu-open","modal-open","no-scroll","overflow-hidden");
            if(d){
                h.style.overflowY="scroll";
                h.style.position="static";
                h.style.height="auto";
                b.style.overflowY="auto";
                b.style.position="static";
                b.style.height="auto";
                b.style.top="auto";
            }
            b.style.overflow="";
        }
    }
    fix();
    setTimeout(fix,100);
    setTimeout(fix,500);
    setTimeout(fix,1000);
    setTimeout(fix,2000);
    window.addEventListener("load",function(){fix();setTimeout(fix,500);setTimeout(fix,1500);});
    // v135.2: Continuous desktop check
    if(d){setInterval(function(){if(!document.querySelector(".ptp-modal-overlay.open")){fix();}},3000);}
})();
</script>';
        }, 999);
        
        // v91: Skip PTP styling on WooCommerce pages to prevent conflicts
        $is_woocommerce_page = false;
        if (function_exists('is_woocommerce')) {
            $is_woocommerce_page = is_woocommerce() || is_cart() || is_checkout() || is_account_page();
        }
        // Also check by page slug for WC pages
        if (is_page(array('shop', 'cart', 'checkout', 'my-account', 'order-received'))) {
            $is_woocommerce_page = true;
        }
        // Check if it's a product page
        if (is_singular('product')) {
            $is_woocommerce_page = true;
        }
        
        // Override: Load PTP styles on our custom PTP pages even if WC is active
        $is_ptp_page = is_page(array(
            'ptp-cart', 'ptp-checkout', 'training', 'trainers', 'trainer-dashboard', 
            'parent-dashboard', 'my-training', 'messages', 'login', 'register',
            'apply', 'coach-application', 'trainer-onboarding', 'account'
        ));
        // Also check for PTP trainer profile pages
        if (isset($_GET['trainer_id']) || strpos($_SERVER['REQUEST_URI'], '/training/') !== false) {
            $is_ptp_page = true;
        }
        
        // v91: Only load full PTP CSS on PTP pages, not WooCommerce
        if (!$is_woocommerce_page || $is_ptp_page) {
            // v133: Scroll fix - MUST LOAD FIRST IN HEAD to fix scroll blocking
            wp_enqueue_script('ptp-scroll-fix-v133', PTP_PLUGIN_URL . 'assets/js/ptp-scroll-fix-v133.js', array(), PTP_VERSION, false); // false = load in head
            
            // Use Inter as the default UI font to match PTP site styling.
            wp_enqueue_style('ptp-google-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=Oswald:wght@400;500;600;700&display=swap', array(), null);
            
            // v88: Design System - Comprehensive design tokens and utilities
            wp_enqueue_style('ptp-design-system-v88', PTP_PLUGIN_URL . 'assets/css/ptp-design-system-v88.css', array('ptp-google-fonts'), PTP_VERSION);
            
            // v88: Global Header CSS
            wp_enqueue_style('ptp-header-v88', PTP_PLUGIN_URL . 'assets/css/ptp-header-v88.css', array('ptp-design-system-v88'), PTP_VERSION);
            
            // v88: UI Components (cards, toasts, modals, tabs, etc.)
            wp_enqueue_style('ptp-components-v88', PTP_PLUGIN_URL . 'assets/css/ptp-components-v88.css', array('ptp-header-v88'), PTP_VERSION);
            
            wp_enqueue_style('ptp-frontend', PTP_PLUGIN_URL . 'assets/css/frontend.css', array('ptp-components-v88'), PTP_VERSION);
            wp_enqueue_script('ptp-frontend', PTP_PLUGIN_URL . 'assets/js/frontend.js', array('jquery'), PTP_VERSION, true);
            
            // v88: Global UI JavaScript (toasts, modals, dropdowns, etc.)
            wp_enqueue_script('ptp-ui-v88', PTP_PLUGIN_URL . 'assets/js/ptp-ui-v88.js', array(), PTP_VERSION, true);
            
            // v5: Modern refined theme - sleek, premium, not boxy
            wp_enqueue_style('ptp-theme-v5', PTP_PLUGIN_URL . 'assets/css/ptp-theme-v5.css', array('ptp-frontend'), PTP_VERSION);
            
            // v35: Unified design system matching Homepage v35 exactly
            wp_enqueue_style('ptp-v35-unified', PTP_PLUGIN_URL . 'assets/css/ptp-v35-unified.css', array('ptp-theme-v5'), PTP_VERSION);
            wp_enqueue_script('ptp-v35-unified', PTP_PLUGIN_URL . 'assets/js/ptp-v35-unified.js', array(), PTP_VERSION, true);
            
            // v88: Mobile CSS - Enhanced with PWA support, bottom sheets, haptics
            wp_enqueue_style('ptp-mobile-v88', PTP_PLUGIN_URL . 'assets/css/ptp-mobile-v88.css', array('ptp-v35-unified'), PTP_VERSION);
            
            // v88: Page-specific layouts (trainers grid, profile, checkout, dashboards)
            wp_enqueue_style('ptp-pages-v88', PTP_PLUGIN_URL . 'assets/css/ptp-pages-v88.css', array('ptp-mobile-v88'), PTP_VERSION);
            
            // v88: Site-wide overrides - MUST LOAD LAST (dark header, maps styling)
            wp_enqueue_style('ptp-site-overrides-v88', PTP_PLUGIN_URL . 'assets/css/ptp-site-overrides-v88.css', array('ptp-pages-v88'), PTP_VERSION);
            
            // v116: Comprehensive mobile fixes (header gap, dashboard tabs, booking wizard)
            wp_enqueue_style('ptp-mobile-fixes-v127', PTP_PLUGIN_URL . 'assets/css/ptp-mobile-fixes-v127.css', array('ptp-site-overrides-v88'), PTP_VERSION);
            
            // v133: Scroll bar hiding + mobile enhancements - MUST LOAD LAST
            wp_enqueue_style('ptp-scroll-mobile-v133', PTP_PLUGIN_URL . 'assets/css/ptp-scroll-mobile-v133.css', array('ptp-mobile-fixes-v127'), PTP_VERSION);
            
            // v133: Nuclear scroll fix - overrides any theme/plugin blocking scroll
            wp_enqueue_style('ptp-scroll-fix-v133', PTP_PLUGIN_URL . 'assets/css/ptp-scroll-fix-v133.css', array('ptp-scroll-mobile-v133'), PTP_VERSION);
        }
        
        // v71: SPA Dashboard assets (conditionally)
        if (is_page(array('trainer-dashboard', 'parent-dashboard', 'my-training'))) {
            wp_enqueue_style('ptp-spa-dashboard', PTP_PLUGIN_URL . 'assets/css/spa-dashboard.css', array('ptp-frontend'), PTP_VERSION);
            wp_enqueue_script('ptp-spa-dashboard', PTP_PLUGIN_URL . 'assets/js/spa-dashboard.js', array('jquery'), PTP_VERSION, true);
        }
        
        // v71: Messaging assets
        if (is_page('messages') || is_page('trainer-dashboard') || is_page('parent-dashboard')) {
            wp_enqueue_script('ptp-messaging', PTP_PLUGIN_URL . 'assets/js/messaging.js', array('jquery'), PTP_VERSION, true);
        }
        
        // v71: Checkout assets - only on CHECKOUT pages, not cart
        if (is_page(array('ptp-checkout', 'training-checkout', 'checkout')) && !is_page(array('ptp-cart', 'cart'))) {
            wp_enqueue_style('ptp-checkout-css', PTP_PLUGIN_URL . 'assets/css/ptp-checkout.css', array('ptp-frontend'), PTP_VERSION);
            wp_enqueue_script('ptp-checkout', PTP_PLUGIN_URL . 'assets/js/ptp-checkout.js', array('jquery'), PTP_VERSION, true);
            
            // Stripe JS - only on checkout
            wp_enqueue_script('stripe-js', 'https://js.stripe.com/v3/', array(), null, true);
            
            wp_localize_script('ptp-checkout', 'ptp_checkout', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('ptp_checkout_nonce'),
                'stripe_pk' => get_option('ptp_stripe_publishable_key', ''),
            ));
        }
        
        // Hide theme secondary navigation on PTP pages
        $hide_secondary_nav_css = '
            /* Hide theme secondary navigation with About Us / Blog */
            .secondary-navigation,
            .secondary-nav,
            .nav-secondary,
            .sub-header-nav,
            header nav:not(.main-navigation):not(.primary-navigation):not([class*="ptp"]),
            .site-header .header-row:has(a[href*="about-us"]),
            .site-header nav:has(a[href*="about-us"]):has(a[href*="blog"]):not(:has(li:nth-child(4))),
            .header-secondary,
            .kadence-header-row-secondary,
            .ast-above-header-bar,
            nav.menu-about-us-blog-container,
            #menu-about-us-blog,
            .menu-about-us-container,
            ul#menu-about-us,
            nav:has(> .menu-about-us),
            nav:has(ul[id*="about"]),
            .et_pb_menu__secondary-nav {
                display: none !important;
                visibility: hidden !important;
                height: 0 !important;
                overflow: hidden !important;
            }
        ';
        wp_add_inline_style('ptp-frontend', $hide_secondary_nav_css);
        
        wp_localize_script('ptp-frontend', 'ptp_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ptp_nonce'),
            'home_url' => home_url(),
            'is_logged_in' => is_user_logged_in(),
            'user_id' => get_current_user_id(),
            // v71 additions
            'v71_nonce' => wp_create_nonce('ptp_v71_nonce'),
            'messaging_nonce' => wp_create_nonce('ptp_messaging_nonce'),
            'spa_nonce' => wp_create_nonce('ptp_spa_nonce'),
        ));
    }
    
    public function admin_scripts($hook) {
        // Always load admin CSS on ALL admin pages
        // CSS is scoped to .ptp-admin-wrap so it won't affect other pages
        wp_enqueue_style(
            'ptp-admin-css', 
            PTP_PLUGIN_URL . 'assets/css/admin.css', 
            array(), 
            PTP_VERSION . '.' . date('His')
        );
        
        // Only load JS on PTP pages
        if (strpos($hook, 'ptp') !== false) {
            wp_enqueue_script('ptp-admin', PTP_PLUGIN_URL . 'assets/js/admin.js', array('jquery'), PTP_VERSION, true);
            wp_localize_script('ptp-admin', 'ptpAdmin', array(
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('ptp_admin_nonce')
            ));
        }
    }
    
    /**
     * Dequeue theme styles on PTP full-page templates
     * These templates are self-contained and don't need theme styles
     */
    public function dequeue_theme_on_ptp_pages() {
        // Only run on PTP full-page templates
        $full_page_templates = array(
            'trainer-dashboard',
            'parent-dashboard', 
            'trainer-onboarding',
            'login',
            'register',
            'logout',
            'apply',
            'account',
            'messages'
        );
        
        if (!is_page($full_page_templates)) {
            return;
        }
        
        // Get all enqueued styles
        global $wp_styles;
        if (!$wp_styles) return;
        
        // Theme style handles to dequeue (common theme stylesheets)
        $theme_handles = array(
            // Astra theme
            'astra-theme-css',
            'astra-addon-css',
            'astra-mobile-css',
            'astra-styles',
            // Kadence theme
            'kadence-global',
            'kadence-header',
            'kadence-content',
            'kadence-footer',
            // GeneratePress
            'generate-style',
            'generate-mobile',
            // OceanWP
            'oceanwp-style',
            'oceanwp-mobile',
            // Generic theme handles
            'theme-style',
            'theme-styles', 
            'parent-style',
            'child-style',
            // WooCommerce (not needed on dashboards)
            'woocommerce-general',
            'woocommerce-layout',
            'woocommerce-smallscreen',
            'wc-blocks-style',
            'wc-blocks-vendors-style',
        );
        
        foreach ($theme_handles as $handle) {
            if (wp_style_is($handle, 'enqueued')) {
                wp_dequeue_style($handle);
            }
        }
        
        // Also dequeue the main theme stylesheet by checking the theme name
        $theme = wp_get_theme();
        $theme_slug = $theme->get_stylesheet();
        $possible_handles = array(
            $theme_slug,
            $theme_slug . '-style',
            $theme_slug . '-css',
            $theme_slug . '-theme',
        );
        
        foreach ($possible_handles as $handle) {
            if (wp_style_is($handle, 'enqueued')) {
                wp_dequeue_style($handle);
            }
        }
        
        // Add critical CSS to ensure PTP styles win
        $critical_css = '
            /* PTP Full-Page Template Critical Override */
            body.ptp-trainer-dashboard,
            body.ptp-parent-dashboard,
            body.ptp-full-page {
                margin: 0 !important;
                padding: 0 !important;
                background: #F9FAFB !important;
                font-family: "Inter", -apple-system, BlinkMacSystemFont, sans-serif !important;
                -webkit-font-smoothing: antialiased !important;
            }
            
            /* Hide ALL theme elements aggressively */
            body.ptp-full-page #page,
            body.ptp-full-page #content,
            body.ptp-full-page .site-content,
            body.ptp-full-page .entry-content,
            body.ptp-full-page > header:not(.app-header):not(.dash-header),
            body.ptp-full-page > footer,
            body.ptp-full-page .site-header,
            body.ptp-full-page .site-footer,
            body.ptp-full-page #masthead,
            body.ptp-full-page .main-navigation,
            body.ptp-full-page .ast-primary-header,
            body.ptp-full-page .ast-mobile-header-wrap,
            body.ptp-full-page #ast-mobile-header,
            body.ptp-full-page .kadence-header,
            body.ptp-full-page .wp-block-template-part,
            body.ptp-full-page .wp-site-blocks > header,
            body.ptp-full-page .wp-site-blocks > footer,
            body.ptp-full-page #site-header,
            body.ptp-full-page #site-footer,
            body.ptp-full-page .site-branding,
            body.ptp-full-page #colophon,
            body.ptp-full-page .footer-widgets,
            body.ptp-full-page #secondary,
            body.ptp-full-page aside.widget-area,
            body.ptp-full-page .woocommerce-breadcrumb {
                display: none !important;
                visibility: hidden !important;
                height: 0 !important;
                width: 0 !important;
                overflow: hidden !important;
                position: absolute !important;
                left: -9999px !important;
            }
        ';
        wp_add_inline_style('ptp-frontend', $critical_css);
    }
    
    public function activate() {
        // Create all database tables
        PTP_Database::create_tables();
        
        // Repair any broken table schemas (for upgrades)
        PTP_Database::repair_tables();
        
        PTP_SMS_V71::create_table();
        PTP_Social::create_table();
        PTP_Geocoding::create_table();
        
        // v145: WooCommerce table - only if WC class exists
        if (class_exists('PTP_WooCommerce')) {
            PTP_WooCommerce::create_table();
        }
        
        // Advanced features tables
        PTP_Recurring::create_tables();
        PTP_Groups::create_tables();
        PTP_Calendar_Sync::create_tables();
        PTP_Training_Plans::create_tables();
        
        // New v45 features
        PTP_Gift_Cards::create_table();
        PTP_Subscriptions::create_tables();
        
        // v52: Analytics & Email Automation tables
        if (class_exists('PTP_Analytics')) {
            PTP_Analytics::create_tables();
        }
        if (class_exists('PTP_Email_Automation')) {
            PTP_Email_Automation::create_tables();
        }
        
        // v53: Growth Engine tables
        if (class_exists('PTP_Trainer_Referrals')) {
            PTP_Trainer_Referrals::create_tables();
        }
        if (class_exists('PTP_Growth')) {
            PTP_Growth::create_tables();
        }
        
        // v59: Flow Engine tables
        if (class_exists('PTP_Flow_Engine')) {
            PTP_Flow_Engine::create_tables();
        }
        
        // v59.3: Quality Control tables
        if (class_exists('PTP_Quality_Control')) {
            PTP_Quality_Control::create_tables();
        }
        
        // v71: Enhanced features tables
        $this->create_v71_tables();
        
        // Run migrations for existing installations
        $this->run_migrations();
        
        // Create critical pages first (cart/checkout)
        $this->create_critical_pages();
        
        // Create all other pages using PTP_Page_Creator (v147: like PTP Camps plugin)
        if (class_exists('PTP_Page_Creator')) {
            PTP_Page_Creator::activate();
        } else {
            // Fallback to old method if Page Creator not loaded yet
            $this->create_pages();
        }
        
        // Add capabilities
        $this->add_capabilities();
        
        // Set default options
        $this->set_default_options();
        
        // Initialize default admin FAQs
        if (class_exists('PTP_FAQ')) {
            PTP_FAQ::maybe_init_defaults();
        }
        
        // Schedule cron jobs
        PTP_Cron::schedule_events();
        
        // Create All-Access Pass product
        $this->create_all_access_product();
        
        // Flush rewrite rules
        flush_rewrite_rules();
        
        // Store version
        update_option('ptp_version', PTP_VERSION);
    }
    
    /**
     * Run database migrations for existing installations
     */
    private function run_migrations() {
        global $wpdb;
        
        // Helper function to add column if it doesn't exist
        $add_column_if_missing = function($table, $column, $definition) use ($wpdb) {
            $column_exists = $wpdb->get_results($wpdb->prepare(
                "SHOW COLUMNS FROM {$table} LIKE %s", $column
            ));
            if (empty($column_exists)) {
                $wpdb->query("ALTER TABLE {$table} ADD COLUMN {$column} {$definition}");
            }
        };
        
        // Migrate applications table
        $apps_table = $wpdb->prefix . 'ptp_applications';
        if ($wpdb->get_var("SHOW TABLES LIKE '{$apps_table}'") === $apps_table) {
            $add_column_if_missing($apps_table, 'name', "varchar(100) NOT NULL DEFAULT '' AFTER email");
            $add_column_if_missing($apps_table, 'phone', "varchar(20) DEFAULT '' AFTER name");
            $add_column_if_missing($apps_table, 'location', "varchar(255) DEFAULT '' AFTER phone");
            $add_column_if_missing($apps_table, 'college', "varchar(255) DEFAULT '' AFTER location");
            $add_column_if_missing($apps_table, 'team', "varchar(255) DEFAULT '' AFTER college");
            $add_column_if_missing($apps_table, 'playing_level', "varchar(50) DEFAULT '' AFTER team");
            $add_column_if_missing($apps_table, 'position', "varchar(100) DEFAULT '' AFTER playing_level");
            $add_column_if_missing($apps_table, 'specialties', "text AFTER position");
            $add_column_if_missing($apps_table, 'instagram', "varchar(100) DEFAULT '' AFTER specialties");
            $add_column_if_missing($apps_table, 'headline', "varchar(255) DEFAULT '' AFTER instagram");
            $add_column_if_missing($apps_table, 'bio', "text AFTER headline");
            $add_column_if_missing($apps_table, 'hourly_rate', "decimal(10,2) DEFAULT 0 AFTER bio");
            $add_column_if_missing($apps_table, 'travel_radius', "int(11) DEFAULT 15 AFTER hourly_rate");
        }
        
        // Migrate trainers table
        $trainers_table = $wpdb->prefix . 'ptp_trainers';
        if ($wpdb->get_var("SHOW TABLES LIKE '{$trainers_table}'") === $trainers_table) {
            $add_column_if_missing($trainers_table, 'email', "varchar(255) DEFAULT '' AFTER slug");
            $add_column_if_missing($trainers_table, 'phone', "varchar(20) DEFAULT '' AFTER email");
            $add_column_if_missing($trainers_table, 'playing_level', "varchar(50) DEFAULT '' AFTER team");
            $add_column_if_missing($trainers_table, 'instagram', "varchar(100) DEFAULT '' AFTER specialties");
            $add_column_if_missing($trainers_table, 'gallery', "text AFTER photo_url");
            $add_column_if_missing($trainers_table, 'training_locations', "text AFTER travel_radius");
            // Verification documents
            $add_column_if_missing($trainers_table, 'safesport_doc_url', "varchar(500) DEFAULT '' AFTER instagram");
            $add_column_if_missing($trainers_table, 'safesport_verified', "tinyint(1) DEFAULT 0 AFTER safesport_doc_url");
            $add_column_if_missing($trainers_table, 'safesport_expiry', "date DEFAULT NULL AFTER safesport_verified");
            $add_column_if_missing($trainers_table, 'background_doc_url', "varchar(500) DEFAULT '' AFTER safesport_expiry");
            $add_column_if_missing($trainers_table, 'background_verified', "tinyint(1) DEFAULT 0 AFTER background_doc_url");
            // Tax information for 1099
            $add_column_if_missing($trainers_table, 'tax_id_last4', "varchar(4) DEFAULT '' AFTER background_verified");
            $add_column_if_missing($trainers_table, 'tax_id_type', "enum('ssn','ein') DEFAULT 'ssn' AFTER tax_id_last4");
            $add_column_if_missing($trainers_table, 'legal_name', "varchar(255) DEFAULT '' AFTER tax_id_type");
            $add_column_if_missing($trainers_table, 'tax_address_line1', "varchar(255) DEFAULT '' AFTER legal_name");
            $add_column_if_missing($trainers_table, 'tax_address_line2', "varchar(255) DEFAULT '' AFTER tax_address_line1");
            $add_column_if_missing($trainers_table, 'tax_city', "varchar(100) DEFAULT '' AFTER tax_address_line2");
            $add_column_if_missing($trainers_table, 'tax_state', "varchar(2) DEFAULT '' AFTER tax_city");
            $add_column_if_missing($trainers_table, 'tax_zip', "varchar(10) DEFAULT '' AFTER tax_state");
            $add_column_if_missing($trainers_table, 'w9_submitted', "tinyint(1) DEFAULT 0 AFTER tax_zip");
            $add_column_if_missing($trainers_table, 'w9_submitted_at', "datetime DEFAULT NULL AFTER w9_submitted");
            $add_column_if_missing($trainers_table, 'contractor_agreement_signed', "tinyint(1) DEFAULT 0 AFTER w9_submitted_at");
            $add_column_if_missing($trainers_table, 'contractor_agreement_signed_at', "datetime DEFAULT NULL AFTER contractor_agreement_signed");
            $add_column_if_missing($trainers_table, 'contractor_agreement_ip', "varchar(45) DEFAULT '' AFTER contractor_agreement_signed_at");
            $add_column_if_missing($trainers_table, 'stripe_account_id', "varchar(255) DEFAULT '' AFTER contractor_agreement_ip");
            $add_column_if_missing($trainers_table, 'stripe_charges_enabled', "tinyint(1) DEFAULT 0 AFTER stripe_account_id");
            
            // Video profile (TeachMeTo "Vet Em Video" equivalent)
            $add_column_if_missing($trainers_table, 'intro_video_url', "varchar(500) DEFAULT '' AFTER gallery");
            
            // Group sessions
            $add_column_if_missing($trainers_table, 'accepts_groups', "tinyint(1) DEFAULT 1 AFTER training_locations");
            $add_column_if_missing($trainers_table, 'group_max_size', "int(11) DEFAULT 3 AFTER accepts_groups");
            $add_column_if_missing($trainers_table, 'group_rate_2', "decimal(10,2) DEFAULT 0 AFTER group_max_size");
            $add_column_if_missing($trainers_table, 'group_rate_3', "decimal(10,2) DEFAULT 0 AFTER group_rate_2");
            
            // v45: Happy Student Score system
            $add_column_if_missing($trainers_table, 'happy_student_score', "int(11) DEFAULT 0 AFTER review_count");
            $add_column_if_missing($trainers_table, 'reliability_score', "int(11) DEFAULT 100 AFTER happy_student_score");
            $add_column_if_missing($trainers_table, 'responsiveness_score', "int(11) DEFAULT 100 AFTER reliability_score");
            $add_column_if_missing($trainers_table, 'return_rate', "int(11) DEFAULT 0 AFTER responsiveness_score");
            $add_column_if_missing($trainers_table, 'is_supercoach', "tinyint(1) DEFAULT 0 AFTER return_rate");
            $add_column_if_missing($trainers_table, 'supercoach_awarded_at', "datetime DEFAULT NULL AFTER is_supercoach");
            $add_column_if_missing($trainers_table, 'lesson_lengths', "varchar(50) DEFAULT '60' AFTER intro_video_url");
            $add_column_if_missing($trainers_table, 'max_participants', "int(11) DEFAULT 1 AFTER lesson_lengths");
            
            // v59.3: Quality control fields
            $add_column_if_missing($trainers_table, 'paused_at', "datetime DEFAULT NULL");
            $add_column_if_missing($trainers_table, 'pause_reason', "text");
            $add_column_if_missing($trainers_table, 'fast_responder', "tinyint(1) DEFAULT 0");
            $add_column_if_missing($trainers_table, 'quality_score', "int(11) DEFAULT 100");
            $add_column_if_missing($trainers_table, 'loyalty_tier', "varchar(20) DEFAULT 'bronze'");
        }
        
        // Add session notes table for progress tracking
        $notes_table = $wpdb->prefix . 'ptp_session_notes';
        if ($wpdb->get_var("SHOW TABLES LIKE '{$notes_table}'") !== $notes_table) {
            $charset_collate = $wpdb->get_charset_collate();
            $wpdb->query("CREATE TABLE {$notes_table} (
                id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                booking_id bigint(20) UNSIGNED NOT NULL,
                trainer_id bigint(20) UNSIGNED NOT NULL,
                player_id bigint(20) UNSIGNED NOT NULL,
                skills_worked text,
                progress_notes text,
                homework text,
                next_focus text,
                effort_rating tinyint(1) DEFAULT NULL,
                attitude_rating tinyint(1) DEFAULT NULL,
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY booking_id (booking_id),
                KEY player_id (player_id),
                KEY trainer_id (trainer_id)
            ) {$charset_collate}");
        }
        
        // v45: Add subscription_id to bookings
        $bookings_table = $wpdb->prefix . 'ptp_bookings';
        if ($wpdb->get_var("SHOW TABLES LIKE '{$bookings_table}'") === $bookings_table) {
            $add_column_if_missing($bookings_table, 'subscription_id', "bigint(20) UNSIGNED DEFAULT NULL AFTER recurring_id");
            $add_column_if_missing($bookings_table, 'gcal_event_id', "varchar(255) DEFAULT NULL COMMENT 'Google Calendar event ID'");
        }
        
        // v59.3: Add would_recommend to reviews
        $reviews_table = $wpdb->prefix . 'ptp_reviews';
        if ($wpdb->get_var("SHOW TABLES LIKE '{$reviews_table}'") === $reviews_table) {
            $add_column_if_missing($reviews_table, 'would_recommend', "tinyint(1) DEFAULT 1");
        }
    }
    
    /**
     * Create v71 database tables for enhanced features
     */
    private function create_v71_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        
        // Availability blocks table (bridge scheduling)
        $table_name = $wpdb->prefix . 'ptp_availability_blocks';
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") !== $table_name) {
            $wpdb->query("CREATE TABLE $table_name (
                id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                trainer_id bigint(20) UNSIGNED NOT NULL,
                day_of_week tinyint(1) DEFAULT NULL COMMENT '0=Sunday, 6=Saturday, NULL for specific date',
                specific_date date DEFAULT NULL,
                start_time time NOT NULL,
                end_time time NOT NULL,
                block_type enum('available','unavailable','google_busy') DEFAULT 'available',
                is_recurring tinyint(1) DEFAULT 1,
                google_event_id varchar(255) DEFAULT NULL,
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY trainer_id (trainer_id),
                KEY day_of_week (day_of_week),
                KEY specific_date (specific_date),
                KEY block_type (block_type)
            ) $charset_collate");
        }
        
        // Conversations table (messaging)
        $table_name = $wpdb->prefix . 'ptp_conversations';
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") !== $table_name) {
            $wpdb->query("CREATE TABLE $table_name (
                id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                trainer_id bigint(20) UNSIGNED NOT NULL,
                parent_id bigint(20) UNSIGNED NOT NULL,
                last_message_at datetime DEFAULT NULL,
                trainer_unread_count int(11) DEFAULT 0,
                parent_unread_count int(11) DEFAULT 0,
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY trainer_parent (trainer_id, parent_id),
                KEY trainer_id (trainer_id),
                KEY parent_id (parent_id),
                KEY last_message_at (last_message_at)
            ) $charset_collate");
        }
        
        // Messages table
        $table_name = $wpdb->prefix . 'ptp_messages_v71';
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") !== $table_name) {
            $wpdb->query("CREATE TABLE $table_name (
                id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                conversation_id bigint(20) UNSIGNED NOT NULL,
                sender_type enum('trainer','parent') NOT NULL,
                sender_id bigint(20) UNSIGNED NOT NULL,
                message text NOT NULL,
                is_read tinyint(1) DEFAULT 0,
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY conversation_id (conversation_id),
                KEY sender_id (sender_id),
                KEY created_at (created_at)
            ) $charset_collate");
        }
        
        // Calendar connections table (Google Calendar OAuth)
        $table_name = $wpdb->prefix . 'ptp_calendar_connections';
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") !== $table_name) {
            $wpdb->query("CREATE TABLE $table_name (
                id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id bigint(20) UNSIGNED NOT NULL,
                provider varchar(50) DEFAULT 'google',
                email varchar(255) DEFAULT NULL,
                access_token text,
                refresh_token text,
                token_expires datetime DEFAULT NULL,
                calendar_id varchar(255) DEFAULT NULL,
                last_sync datetime DEFAULT NULL,
                sync_enabled tinyint(1) DEFAULT 1,
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY user_provider (user_id, provider),
                KEY user_id (user_id)
            ) $charset_collate");
        }
        
        // Payouts table (Stripe Connect)
        $table_name = $wpdb->prefix . 'ptp_payouts';
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") !== $table_name) {
            $wpdb->query("CREATE TABLE $table_name (
                id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                trainer_id bigint(20) UNSIGNED NOT NULL,
                amount decimal(10,2) NOT NULL,
                currency varchar(3) DEFAULT 'usd',
                status enum('pending','processing','paid','failed') DEFAULT 'pending',
                stripe_transfer_id varchar(255) DEFAULT NULL,
                stripe_payout_id varchar(255) DEFAULT NULL,
                booking_ids text COMMENT 'JSON array of booking IDs',
                requested_at datetime DEFAULT CURRENT_TIMESTAMP,
                processed_at datetime DEFAULT NULL,
                notes text,
                PRIMARY KEY (id),
                KEY trainer_id (trainer_id),
                KEY status (status),
                KEY requested_at (requested_at)
            ) $charset_collate");
        }
        
        // SMS log table
        $table_name = $wpdb->prefix . 'ptp_sms_log_v71';
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") !== $table_name) {
            $wpdb->query("CREATE TABLE $table_name (
                id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                phone varchar(20) NOT NULL,
                message text NOT NULL,
                message_type varchar(50) DEFAULT 'general',
                provider varchar(50) DEFAULT 'twilio',
                status enum('sent','delivered','failed','pending') DEFAULT 'pending',
                provider_message_id varchar(255) DEFAULT NULL,
                error_message text,
                metadata text COMMENT 'JSON metadata',
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY phone (phone),
                KEY message_type (message_type),
                KEY status (status),
                KEY created_at (created_at)
            ) $charset_collate");
        }
        
        // Add Stripe Connect columns to trainers table
        $trainers_table = $wpdb->prefix . 'ptp_trainers';
        if ($wpdb->get_var("SHOW TABLES LIKE '$trainers_table'") === $trainers_table) {
            $columns = $wpdb->get_col("SHOW COLUMNS FROM $trainers_table");
            
            if (!in_array('stripe_account_id', $columns)) {
                $wpdb->query("ALTER TABLE $trainers_table ADD COLUMN stripe_account_id varchar(255) DEFAULT NULL");
            }
            if (!in_array('stripe_account_status', $columns)) {
                $wpdb->query("ALTER TABLE $trainers_table ADD COLUMN stripe_account_status varchar(50) DEFAULT NULL");
            }
            if (!in_array('stripe_payouts_enabled', $columns)) {
                $wpdb->query("ALTER TABLE $trainers_table ADD COLUMN stripe_payouts_enabled tinyint(1) DEFAULT 0");
            }
            if (!in_array('pending_balance', $columns)) {
                $wpdb->query("ALTER TABLE $trainers_table ADD COLUMN pending_balance decimal(10,2) DEFAULT 0");
            }
            if (!in_array('available_balance', $columns)) {
                $wpdb->query("ALTER TABLE $trainers_table ADD COLUMN available_balance decimal(10,2) DEFAULT 0");
            }
            if (!in_array('total_earnings', $columns)) {
                $wpdb->query("ALTER TABLE $trainers_table ADD COLUMN total_earnings decimal(10,2) DEFAULT 0");
            }
        }
    }
    
    private function set_default_options() {
        // General settings
        add_option('ptp_platform_fee', '20');
        add_option('ptp_from_email', get_option('admin_email'));
        
        // Notification defaults
        add_option('ptp_email_booking_confirmation', true);
        add_option('ptp_email_session_reminder', true);
        add_option('ptp_email_review_request', true);
        add_option('ptp_sms_booking_confirmation', true);
        add_option('ptp_sms_session_reminder', true);
        
        // Stripe defaults
        add_option('ptp_stripe_test_mode', true);
    }
    
    public function deactivate() {
        PTP_Cron::clear_events();
        flush_rewrite_rules();
    }
    
    /**
     * Create critical pages (cart/checkout) - always runs
     */
    private function create_critical_pages() {
        $critical_pages = array(
            // Training checkout pages
            'ptp-cart' => array('title' => 'Cart', 'content' => '[ptp_cart]'),
            'ptp-checkout' => array('title' => 'Checkout', 'content' => '[ptp_checkout]'),
            'training-checkout' => array('title' => 'Training Checkout', 'content' => '[ptp_training_checkout]'),
            'thank-you' => array('title' => 'Thank You', 'content' => '[ptp_thank_you]'),
            // Camp checkout pages (v147: like PTP Camps plugin)
            'camp-checkout' => array('title' => 'Camp Checkout', 'content' => '[ptp_camp_checkout]'),
            'camp-thank-you' => array('title' => 'Camp Thank You', 'content' => '[ptp_camp_thank_you]'),
        );
        
        foreach ($critical_pages as $slug => $page) {
            $existing = get_page_by_path($slug);
            
            if (!$existing) {
                // Create the page
                wp_insert_post(array(
                    'post_title' => $page['title'],
                    'post_name' => $slug,
                    'post_content' => $page['content'],
                    'post_status' => 'publish',
                    'post_type' => 'page',
                ));
                error_log('PTP: Created critical page: ' . $slug);
            } elseif ($existing->post_status === 'trash') {
                // Restore from trash
                wp_update_post(array(
                    'ID' => $existing->ID,
                    'post_status' => 'publish',
                    'post_content' => $page['content'],
                ));
                error_log('PTP: Restored critical page from trash: ' . $slug);
            }
        }
    }
    
    /**
     * Check and create missing pages (runs on admin init)
     */
    private function maybe_create_pages() {
        // Always ensure critical pages exist (cart, checkout)
        $this->create_critical_pages();
        
        // Only run full page creation once per version update
        $pages_version = get_option('ptp_pages_version', '0');
        if (version_compare($pages_version, PTP_VERSION, '>=')) {
            return;
        }
        
        $this->create_pages();
        update_option('ptp_pages_version', PTP_VERSION);
        
        // Flush rewrite rules after creating pages
        flush_rewrite_rules();
    }
    
    private function create_pages() {
        $pages = array(
            'training' => array('title' => 'Private Training', 'content' => '[ptp_training]'),
            'find-trainers' => array('title' => 'Find Trainers', 'content' => '[ptp_trainers_grid]'),
            'trainer' => array('title' => 'Trainer Profile', 'content' => '[ptp_trainer_profile]'),
            'book-session' => array('title' => 'Book Session', 'content' => '[ptp_booking_form]'),
            'book' => array('title' => 'Book Training', 'content' => '[ptp_booking_wizard]'),
            'booking-confirmation' => array('title' => 'Booking Confirmed', 'content' => '[ptp_booking_confirmation]'),
            'bundle-checkout' => array('title' => 'Bundle Checkout', 'content' => '[ptp_bundle_checkout]'),
            'training-checkout' => array('title' => 'Training Checkout', 'content' => '[ptp_training_checkout]'),
            'my-training' => array('title' => 'My Training', 'content' => '[ptp_my_training]'),
            'trainer-dashboard' => array('title' => 'Trainer Dashboard', 'content' => '[ptp_trainer_dashboard]'),
            'trainer-onboarding' => array('title' => 'Complete Your Profile', 'content' => '[ptp_trainer_onboarding]'),
            'trainer-pending' => array('title' => 'Application Under Review', 'content' => '[ptp_trainer_pending]'),
            'trainer-edit-profile' => array('title' => 'Edit Profile', 'content' => '[ptp_trainer_profile_editor]'),
            'messages' => array('title' => 'Messages', 'content' => '[ptp_messaging]'),
            'account' => array('title' => 'Account', 'content' => '[ptp_account]'),
            'login' => array('title' => 'Login', 'content' => '[ptp_login]'),
            'register' => array('title' => 'Register', 'content' => '[ptp_register]'),
            'social-login' => array('title' => 'Social Login', 'content' => ''),
            'apply' => array('title' => 'Become a Trainer', 'content' => '[ptp_apply]'),
            'parent-dashboard' => array('title' => 'Parent Dashboard', 'content' => '[ptp_parent_dashboard]'),
            'player-progress' => array('title' => 'Player Progress', 'content' => '[ptp_player_progress]'),
            'training-plans' => array('title' => 'Training Plans', 'content' => '[ptp_training_plans]'),
            'logout' => array('title' => 'Log Out', 'content' => '[ptp_logout]'),
            'gift-cards' => array('title' => 'Gift Cards', 'content' => '[ptp_gift_cards]'),
            'all-access' => array('title' => 'All-Access Pass', 'content' => '<!-- Template loaded by plugin -->'),
            // Legal pages
            'liability-waiver' => array('title' => 'Liability Waiver', 'content' => '<h2>Liability Waiver & Release</h2>
<p>By registering for PTP Soccer Camps or Private Training, I acknowledge and agree to the following:</p>
<h3>Assumption of Risk</h3>
<p>I understand that participation in soccer activities involves inherent risks, including but not limited to physical injury, illness, or death. I voluntarily assume all such risks.</p>
<h3>Medical Authorization</h3>
<p>I authorize PTP staff to seek emergency medical treatment for my child if necessary. I understand I am responsible for any medical expenses incurred.</p>
<h3>Release of Liability</h3>
<p>I release and hold harmless PTP Soccer Camps, its coaches, trainers, employees, and volunteers from any claims, damages, or liability arising from participation in activities.</p>
<h3>Health Confirmation</h3>
<p>I confirm that my child is physically fit to participate and has no medical conditions that would prevent safe participation.</p>
<p><em>Last updated: January 2025</em></p>'),
            'refund-policy' => array('title' => 'Refund Policy', 'content' => '<h2>Refund & Cancellation Policy</h2>
<h3>Camp Registrations</h3>
<ul>
<li><strong>More than 14 days before camp:</strong> Full refund minus $25 processing fee, or transfer to another session</li>
<li><strong>7-14 days before camp:</strong> 50% refund or transfer to another session</li>
<li><strong>Less than 7 days before camp:</strong> No refund, but may transfer to another session with same value</li>
</ul>
<h3>Private Training Sessions</h3>
<ul>
<li><strong>Single sessions:</strong> Cancel at least 24 hours in advance for full credit</li>
<li><strong>Training packages:</strong> Unused sessions do not expire and can be rescheduled</li>
</ul>
<h3>Weather Cancellations</h3>
<p>If PTP cancels due to weather or other circumstances beyond our control, you will receive a full credit or refund.</p>
<h3>Transfers</h3>
<p>Camp registrations may be transferred to another participant or session at any time before the start of camp.</p>
<p><em>Contact us at info@ptpsummercamps.com for any questions.</em></p>'),
            'media-release' => array('title' => 'Media Release', 'content' => '<h2>Photo & Video Release</h2>
<p>By consenting to this media release, I grant PTP Soccer Camps permission to:</p>
<ul>
<li>Take photographs and videos of my child during camp and training activities</li>
<li>Use these images for promotional purposes including website, social media, brochures, and advertising</li>
<li>Store and archive these images for future use</li>
</ul>
<h3>Privacy</h3>
<p>We will never sell images to third parties or use them in any context that could be considered harmful or embarrassing.</p>
<h3>Opting Out</h3>
<p>If you do not consent to media use, please contact us and we will ensure your child is not photographed or that images are not used publicly.</p>
<p><em>This consent remains in effect unless revoked in writing.</em></p>'),
        );
        
        foreach ($pages as $slug => $page) {
            if (!get_page_by_path($slug)) {
                wp_insert_post(array(
                    'post_title' => $page['title'],
                    'post_name' => $slug,
                    'post_content' => $page['content'],
                    'post_status' => 'publish',
                    'post_type' => 'page',
                ));
            }
        }
    }
    
    /**
     * Create All-Access Pass WooCommerce product
     */
    private function create_all_access_product() {
        // Check if WooCommerce is active
        if (!class_exists('WC_Product')) {
            return;
        }
        
        // Check if product already exists
        $existing_id = get_option('ptp_all_access_product_id', 0);
        if ($existing_id && get_post_status($existing_id)) {
            return; // Product exists
        }
        
        // Check by SKU
        $existing_product_id = wc_get_product_id_by_sku('ptp-all-access-pass');
        if ($existing_product_id) {
            update_option('ptp_all_access_product_id', $existing_product_id);
            return;
        }
        
        // Create the product
        $product = new WC_Product_Simple();
        $product->set_name('All-Access Pass');
        $product->set_slug('all-access-pass');
        $product->set_status('publish');
        $product->set_catalog_visibility('visible');
        $product->set_description('The complete PTP experience — 6 summer camps, 12 private sessions, 6 skills clinics, 4 hours of video analysis, and 4 hours of mentorship. Save $1,930 (33% off).');
        $product->set_short_description('6 Camps + 12 Private Sessions + 6 Clinics + Video Analysis + Mentorship — Save 33%');
        $product->set_sku('ptp-all-access-pass');
        $product->set_regular_price('5930');
        $product->set_sale_price('4000');
        $product->set_price('4000');
        $product->set_sold_individually(true);
        $product->set_virtual(true);
        $product->set_manage_stock(false);
        
        // Save product
        $product_id = $product->save();
        
        if ($product_id) {
            // Store the product ID
            update_option('ptp_all_access_product_id', $product_id);
            
            // Add to category if exists
            $term = get_term_by('slug', 'memberships', 'product_cat');
            if (!$term) {
                // Create memberships category
                $term = wp_insert_term('Memberships', 'product_cat', array(
                    'slug' => 'memberships',
                    'description' => 'PTP membership packages and passes'
                ));
                if (!is_wp_error($term)) {
                    wp_set_object_terms($product_id, $term['term_id'], 'product_cat');
                }
            } else {
                wp_set_object_terms($product_id, $term->term_id, 'product_cat');
            }
            
            // Add custom meta for tracking
            update_post_meta($product_id, '_ptp_product_type', 'all-access-pass');
            update_post_meta($product_id, '_ptp_camps_included', 6);
            update_post_meta($product_id, '_ptp_private_sessions', 12);
            update_post_meta($product_id, '_ptp_clinics_included', 6);
            update_post_meta($product_id, '_ptp_video_analysis_hours', 4);
            update_post_meta($product_id, '_ptp_mentorship_hours', 4);
        }
    }
    
    private function add_capabilities() {
        // Register custom roles
        $trainer_role = get_role('ptp_trainer');
        if (!$trainer_role) {
            add_role('ptp_trainer', 'PTP Trainer', array(
                'read' => true,
                'upload_files' => true,
            ));
        }
        
        $parent_role = get_role('ptp_parent');
        if (!$parent_role) {
            add_role('ptp_parent', 'PTP Parent', array(
                'read' => true,
            ));
        }
        
        // Add admin capabilities
        $admin = get_role('administrator');
        if ($admin) {
            $admin->add_cap('manage_ptp_trainers');
            $admin->add_cap('manage_ptp_bookings');
            $admin->add_cap('manage_ptp_payments');
        }
    }
}

/**
 * Get video embed URL from YouTube or Vimeo link
 */
function ptp_get_video_embed_url($url) {
    if (empty($url)) return '';
    
    // YouTube
    if (preg_match('/youtube\.com\/watch\?v=([a-zA-Z0-9_-]+)/', $url, $matches) ||
        preg_match('/youtu\.be\/([a-zA-Z0-9_-]+)/', $url, $matches) ||
        preg_match('/youtube\.com\/embed\/([a-zA-Z0-9_-]+)/', $url, $matches)) {
        return 'https://www.youtube.com/embed/' . $matches[1];
    }
    
    // Vimeo
    if (preg_match('/vimeo\.com\/(\d+)/', $url, $matches)) {
        return 'https://player.vimeo.com/video/' . $matches[1];
    }
    
    return $url;
}

/**
 * Get video thumbnail URL
 */
function ptp_get_video_thumbnail($url) {
    if (empty($url)) return '';
    
    // YouTube
    if (preg_match('/youtube\.com\/watch\?v=([a-zA-Z0-9_-]+)/', $url, $matches) ||
        preg_match('/youtu\.be\/([a-zA-Z0-9_-]+)/', $url, $matches)) {
        return 'https://img.youtube.com/vi/' . $matches[1] . '/maxresdefault.jpg';
    }
    
    return '';
}

/**
 * Format phone number for display
 */
function ptp_format_phone($phone) {
    $cleaned = preg_replace('/[^0-9]/', '', $phone);
    if (strlen($cleaned) === 10) {
        return '(' . substr($cleaned, 0, 3) . ') ' . substr($cleaned, 3, 3) . '-' . substr($cleaned, 6);
    }
    if (strlen($cleaned) === 11 && $cleaned[0] === '1') {
        return '(' . substr($cleaned, 1, 3) . ') ' . substr($cleaned, 4, 3) . '-' . substr($cleaned, 7);
    }
    return $phone;
}

function PTP() {
    return PTP_Training_Platform::instance();
}

// v130.3: Register activation hook for database setup and indexes
register_activation_hook(__FILE__, array('PTP_Database', 'activate'));

// v130.3: Also run on plugin update (version check)
add_action('plugins_loaded', function() {
    $installed_version = get_option('ptp_version', '0');
    if (version_compare($installed_version, PTP_VERSION, '<')) {
        PTP_Database::create_tables();
        PTP_Database::add_performance_indexes();
        update_option('ptp_version', PTP_VERSION);
    }
}, 5);

PTP();
