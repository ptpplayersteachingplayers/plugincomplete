<?php
/**
 * Plugin Name: PTP Camps
 * Description: Summer camp registration with Stripe payments
 * Version: 2.0.0
 * Author: PTP Soccer
 */

if (!defined('ABSPATH')) exit;

define('PTP_CAMPS_VERSION', '2.0.0');
define('PTP_CAMPS_PATH', plugin_dir_path(__FILE__));
define('PTP_CAMPS_URL', plugin_dir_url(__FILE__));

class PTP_Camps {
    private static $instance = null;
    
    public static function instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function __construct() {
        $this->includes();
        $this->init_hooks();
    }
    
    private function includes() {
        require_once PTP_CAMPS_PATH . 'includes/class-database.php';
        require_once PTP_CAMPS_PATH . 'includes/class-camps.php';
        require_once PTP_CAMPS_PATH . 'includes/class-coupons.php';
        require_once PTP_CAMPS_PATH . 'includes/class-cart.php';
        require_once PTP_CAMPS_PATH . 'includes/class-checkout.php';
        require_once PTP_CAMPS_PATH . 'includes/class-stripe.php';
        require_once PTP_CAMPS_PATH . 'includes/class-webhooks.php';
        require_once PTP_CAMPS_PATH . 'includes/class-emails.php';
        require_once PTP_CAMPS_PATH . 'includes/class-ajax.php';
        if (is_admin()) {
            require_once PTP_CAMPS_PATH . 'includes/class-admin.php';
            require_once PTP_CAMPS_PATH . 'includes/class-woo-import.php';
        }
    }
    
    private function init_hooks() {
        register_activation_hook(__FILE__, array($this, 'activate'));
        add_action('init', array($this, 'register_post_type'));
        add_action('init', array($this, 'register_pages'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'));
        add_filter('template_include', array($this, 'load_template'), 99);
    }
    
    public function activate() {
        $this->register_post_type();
        flush_rewrite_rules();
        PTP_Camps_Database::create_tables();
        
        // Create checkout page
        if (!get_page_by_path('camp-checkout')) {
            wp_insert_post(array(
                'post_title' => 'Camp Checkout',
                'post_name' => 'camp-checkout',
                'post_status' => 'publish',
                'post_type' => 'page',
                'post_content' => '[ptp_camp_checkout]'
            ));
        }
    }
    
    public function register_post_type() {
        register_post_type('ptp_camp', array(
            'labels' => array(
                'name' => 'Camps',
                'singular_name' => 'Camp',
                'add_new' => 'Add Camp',
                'add_new_item' => 'Add New Camp'
            ),
            'public' => true,
            'has_archive' => true,
            'rewrite' => array('slug' => 'camps'),
            'supports' => array('title', 'editor', 'thumbnail'),
            'menu_icon' => 'dashicons-superhero',
            'show_in_rest' => true
        ));
    }
    
    public function register_pages() {
        add_shortcode('ptp_camp_checkout', array('PTP_Camps_Checkout', 'render_checkout'));
    }
    
    public function enqueue_assets() {
        if (is_singular('ptp_camp') || is_post_type_archive('ptp_camp') || is_page('camp-checkout')) {
            wp_enqueue_style('ptp-camps', PTP_CAMPS_URL . 'assets/css/ptp-camp-product.css', array(), PTP_CAMPS_VERSION);
            wp_enqueue_script('stripe', 'https://js.stripe.com/v3/', array(), null, true);
            wp_enqueue_script('ptp-camps', PTP_CAMPS_URL . 'assets/js/ptp-camp-product.js', array('jquery', 'stripe'), PTP_CAMPS_VERSION, true);
            wp_localize_script('ptp-camps', 'ptpCamps', array(
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('ptp_camps_nonce'),
                'stripeKey' => get_option('ptp_camps_stripe_pk', ''),
                'checkoutUrl' => home_url('/camp-checkout/')
            ));
        }
    }
    
    public function load_template($template) {
        if (is_singular('ptp_camp')) {
            $custom = PTP_CAMPS_PATH . 'templates/single-camp.php';
            if (file_exists($custom)) return $custom;
        }
        return $template;
    }
}

function ptp_camps() { return PTP_Camps::instance(); }

function ptp_camps_is_early_bird() {
    return time() < strtotime('2026-02-16 23:59:59 America/New_York');
}

function ptp_camps_early_bird_data() {
    $deadline = strtotime('2026-02-16 23:59:59 America/New_York');
    $diff = $deadline - time();
    return array(
        'active' => $diff > 0,
        'deadline' => $deadline,
        'days_left' => max(0, floor($diff / 86400)),
        'discount' => 50
    );
}

add_action('plugins_loaded', 'ptp_camps');
