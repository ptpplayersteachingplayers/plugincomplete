<?php
/**
 * Skills Section Partial
 */

if (!defined('ABSPATH')) exit;
?>

<!-- SKILLS SECTION -->
<section class="ptp-section ptp-bg-white">
    <div class="ptp-section-header center">
        <span class="ptp-label">The Experience</span>
        <h2 class="ptp-headline">Skills You'll <span>Master</span></h2>
    </div>
    <div class="ptp-skills-grid">
        <div class="ptp-skill-card">
            <div class="ptp-skill-icon">⚽</div>
            <div class="ptp-skill-name">1v1 Moves</div>
            <div class="ptp-skill-desc">Beat defenders with scissors, stepovers, and body feints</div>
        </div>
        <div class="ptp-skill-card">
            <div class="ptp-skill-icon">🎯</div>
            <div class="ptp-skill-name">Finishing</div>
            <div class="ptp-skill-desc">Placement, power, and composure in front of goal</div>
        </div>
        <div class="ptp-skill-card">
            <div class="ptp-skill-icon">👟</div>
            <div class="ptp-skill-name">First Touch</div>
            <div class="ptp-skill-desc">Receiving, cushion control, and turns under pressure</div>
        </div>
        <div class="ptp-skill-card">
            <div class="ptp-skill-icon">🔗</div>
            <div class="ptp-skill-name">Passing Combos</div>
            <div class="ptp-skill-desc">Wall passes, through balls, and give-and-gos</div>
        </div>
        <div class="ptp-skill-card">
            <div class="ptp-skill-icon">👁️</div>
            <div class="ptp-skill-name">Scanning</div>
            <div class="ptp-skill-desc">Check shoulders before receiving—see the field</div>
        </div>
        <div class="ptp-skill-card">
            <div class="ptp-skill-icon">🛡️</div>
            <div class="ptp-skill-name">Defending</div>
            <div class="ptp-skill-desc">Body position, jockeying, and winning 1v1 duels</div>
        </div>
    </div>
</section>
