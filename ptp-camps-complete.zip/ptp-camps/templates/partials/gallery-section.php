<?php
/**
 * Gallery Section Partial
 */

if (!defined('ABSPATH')) exit;
?>

<!-- GALLERY -->
<section class="ptp-gallery ptp-section">
    <div class="ptp-gallery-header">
        <span class="ptp-label">Skills in Action</span>
        <h2 class="ptp-headline ptp-headline-white">Real <span>Training</span></h2>
    </div>
    <div class="ptp-gallery-grid">
        <div class="ptp-gallery-item">
            <img src="https://ptpsummercamps.com/wp-content/uploads/2026/01/hunter.jpg" alt="1v1 Moves">
            <span class="ptp-gallery-caption">1v1 Moves</span>
        </div>
        <div class="ptp-gallery-item">
            <img src="https://ptpsummercamps.com/wp-content/uploads/2025/12/cone-dribbling-6.jpg" alt="Ball Mastery">
            <span class="ptp-gallery-caption">Ball Mastery</span>
        </div>
        <div class="ptp-gallery-item">
            <img src="https://ptpsummercamps.com/wp-content/uploads/2025/12/cone-dribbling-4.jpg" alt="Close Control">
            <span class="ptp-gallery-caption">Close Control</span>
        </div>
        <div class="ptp-gallery-item">
            <img src="https://ptpsummercamps.com/wp-content/uploads/2025/12/BG7A1787.jpg" alt="Small-Sided Games">
            <span class="ptp-gallery-caption">Small-Sided Games</span>
        </div>
    </div>
</section>
