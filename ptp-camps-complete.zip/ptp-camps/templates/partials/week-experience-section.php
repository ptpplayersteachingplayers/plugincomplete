<?php
/**
 * Week Experience Section Partial - World Cup Format
 */

if (!defined('ABSPATH')) exit;
?>

<!-- WEEK EXPERIENCE -->
<section class="ptp-section ptp-bg-gray">
    <div class="ptp-section-header">
        <span class="ptp-label">Your Week</span>
        <h2 class="ptp-headline">World Cup <span>Format</span></h2>
    </div>
    <div class="ptp-week-grid">
        <div class="ptp-week-card">
            <div class="ptp-week-header">
                <span class="ptp-week-day">Monday</span>
                <span class="ptp-week-theme">Draft Day</span>
            </div>
            <div class="ptp-week-body">
                <span class="ptp-week-skill">FIRST TOUCH</span>
                <p class="ptp-week-focus">Get drafted to your country.</p>
                <p class="ptp-week-desc">Receiving, cushion control, turns under pressure.</p>
            </div>
        </div>
        <div class="ptp-week-card">
            <div class="ptp-week-header">
                <span class="ptp-week-day">Tuesday</span>
                <span class="ptp-week-theme">Group Stage</span>
            </div>
            <div class="ptp-week-body">
                <span class="ptp-week-skill">1v1 MOVES</span>
                <p class="ptp-week-focus">First tournament matches.</p>
                <p class="ptp-week-desc">Scissors, stepovers, body feints to beat defenders.</p>
            </div>
        </div>
        <div class="ptp-week-card">
            <div class="ptp-week-header">
                <span class="ptp-week-day">Wednesday</span>
                <span class="ptp-week-theme">Knockout</span>
            </div>
            <div class="ptp-week-body">
                <span class="ptp-week-skill">PASSING</span>
                <p class="ptp-week-focus">Win or go home.</p>
                <p class="ptp-week-desc">Wall passes, through balls, scanning before receiving.</p>
            </div>
        </div>
        <div class="ptp-week-card">
            <div class="ptp-week-header">
                <span class="ptp-week-day">Thursday</span>
                <span class="ptp-week-theme">Semi Finals</span>
            </div>
            <div class="ptp-week-body">
                <span class="ptp-week-skill">FINISHING</span>
                <p class="ptp-week-focus">Top 4 compete.</p>
                <p class="ptp-week-desc">Placement, power, composure in front of goal.</p>
            </div>
        </div>
        <div class="ptp-week-card highlight">
            <div class="ptp-week-header">
                <span class="ptp-week-day">Friday</span>
                <span class="ptp-week-theme">Finals</span>
            </div>
            <div class="ptp-week-body">
                <span class="ptp-week-skill">PRO DAY</span>
                <p class="ptp-week-focus">Championship + pro guest.</p>
                <p class="ptp-week-desc">Q&A with pro player. Awards ceremony.</p>
            </div>
        </div>
    </div>
</section>
