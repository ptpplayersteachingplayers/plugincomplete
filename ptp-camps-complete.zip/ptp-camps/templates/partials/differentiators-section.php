<?php
/**
 * Differentiators Section Partial
 * What makes PTP different
 */

if (!defined('ABSPATH')) exit;
?>

<!-- DIFFERENTIATORS -->
<section class="ptp-section ptp-bg-dark">
    <div class="ptp-section-header center">
        <span class="ptp-label">Why PTP</span>
        <h2 class="ptp-headline ptp-headline-white">Not Your Average <span>Camp</span></h2>
    </div>
    <div class="ptp-diff-grid">
        <div class="ptp-diff-card">
            <div class="ptp-diff-eyebrow">COACHES PLAY</div>
            <h3 class="ptp-diff-title">In the Game</h3>
            <p class="ptp-diff-desc">Our coaches are <strong>in the 3v3</strong>, playing alongside your kid—not standing on the sideline.</p>
        </div>
        <div class="ptp-diff-card">
            <div class="ptp-diff-eyebrow">REAL PLAYERS</div>
            <h3 class="ptp-diff-title">NCAA D1 Athletes</h3>
            <p class="ptp-diff-desc"><strong>Current and former</strong> Division 1 players who know what it takes to compete.</p>
        </div>
        <div class="ptp-diff-card">
            <div class="ptp-diff-eyebrow">SMALL GROUPS</div>
            <h3 class="ptp-diff-title">8:1 Ratio</h3>
            <p class="ptp-diff-desc">Your kid is <strong>known by name</strong>. Individual feedback every session.</p>
        </div>
        <div class="ptp-diff-card">
            <div class="ptp-diff-eyebrow">SKILL FOCUSED</div>
            <h3 class="ptp-diff-title">Real Development</h3>
            <p class="ptp-diff-desc"><strong>1v1 moves, finishing, first touch, passing combos</strong>—skills that transfer to games.</p>
        </div>
    </div>
</section>
