<?php
/**
 * Reels Section Partial
 * Video reels showcasing camp experience
 */

if (!defined('ABSPATH')) exit;
?>

<!-- VIDEO REELS -->
<section class="ptp-reels ptp-section" id="reelsSection">
    <div class="ptp-reels-header">
        <span class="ptp-label">See It In Action</span>
        <h2 class="ptp-headline ptp-headline-white">Real Camp <span>Moments</span></h2>
    </div>
    <div class="ptp-reels-grid">
        <!-- Reel 1 -->
        <div class="ptp-reel" data-reel-id="reel-1">
            <div class="ptp-reel-wrap">
                <video id="video-reel-1" poster="https://ptpsummercamps.com/wp-content/uploads/2025/09/eddy-davis-signing-jersey.jpg.jpg" preload="metadata" loop muted playsinline>
                    <source src="https://ptpsummercamps.com/wp-content/uploads/2025/11/EDDY-DAVIS-PTP.mp4" type="video/mp4">
                </video>
                <div class="ptp-reel-overlay">
                    <button class="ptp-reel-play" data-video-id="video-reel-1">
                        <svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                    </button>
                </div>
            </div>
            <p class="ptp-reel-caption">Pro Player Visit</p>
        </div>
        
        <!-- Reel 2 -->
        <div class="ptp-reel" data-reel-id="reel-2">
            <div class="ptp-reel-wrap">
                <video id="video-reel-2" preload="metadata" loop muted playsinline>
                    <source src="https://ptpsummercamps.com/wp-content/uploads/2025/11/REEL-2.mp4" type="video/mp4">
                </video>
                <div class="ptp-reel-overlay">
                    <button class="ptp-reel-play" data-video-id="video-reel-2">
                        <svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                    </button>
                </div>
            </div>
            <p class="ptp-reel-caption">3v3 Gameplay</p>
        </div>
        
        <!-- Reel 3 -->
        <div class="ptp-reel" data-reel-id="reel-3">
            <div class="ptp-reel-wrap">
                <video id="video-reel-3" preload="metadata" loop muted playsinline>
                    <source src="https://ptpsummercamps.com/wp-content/uploads/2025/11/REEL-3.mp4" type="video/mp4">
                </video>
                <div class="ptp-reel-overlay">
                    <button class="ptp-reel-play" data-video-id="video-reel-3">
                        <svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                    </button>
                </div>
            </div>
            <p class="ptp-reel-caption">Skill Training</p>
        </div>
        
        <!-- Reel 4 -->
        <div class="ptp-reel" data-reel-id="reel-4">
            <div class="ptp-reel-wrap">
                <video id="video-reel-4" preload="metadata" loop muted playsinline>
                    <source src="https://ptpsummercamps.com/wp-content/uploads/2025/11/REEL-4.mp4" type="video/mp4">
                </video>
                <div class="ptp-reel-overlay">
                    <button class="ptp-reel-play" data-video-id="video-reel-4">
                        <svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                    </button>
                </div>
            </div>
            <p class="ptp-reel-caption">World Cup Finals</p>
        </div>
    </div>
</section>
