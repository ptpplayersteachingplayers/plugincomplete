<?php
/**
 * Daily Schedule Section Partial
 */

if (!defined('ABSPATH')) exit;
?>

<!-- DAILY SCHEDULE -->
<section class="ptp-section ptp-bg-gray" id="scheduleSection">
    <div class="ptp-section-header">
        <span class="ptp-label">Typical Day</span>
        <h2 class="ptp-headline">Daily <span>Schedule</span></h2>
    </div>
    <div class="ptp-schedule-badge">
        <svg width="14" height="14" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clip-rule="evenodd"/></svg>
        9:00 AM - 3:00 PM
    </div>
    <div class="ptp-schedule-list">
        <div class="ptp-schedule-item">
            <div class="ptp-schedule-time">9:00 AM</div>
            <div class="ptp-schedule-content">
                <span class="ptp-schedule-tag ptp-tag-arrival">CHECK-IN</span>
                <div class="ptp-schedule-activity">Arrival & Warm-Up</div>
                <div class="ptp-schedule-desc">Dynamic stretching, ball mastery</div>
            </div>
        </div>
        <div class="ptp-schedule-item">
            <div class="ptp-schedule-time">9:30 AM</div>
            <div class="ptp-schedule-content">
                <span class="ptp-schedule-tag ptp-tag-skill">SKILL BLOCK</span>
                <div class="ptp-schedule-activity">Technical Training</div>
                <div class="ptp-schedule-desc">Skill of the day with coach demos</div>
            </div>
        </div>
        <div class="ptp-schedule-item">
            <div class="ptp-schedule-time">10:30 AM</div>
            <div class="ptp-schedule-content">
                <span class="ptp-schedule-tag ptp-tag-gameplay">GAMEPLAY</span>
                <div class="ptp-schedule-activity">3v3 / 4v4 Matches</div>
                <div class="ptp-schedule-desc">Coaches play with campers</div>
            </div>
        </div>
        <div class="ptp-schedule-item">
            <div class="ptp-schedule-time">11:15 AM</div>
            <div class="ptp-schedule-content">
                <span class="ptp-schedule-tag ptp-tag-break">BREAK</span>
                <div class="ptp-schedule-activity">Snack Time</div>
                <div class="ptp-schedule-desc">Water, snacks, rest in shade</div>
            </div>
        </div>
        <div class="ptp-schedule-item">
            <div class="ptp-schedule-time">11:30 AM</div>
            <div class="ptp-schedule-content">
                <span class="ptp-schedule-tag ptp-tag-tournament">TOURNAMENT</span>
                <div class="ptp-schedule-activity">World Cup Matches</div>
                <div class="ptp-schedule-desc">Country vs Country competition</div>
            </div>
        </div>
        <div class="ptp-schedule-item">
            <div class="ptp-schedule-time">12:30 PM</div>
            <div class="ptp-schedule-content">
                <span class="ptp-schedule-tag ptp-tag-lunch">LUNCH</span>
                <div class="ptp-schedule-activity">Lunch Break</div>
                <div class="ptp-schedule-desc">Bring your own lunch</div>
            </div>
        </div>
        <div class="ptp-schedule-item">
            <div class="ptp-schedule-time">1:15 PM</div>
            <div class="ptp-schedule-content">
                <span class="ptp-schedule-tag ptp-tag-skill">SKILL BLOCK</span>
                <div class="ptp-schedule-activity">Afternoon Skills</div>
                <div class="ptp-schedule-desc">Position-specific training</div>
            </div>
        </div>
        <div class="ptp-schedule-item">
            <div class="ptp-schedule-time">2:15 PM</div>
            <div class="ptp-schedule-content">
                <span class="ptp-schedule-tag ptp-tag-tournament">TOURNAMENT</span>
                <div class="ptp-schedule-activity">Final Matches</div>
                <div class="ptp-schedule-desc">Bracket play continues</div>
            </div>
        </div>
        <div class="ptp-schedule-item">
            <div class="ptp-schedule-time">3:00 PM</div>
            <div class="ptp-schedule-content">
                <span class="ptp-schedule-tag ptp-tag-pickup">PICKUP</span>
                <div class="ptp-schedule-activity">Dismissal</div>
                <div class="ptp-schedule-desc">Pick up at main entrance</div>
            </div>
        </div>
    </div>
</section>
