<?php
/**
 * Trust Bar Section Partial
 * Background checked, CPR certified, refund guarantee
 */

if (!defined('ABSPATH')) exit;
?>

<!-- TRUST BAR -->
<section class="ptp-trust">
    <div class="ptp-trust-item">
        <div class="ptp-trust-icon">
            <svg viewBox="0 0 20 20"><path fill-rule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>
        </div>
        <div class="ptp-trust-value">100%</div>
        <div class="ptp-trust-label">Background Checked</div>
    </div>
    <div class="ptp-trust-item">
        <div class="ptp-trust-icon">
            <svg viewBox="0 0 20 20"><path d="M10.394 2.08a1 1 0 00-.788 0l-7 3a1 1 0 000 1.84L5.25 8.051a.999.999 0 01.356-.257l4-1.714a1 1 0 11.788 1.838L7.667 9.088l1.94.831a1 1 0 00.787 0l7-3a1 1 0 000-1.838l-7-3zM3.31 9.397L5 10.12v4.102a8.969 8.969 0 00-1.05-.174 1 1 0 01-.89-.89 11.115 11.115 0 01.25-3.762z"/></svg>
        </div>
        <div class="ptp-trust-value">CPR</div>
        <div class="ptp-trust-label">Certified</div>
    </div>
    <div class="ptp-trust-item">
        <div class="ptp-trust-icon">
            <svg viewBox="0 0 20 20"><path fill-rule="evenodd" d="M4 4a2 2 0 00-2 2v4a2 2 0 002 2V6h10a2 2 0 00-2-2H4zm2 6a2 2 0 012-2h8a2 2 0 012 2v4a2 2 0 01-2 2H8a2 2 0 01-2-2v-4zm6 4a2 2 0 100-4 2 2 0 000 4z" clip-rule="evenodd"/></svg>
        </div>
        <div class="ptp-trust-value">14-Day</div>
        <div class="ptp-trust-label">Full Refund</div>
    </div>
</section>
