<?php
/**
 * Location Section Partial
 * Google Maps embed + address info
 */

if (!defined('ABSPATH')) exit;

// Get location data from post meta or use defaults
$product_id = get_the_ID();
$camp_location = get_post_meta($product_id, '_ptp_camp_location', true) ?: 'Radnor Memorial Park';
$camp_address = get_post_meta($product_id, '_ptp_camp_address', true) ?: 'Radnor, PA';
$camp_time = get_post_meta($product_id, '_ptp_camp_time', true) ?: '9:00 AM - 3:00 PM';
$camp_days = get_post_meta($product_id, '_ptp_camp_days', true) ?: 'Monday – Friday';
$google_maps_embed = get_post_meta($product_id, '_ptp_google_maps_embed', true);

// Default maps embed if not set
if (empty($google_maps_embed)) {
    $maps_query = urlencode($camp_location . ' ' . $camp_address);
    $google_maps_embed = "https://maps.google.com/maps?q={$maps_query}&t=&z=14&ie=UTF8&iwloc=&output=embed";
}
?>

<!-- LOCATION -->
<section class="ptp-section ptp-bg-gray" id="locationSection">
    <div class="ptp-section-header">
        <span class="ptp-label">Location</span>
        <h2 class="ptp-headline">Where to <span>Find Us</span></h2>
    </div>
    <div class="ptp-location-card">
        <div class="ptp-location-map">
            <iframe 
                src="<?php echo esc_url($google_maps_embed); ?>" 
                width="100%" 
                height="200" 
                style="border:0;" 
                allowfullscreen="" 
                loading="lazy"
                referrerpolicy="no-referrer-when-downgrade">
            </iframe>
        </div>
        <div class="ptp-location-info">
            <div class="ptp-location-row">
                <svg viewBox="0 0 20 20"><path fill-rule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clip-rule="evenodd"/></svg>
                <div>
                    <strong><?php echo esc_html($camp_location); ?></strong>
                    <span><?php echo esc_html($camp_address); ?></span>
                </div>
            </div>
            <div class="ptp-location-row">
                <svg viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clip-rule="evenodd"/></svg>
                <div>
                    <strong><?php echo esc_html($camp_time); ?></strong>
                    <span><?php echo esc_html($camp_days); ?></span>
                </div>
            </div>
            <div class="ptp-location-row">
                <svg viewBox="0 0 20 20"><path fill-rule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clip-rule="evenodd"/></svg>
                <div>
                    <strong>Drop-off</strong>
                    <span>8:45 AM - 9:00 AM</span>
                </div>
            </div>
            <div class="ptp-location-row">
                <svg viewBox="0 0 20 20"><path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z"/></svg>
                <div>
                    <strong>Questions?</strong>
                    <span><a href="tel:+14845724770">(484) 572-4770</a></span>
                </div>
            </div>
        </div>
        <a href="https://maps.google.com/?q=<?php echo urlencode($camp_location . ' ' . $camp_address); ?>" target="_blank" rel="noopener" class="ptp-location-btn">
            <svg viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clip-rule="evenodd"/></svg>
            Get Directions
        </a>
    </div>
</section>
