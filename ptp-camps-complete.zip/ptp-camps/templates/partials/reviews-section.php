<?php
/**
 * Reviews Section Partial
 * Parent testimonials with avatars
 */

if (!defined('ABSPATH')) exit;

// You can make these dynamic via custom fields or options
$reviews = array(
    array(
        'name' => 'Ben Prusky',
        'avatar' => 'https://ptpsummercamps.com/wp-content/uploads/2026/01/unnamed-2.webp',
        'text' => 'Coaches v kids scrimmage, then a talk with a live pro player. <strong>Amazing experience.</strong>',
        'rating' => 5
    ),
    array(
        'name' => 'J. Bunnell',
        'avatar' => 'https://ptpsummercamps.com/wp-content/uploads/2026/01/unnamed-3.webp',
        'text' => 'Small ratio = individual attention. Coaches are <strong>genuinely invested</strong> in every kid.',
        'rating' => 5
    ),
    array(
        'name' => 'Kelci Edwards-Graber',
        'avatar' => 'https://ptpsummercamps.com/wp-content/uploads/2026/01/unnamed.webp',
        'text' => 'Great time at the clinic. My son learned so much. <strong>We\'ll definitely be back!</strong>',
        'rating' => 5
    )
);

// Allow filtering reviews
$reviews = apply_filters('ptp_camps_reviews', $reviews);
?>

<!-- PARENT REVIEWS -->
<section class="ptp-section ptp-bg-white">
    <div class="ptp-section-header">
        <span class="ptp-label">Parent Reviews</span>
        <h2 class="ptp-headline">What Families <span>Say</span></h2>
    </div>
    <div class="ptp-reviews-grid">
        <?php foreach ($reviews as $review): ?>
        <div class="ptp-review">
            <div class="ptp-review-header">
                <img src="<?php echo esc_url($review['avatar']); ?>" alt="<?php echo esc_attr($review['name']); ?>" class="ptp-review-avatar">
                <div>
                    <div class="ptp-review-name"><?php echo esc_html($review['name']); ?></div>
                    <div class="ptp-review-stars"><?php echo str_repeat('★', $review['rating']); ?></div>
                </div>
            </div>
            <p class="ptp-review-text">"<?php echo wp_kses($review['text'], array('strong' => array(), 'em' => array())); ?>"</p>
        </div>
        <?php endforeach; ?>
    </div>
    <div class="ptp-reviews-more">
        <a href="<?php echo home_url('/reviews/'); ?>" class="ptp-reviews-link">View More Reviews →</a>
    </div>
</section>
