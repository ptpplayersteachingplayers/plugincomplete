<?php
/**
 * Coaches Section Partial
 */

if (!defined('ABSPATH')) exit;
?>

<!-- COACHES -->
<section class="ptp-section ptp-bg-dark" id="coachesSection">
    <div class="ptp-section-header center">
        <span class="ptp-label">The Team</span>
        <h2 class="ptp-headline ptp-headline-white">Meet Your <span>Coaches</span></h2>
    </div>
    <p class="ptp-coaches-note">NCAA D1 athletes who play with your kid, not just instruct.</p>
    <div class="ptp-coaches-grid">
        <div class="ptp-coach">
            <div class="ptp-coach-photo">
                <img src="https://ptpsummercamps.com/wp-content/uploads/2025/11/luke-coach.jpg" alt="Luke Martelli">
                <span class="ptp-coach-badge">FOUNDER</span>
            </div>
            <div class="ptp-coach-name">Luke M.</div>
            <div class="ptp-coach-school">Villanova</div>
        </div>
        <div class="ptp-coach">
            <div class="ptp-coach-photo">
                <img src="https://ptpsummercamps.com/wp-content/uploads/2025/11/coach-2.jpg" alt="Coach">
                <span class="ptp-coach-badge">D1 ATHLETE</span>
            </div>
            <div class="ptp-coach-name">Mike R.</div>
            <div class="ptp-coach-school">Penn State</div>
        </div>
        <div class="ptp-coach">
            <div class="ptp-coach-photo">
                <img src="https://ptpsummercamps.com/wp-content/uploads/2025/11/coach-3.jpg" alt="Coach">
                <span class="ptp-coach-badge">D1 ATHLETE</span>
            </div>
            <div class="ptp-coach-name">Jake T.</div>
            <div class="ptp-coach-school">Temple</div>
        </div>
        <div class="ptp-coach">
            <div class="ptp-coach-photo">
                <img src="https://ptpsummercamps.com/wp-content/uploads/2025/11/coach-4.jpg" alt="Coach">
                <span class="ptp-coach-badge">D1 ATHLETE</span>
            </div>
            <div class="ptp-coach-name">Chris D.</div>
            <div class="ptp-coach-school">Drexel</div>
        </div>
        <div class="ptp-coach">
            <div class="ptp-coach-photo">
                <img src="https://ptpsummercamps.com/wp-content/uploads/2025/11/coach-5.jpg" alt="Coach">
                <span class="ptp-coach-badge">D1 ATHLETE</span>
            </div>
            <div class="ptp-coach-name">Tom S.</div>
            <div class="ptp-coach-school">St. Joe's</div>
        </div>
        <div class="ptp-coach">
            <div class="ptp-coach-photo">
                <img src="https://ptpsummercamps.com/wp-content/uploads/2025/11/coach-6.jpg" alt="Coach">
                <span class="ptp-coach-badge">D1 ATHLETE</span>
            </div>
            <div class="ptp-coach-name">Dan K.</div>
            <div class="ptp-coach-school">La Salle</div>
        </div>
    </div>
</section>
