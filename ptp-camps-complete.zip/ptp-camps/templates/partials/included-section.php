<?php
/**
 * What's Included Section Partial
 * Checklist of camp inclusions + World Cup Jersey add-on
 */

if (!defined('ABSPATH')) exit;

// Get product ID for add-on
$product_id = get_the_ID();
?>

<!-- WHAT'S INCLUDED -->
<section class="ptp-section ptp-bg-gray">
    <div class="ptp-section-header">
        <span class="ptp-label">Everything Included</span>
        <h2 class="ptp-headline">What's <span>Included</span></h2>
    </div>
    <div class="ptp-included-list">
        <div class="ptp-included-item">
            <div class="ptp-included-check">
                <svg viewBox="0 0 20 20"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/></svg>
            </div>
            <span class="ptp-included-text">PTP Camp T-Shirt</span>
        </div>
        <div class="ptp-included-item">
            <div class="ptp-included-check">
                <svg viewBox="0 0 20 20"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/></svg>
            </div>
            <span class="ptp-included-text">Soccer Ball (Size 4 or 5)</span>
        </div>
        <div class="ptp-included-item">
            <div class="ptp-included-check">
                <svg viewBox="0 0 20 20"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/></svg>
            </div>
            <span class="ptp-included-text">5 Days of Expert Coaching</span>
        </div>
        <div class="ptp-included-item">
            <div class="ptp-included-check">
                <svg viewBox="0 0 20 20"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/></svg>
            </div>
            <span class="ptp-included-text">8:1 Camper to Coach Ratio</span>
        </div>
        <div class="ptp-included-item">
            <div class="ptp-included-check">
                <svg viewBox="0 0 20 20"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/></svg>
            </div>
            <span class="ptp-included-text">Daily Video Clips of Your Child</span>
        </div>
        <div class="ptp-included-item">
            <div class="ptp-included-check">
                <svg viewBox="0 0 20 20"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/></svg>
            </div>
            <span class="ptp-included-text">MVP Awards & Skill Prizes</span>
        </div>
        <div class="ptp-included-item">
            <div class="ptp-included-check">
                <svg viewBox="0 0 20 20"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/></svg>
            </div>
            <span class="ptp-included-text">Snacks & Hydration Provided</span>
        </div>
        <div class="ptp-included-item">
            <div class="ptp-included-check">
                <svg viewBox="0 0 20 20"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/></svg>
            </div>
            <span class="ptp-included-text">Friday Pro Player Visit</span>
        </div>
    </div>
    
    <!-- World Cup Jersey Add-On -->
    <div class="ptp-addon-section">
        <div class="ptp-addon-card">
            <div class="ptp-addon-check">
                <input type="checkbox" id="worldCupJersey" name="world_cup_jersey" data-price="25">
            </div>
            <div class="ptp-addon-info">
                <div class="ptp-addon-title">+ World Cup Country Jersey</div>
                <div class="ptp-addon-desc">Get drafted to a country and wear their jersey all week</div>
            </div>
            <div class="ptp-addon-price">+$25</div>
        </div>
    </div>
</section>
