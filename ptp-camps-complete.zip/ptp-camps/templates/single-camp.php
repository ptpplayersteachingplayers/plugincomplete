<?php
if (!defined('ABSPATH')) exit;
get_header();

$camp = PTP_Camps_Manager::get(get_the_ID());
$early_bird = ptp_camps_early_bird_data();
$all_camps = PTP_Camps_Manager::get_available_weeks();
?>
<!DOCTYPE html>
<html>
<head>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
</head>
<body class="ptp-camp-page">
<div class="ptp-camp-wrapper">
    <!-- Hero -->
    <section class="ptp-hero">
        <div class="ptp-hero-video">
            <?php if ($camp['video_url']): ?>
            <video autoplay muted loop playsinline>
                <source src="<?php echo esc_url($camp['video_url']); ?>" type="video/mp4">
            </video>
            <?php elseif ($camp['image']): ?>
            <img src="<?php echo esc_url($camp['image']); ?>" alt="<?php echo esc_attr($camp['title']); ?>">
            <?php endif; ?>
        </div>
        <div class="ptp-hero-content">
            <div class="ptp-hero-card">
                <div class="ptp-card-header">
                    <span class="ptp-badge"><?php echo $camp['sold_out'] ? 'SOLD OUT' : $camp['spots_left'] . ' SPOTS LEFT'; ?></span>
                    <h1><?php echo esc_html($camp['title']); ?></h1>
                    <p class="ptp-camp-meta"><?php echo esc_html($camp['date']); ?> • <?php echo esc_html($camp['location']); ?></p>
                </div>
                
                <?php if ($early_bird['active']): ?>
                <div class="ptp-early-bird">
                    <div class="ptp-countdown">
                        <span class="ptp-countdown-label">EARLY BIRD ENDS IN</span>
                        <span class="ptp-countdown-days"><?php echo $early_bird['days_left']; ?> DAYS</span>
                    </div>
                    <div class="ptp-pricing">
                        <span class="ptp-price-old">$<?php echo number_format($camp['price'], 0); ?></span>
                        <span class="ptp-price-new">$<?php echo number_format($camp['early_bird_price'], 0); ?></span>
                        <span class="ptp-save">SAVE $<?php echo $early_bird['discount']; ?></span>
                    </div>
                </div>
                <?php else: ?>
                <div class="ptp-pricing-single">
                    <span class="ptp-price-new">$<?php echo number_format($camp['price'], 0); ?></span>
                </div>
                <?php endif; ?>
                
                <div class="ptp-camp-details">
                    <div class="ptp-detail"><span class="ptp-detail-label">TIME</span><span><?php echo esc_html($camp['time']); ?></span></div>
                    <div class="ptp-detail"><span class="ptp-detail-label">AGES</span><span><?php echo esc_html($camp['ages']); ?></span></div>
                    <div class="ptp-detail"><span class="ptp-detail-label">LOCATION</span><span><?php echo esc_html($camp['address']); ?></span></div>
                </div>
                
                <?php if (!$camp['sold_out']): ?>
                <button class="ptp-btn-reserve" data-camp="<?php echo $camp['id']; ?>">RESERVE YOUR SPOT</button>
                <?php else: ?>
                <button class="ptp-btn-waitlist" data-camp="<?php echo $camp['id']; ?>">JOIN WAITLIST</button>
                <?php endif; ?>
            </div>
        </div>
    </section>
    
    <!-- Stats -->
    <section class="ptp-stats">
        <div class="ptp-stat"><span class="ptp-stat-value">500+</span><span class="ptp-stat-label">FAMILIES SERVED</span></div>
        <div class="ptp-stat"><span class="ptp-stat-value">8:1</span><span class="ptp-stat-label">CAMPER RATIO</span></div>
        <div class="ptp-stat"><span class="ptp-stat-value">D1</span><span class="ptp-stat-label">COLLEGE COACHES</span></div>
    </section>
    
    <!-- Multi-Week Selector -->
    <?php if (count($all_camps) > 1): ?>
    <section class="ptp-multi-week">
        <div class="ptp-section-header">
            <h2>BOOK MULTIPLE WEEKS & SAVE</h2>
            <p>10% off 2 weeks • 20% off 3+ weeks</p>
        </div>
        <div class="ptp-week-grid">
            <?php foreach ($all_camps as $c): ?>
            <label class="ptp-week-card <?php echo $c['id'] === $camp['id'] ? 'selected' : ''; ?>">
                <input type="checkbox" name="camp_ids[]" value="<?php echo $c['id']; ?>" <?php checked($c['id'], $camp['id']); ?>>
                <div class="ptp-week-info">
                    <span class="ptp-week-date"><?php echo esc_html($c['date']); ?></span>
                    <span class="ptp-week-location"><?php echo esc_html($c['location']); ?></span>
                </div>
                <span class="ptp-week-price">$<?php echo number_format($c['early_bird_price'], 0); ?></span>
                <span class="ptp-week-spots"><?php echo $c['spots_left']; ?> spots</span>
            </label>
            <?php endforeach; ?>
        </div>
        <div class="ptp-multi-total">
            <span class="ptp-total-label">Total:</span>
            <span class="ptp-total-amount">$<?php echo number_format($camp['early_bird_price'], 0); ?></span>
            <span class="ptp-total-savings"></span>
        </div>
        <button class="ptp-btn-checkout">CHECKOUT SELECTED WEEKS</button>
    </section>
    <?php endif; ?>
    
    <!-- What's Included -->
    <section class="ptp-included">
        <h2>WHAT'S INCLUDED</h2>
        <div class="ptp-included-grid">
            <div class="ptp-included-item">✓ World Cup Jersey</div>
            <div class="ptp-included-item">✓ Pro Training Sessions</div>
            <div class="ptp-included-item">✓ Small Group Coaching</div>
            <div class="ptp-included-item">✓ Daily Competitions</div>
            <div class="ptp-included-item">✓ Skills Assessment</div>
            <div class="ptp-included-item">✓ Certificate</div>
        </div>
    </section>
    
    <!-- Location -->
    <?php if ($camp['maps_embed']): ?>
    <section class="ptp-location">
        <h2>LOCATION</h2>
        <div class="ptp-map"><?php echo $camp['maps_embed']; ?></div>
        <p class="ptp-address"><?php echo esc_html($camp['address']); ?></p>
    </section>
    <?php endif; ?>
</div>

<!-- Sticky CTA -->
<div class="ptp-sticky-cta">
    <div class="ptp-sticky-info">
        <span class="ptp-sticky-price">$<?php echo number_format($camp['early_bird_price'], 0); ?></span>
        <span class="ptp-sticky-date"><?php echo esc_html($camp['date']); ?></span>
    </div>
    <button class="ptp-btn-reserve" data-camp="<?php echo $camp['id']; ?>">RESERVE SPOT</button>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Single reserve
    document.querySelectorAll('.ptp-btn-reserve').forEach(btn => {
        btn.addEventListener('click', function() {
            const campId = this.dataset.camp;
            fetch(ptpCamps.ajaxUrl, {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=ptp_add_to_cart&nonce=' + ptpCamps.nonce + '&camp_ids[]=' + campId
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) window.location = data.data.redirect;
            });
        });
    });
    
    // Multi-week checkout
    const checkoutBtn = document.querySelector('.ptp-btn-checkout');
    if (checkoutBtn) {
        checkoutBtn.addEventListener('click', function() {
            const selected = [...document.querySelectorAll('input[name="camp_ids[]"]:checked')].map(c => c.value);
            if (!selected.length) return alert('Select at least one week');
            
            fetch(ptpCamps.ajaxUrl, {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=ptp_add_to_cart&nonce=' + ptpCamps.nonce + '&' + selected.map(id => 'camp_ids[]=' + id).join('&')
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) window.location = data.data.redirect;
            });
        });
    }
    
    // Update totals on selection
    document.querySelectorAll('input[name="camp_ids[]"]').forEach(cb => {
        cb.addEventListener('change', updateTotals);
    });
    
    function updateTotals() {
        const selected = document.querySelectorAll('input[name="camp_ids[]"]:checked');
        const count = selected.length;
        const basePrice = <?php echo $camp['early_bird_price']; ?>;
        let subtotal = count * basePrice;
        let discount = 0;
        
        if (count >= 3) discount = subtotal * 0.20;
        else if (count >= 2) discount = subtotal * 0.10;
        
        const total = subtotal - discount;
        
        document.querySelector('.ptp-total-amount').textContent = '$' + total.toFixed(0);
        document.querySelector('.ptp-total-savings').textContent = discount > 0 ? 'Save $' + discount.toFixed(0) : '';
    }
});
</script>

<?php get_footer(); ?>
