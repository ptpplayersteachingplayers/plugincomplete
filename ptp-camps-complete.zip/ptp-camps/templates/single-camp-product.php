<?php
/**
 * PTP Camp Single Product Template
 * Complete Summer Camp Product Page
 * 
 * @version 2.0.0
 * @package PTP_Camps
 * 
 * Template for displaying individual summer camp product pages.
 * Integrates with WooCommerce products and PTP Training Platform.
 */

if (!defined('ABSPATH')) exit;

// Get product data
global $product;

if (!$product || !is_a($product, 'WC_Product')) {
    $product_id = get_the_ID();
    $product = wc_get_product($product_id);
}

if (!$product) {
    wp_redirect(home_url('/summer-camps/'));
    exit;
}

// Get product meta
$product_id = $product->get_id();
$price = $product->get_price();
$camp_date = get_post_meta($product_id, '_ptp_camp_date', true);
$camp_location = get_post_meta($product_id, '_ptp_camp_location', true);
$camp_address = get_post_meta($product_id, '_ptp_camp_address', true);
$camp_time = get_post_meta($product_id, '_ptp_camp_time', true) ?: '9:00 AM - 3:00 PM';
$camp_ages = get_post_meta($product_id, '_ptp_camp_ages', true) ?: '6-14';
$camp_video_url = get_post_meta($product_id, '_ptp_camp_video_url', true);
$camp_theme = get_post_meta($product_id, '_ptp_camp_theme', true) ?: 'World Cup 2026';
$spots_remaining = get_post_meta($product_id, '_ptp_spots_remaining', true) ?: 'Limited';
$google_maps_embed = get_post_meta($product_id, '_ptp_google_maps_embed', true);

// Get all available camp weeks for multi-week selector
$all_camps = ptp_camps_get_available_weeks();

// Checkout URL - use PTP checkout if available
$checkout_url = home_url('/ptp-checkout/');
if (!ptp_camps_has_training_platform()) {
    $checkout_url = wc_get_checkout_url();
}

// Check if we're in early bird period
$early_bird_active = ptp_camps_is_early_bird_active();
$early_bird_data = ptp_camps_get_early_bird_data();

get_header();
?>

<div id="ptp-camp-wrapper" 
     data-product-id="<?php echo esc_attr($product_id); ?>" 
     data-base-price="<?php echo esc_attr($price); ?>"
     data-checkout-url="<?php echo esc_url($checkout_url); ?>">
    
    <!-- HERO SECTION -->
    <section class="ptp-hero-two-col">
        <div class="ptp-hero-video-col">
            <?php if ($camp_video_url): ?>
            <video class="ptp-hero-video" id="heroVideo" autoplay muted loop playsinline>
                <source src="<?php echo esc_url($camp_video_url); ?>" type="video/mp4">
            </video>
            <?php else: ?>
            <video class="ptp-hero-video" id="heroVideo" autoplay muted loop playsinline>
                <source src="https://ptpsummercamps.com/wp-content/uploads/2026/01/PRODUCT-VIDEO.mp4" type="video/mp4">
            </video>
            <?php endif; ?>
            <div class="ptp-hero-overlay"></div>
            
            <div class="ptp-hero-top">
                <span class="ptp-hero-badge-top">
                    <svg width="12" height="12" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
                    5.0 · 50+ Reviews
                </span>
            </div>
            
            <button class="ptp-hero-sound-toggle" id="heroSoundToggle">
                <svg class="sound-off" viewBox="0 0 24 24"><path d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z"/></svg>
                <svg class="sound-on" viewBox="0 0 24 24"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/></svg>
            </button>
            
            <div class="ptp-hero-content-mobile">
                <span class="ptp-hero-badge">⚽ SUMMER 2026</span>
                <h1 class="ptp-hero-headline">Train With <span>D1 Athletes</span></h1>
                <p class="ptp-hero-sub">NCAA D1 coaches <strong>play alongside</strong> your kid.</p>
            </div>
        </div>
        
        <div class="ptp-hero-reserve-col">
            <div class="ptp-reserve-card">
                <span class="ptp-reserve-badge">⚽ SUMMER 2026</span>
                <h1 class="ptp-reserve-headline">Train With <span>D1 Athletes</span></h1>
                <p class="ptp-reserve-sub">NCAA D1 coaches <strong>play alongside</strong> your kid. Not from the sideline.</p>
                
                <div class="ptp-reserve-pills">
                    <span class="pill">
                        <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clip-rule="evenodd"/></svg>
                        <?php echo esc_html($camp_date); ?>
                    </span>
                    <span class="pill">
                        <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clip-rule="evenodd"/></svg>
                        <?php echo esc_html($camp_location); ?>
                    </span>
                    <span class="pill">Ages <?php echo esc_html($camp_ages); ?></span>
                </div>
                
                <?php if ($early_bird_active): ?>
                <div class="ptp-reserve-urgency">
                    <span>🔥 Early Bird: <strong>Save $<?php echo esc_html($early_bird_data['discount']); ?></strong></span>
                    <span class="ptp-urgency-timer" id="earlyBirdTimer"><?php echo esc_html($early_bird_data['days_left']); ?>d left</span>
                </div>
                <?php endif; ?>
                
                <div class="ptp-reserve-price">
                    <span class="ptp-price-amount">$<?php echo esc_html(number_format($price, 0)); ?></span>
                    <span class="ptp-price-per">/week</span>
                </div>
                
                <button id="heroCta" class="ptp-reserve-btn">RESERVE YOUR SPOT →</button>
                
                <div class="ptp-reserve-guarantee">
                    <svg viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>
                    14-Day Full Refund Guarantee
                </div>
            </div>
        </div>
    </section>
    
    <!-- QUICK NAV -->
    <nav class="ptp-quick-nav" id="quickNav">
        <div class="ptp-quick-nav-inner">
            <div class="ptp-quick-info">
                <div class="ptp-quick-item">
                    <svg width="12" height="12" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clip-rule="evenodd"/></svg>
                    <span><?php echo esc_html($camp_date); ?></span>
                </div>
                <div class="ptp-quick-item">
                    <svg width="12" height="12" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clip-rule="evenodd"/></svg>
                    <span><?php echo esc_html($camp_location); ?></span>
                </div>
                <div class="ptp-quick-item">
                    <svg width="12" height="12" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clip-rule="evenodd"/></svg>
                    <span><?php echo esc_html($camp_time); ?></span>
                </div>
                <div class="ptp-quick-item">Ages <?php echo esc_html($camp_ages); ?></div>
            </div>
            <div class="ptp-quick-links">
                <a href="#reelsSection" class="ptp-quick-link">Videos</a>
                <a href="#coachesSection" class="ptp-quick-link">Coaches</a>
                <a href="#scheduleSection" class="ptp-quick-link">Schedule</a>
                <a href="#pricing" class="ptp-quick-link ptp-quick-link-cta">Book Now</a>
            </div>
        </div>
    </nav>
    
    <!-- FOUNDER QUOTE -->
    <section class="ptp-mission">
        <img src="https://ptpsummercamps.com/wp-content/uploads/2025/11/BG7A5661.jpg" alt="Luke Martelli" class="ptp-founder-photo">
        <p class="ptp-mission-quote">"After two ACL injuries ended my playing career, I built the camp I wish I had as a kid—<span>what my teammates and I never got.</span>"</p>
        <p class="ptp-mission-author">
            <strong>Luke Martelli</strong>
            Villanova Soccer · PTP Founder
        </p>
    </section>
    
    <!-- STATS BAR -->
    <section class="ptp-stats">
        <div class="ptp-stat">
            <div class="ptp-stat-value">500+</div>
            <div class="ptp-stat-label">Families</div>
        </div>
        <div class="ptp-stat">
            <div class="ptp-stat-value">8:1</div>
            <div class="ptp-stat-label">Ratio</div>
        </div>
        <div class="ptp-stat">
            <div class="ptp-stat-value">D1</div>
            <div class="ptp-stat-label">Coaches</div>
        </div>
    </section>
    
    <?php 
    // Include additional sections as partials
    include PTP_CAMPS_PATH . 'templates/partials/reels-section.php';
    include PTP_CAMPS_PATH . 'templates/partials/differentiators-section.php';
    include PTP_CAMPS_PATH . 'templates/partials/gallery-section.php';
    include PTP_CAMPS_PATH . 'templates/partials/skills-section.php';
    include PTP_CAMPS_PATH . 'templates/partials/week-experience-section.php';
    include PTP_CAMPS_PATH . 'templates/partials/schedule-section.php';
    include PTP_CAMPS_PATH . 'templates/partials/coaches-section.php';
    include PTP_CAMPS_PATH . 'templates/partials/trust-section.php';
    include PTP_CAMPS_PATH . 'templates/partials/included-section.php';
    include PTP_CAMPS_PATH . 'templates/partials/reviews-section.php';
    include PTP_CAMPS_PATH . 'templates/partials/location-section.php';
    ?>
    
    <!-- PRICING / MULTI-WEEK SELECTOR -->
    <section class="ptp-section ptp-bg-gray" id="pricing">
        <div class="ptp-section-header center">
            <span class="ptp-label">Select Your Week(s)</span>
            <h2 class="ptp-headline">Book Your <span>Spot</span></h2>
        </div>
        
        <div class="ptp-week-selector" id="weekSelector">
            <?php if ($early_bird_active): ?>
            <div class="ptp-pricing-banner">
                🔥 Early Bird Special: <strong>Save $<?php echo esc_html($early_bird_data['discount']); ?>/week</strong> – Ends <?php echo esc_html($early_bird_data['deadline_formatted']); ?>
            </div>
            <?php endif; ?>
            
            <p class="ptp-selector-hint">Select multiple weeks to save more!</p>
            
            <div class="ptp-weeks-grid">
                <?php foreach ($all_camps as $camp): 
                    $is_current = ($camp['id'] == $product_id);
                    $camp_product = wc_get_product($camp['id']);
                    $camp_price = $camp_product ? $camp_product->get_price() : $price;
                ?>
                <label class="ptp-week-option">
                    <input type="checkbox" 
                           name="selected_weeks[]" 
                           value="<?php echo esc_attr($camp['id']); ?>"
                           <?php checked($is_current); ?>>
                    <div class="ptp-week-option-content">
                        <div class="ptp-week-option-name"><?php echo esc_html($camp['name']); ?></div>
                        <div class="ptp-week-option-date"><?php echo esc_html($camp['date']); ?></div>
                        <div class="ptp-week-option-location"><?php echo esc_html($camp['location']); ?></div>
                        <div class="ptp-week-option-time"><?php echo esc_html($camp['time']); ?></div>
                    </div>
                    <div class="ptp-week-option-price">$<?php echo esc_html(number_format($camp_price, 0)); ?></div>
                    <div class="ptp-week-option-check">
                        <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/></svg>
                    </div>
                </label>
                <?php endforeach; ?>
            </div>
            
            <div class="ptp-multi-week-discount">
                <span class="ptp-discount-row">2 Weeks: <strong>Save 10%</strong></span>
                <span class="ptp-discount-row">3+ Weeks: <strong>Save 20%</strong></span>
            </div>
            
            <div class="ptp-selection-summary">
                <span class="ptp-summary-count"><span id="weekCount">1</span> week(s) selected</span>
                <span class="ptp-summary-total">Total: <strong>$<span id="totalPrice"><?php echo esc_html(number_format($price, 0)); ?></span></strong></span>
            </div>
            
            <button id="checkoutBtn" class="ptp-checkout-btn">CONTINUE TO CHECKOUT →</button>
        </div>
    </section>
    
    <!-- FAQ SECTION -->
    <section class="ptp-section ptp-bg-white">
        <div class="ptp-section-header center">
            <span class="ptp-label">Questions?</span>
            <h2 class="ptp-headline">Frequently <span>Asked</span></h2>
        </div>
        <div class="ptp-faq-list" id="faqList">
            <div class="ptp-faq-item">
                <button class="ptp-faq-q" type="button" aria-expanded="false">
                    <span>What's included in the camp fee?</span>
                    <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"/></svg>
                </button>
                <div class="ptp-faq-a">
                    <strong>Everything</strong>: PTP camp t-shirt, daily snacks and water, end-of-week awards, professional instruction from NCAA D1 athletes, and access to our World Cup tournament format all week.
                </div>
            </div>
            <div class="ptp-faq-item">
                <button class="ptp-faq-q" type="button" aria-expanded="false">
                    <span>What should my child bring?</span>
                    <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"/></svg>
                </button>
                <div class="ptp-faq-a">
                    <strong>Cleats, shin guards, a soccer ball, water bottle, sunscreen, and a packed lunch.</strong> We provide snacks and water throughout the day.
                </div>
            </div>
            <div class="ptp-faq-item">
                <button class="ptp-faq-q" type="button" aria-expanded="false">
                    <span>What's the coach-to-camper ratio?</span>
                    <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"/></svg>
                </button>
                <div class="ptp-faq-a">
                    <strong>8:1</strong>. We keep groups small so every kid gets individual attention. Your child will be known by name and receive personal feedback.
                </div>
            </div>
            <div class="ptp-faq-item">
                <button class="ptp-faq-q" type="button" aria-expanded="false">
                    <span>What's your refund policy?</span>
                    <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"/></svg>
                </button>
                <div class="ptp-faq-a">
                    <strong>Full refund</strong> within 14 days of purchase, no questions asked. After that, we offer camp credit for future sessions.
                </div>
            </div>
            <div class="ptp-faq-item">
                <button class="ptp-faq-q" type="button" aria-expanded="false">
                    <span>Can I add a World Cup jersey?</span>
                    <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"/></svg>
                </button>
                <div class="ptp-faq-a">
                    Yes! The PTP camp shirt is included. World Cup country jerseys are available as an add-on at checkout for an additional fee.
                </div>
            </div>
            <div class="ptp-faq-item">
                <button class="ptp-faq-q" type="button" aria-expanded="false">
                    <span>Questions?</span>
                    <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"/></svg>
                </button>
                <div class="ptp-faq-a">
                    Text or call Luke directly: <strong>(484) 572-4770</strong>. Happy to answer anything.
                </div>
            </div>
        </div>
    </section>
    
    <!-- FINAL CTA -->
    <section class="ptp-final-cta">
        <h2 class="ptp-final-headline">Ready to <span>Level Up?</span></h2>
        <p class="ptp-final-sub">500+ families. NCAA D1 coaches. Real development.</p>
        <button class="ptp-final-btn" id="finalCta">
            RESERVE YOUR SPOT
            <span class="ptp-cta-price">$<?php echo esc_html(number_format($price, 0)); ?></span>
        </button>
        <p class="ptp-final-guarantee">
            <svg viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>
            14-Day Full Refund Guarantee
        </p>
    </section>
    
</div>

<!-- STICKY CTA BAR -->
<div class="ptp-sticky-cta" id="stickyCta">
    <div class="ptp-sticky-left">
        <span class="ptp-sticky-price" id="stickyPrice">$<?php echo esc_html(number_format($price, 0)); ?></span>
        <span class="ptp-sticky-date"><?php echo esc_html($camp_date); ?></span>
    </div>
    <button class="ptp-sticky-btn" id="stickyBtn">RESERVE</button>
</div>

<?php get_footer(); ?>
