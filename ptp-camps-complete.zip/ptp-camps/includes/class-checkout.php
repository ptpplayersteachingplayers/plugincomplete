<?php
if (!defined('ABSPATH')) exit;

class PTP_Camps_Checkout {
    
    public static function render_checkout() {
        // Check for success
        if (isset($_GET['success'])) {
            return self::render_success();
        }
        
        $cart = PTP_Camps_Cart::get();
        $totals = PTP_Camps_Cart::get_totals();
        
        ob_start();
        ?>
        <div class="ptp-checkout-page">
            <div class="ptp-checkout-container">
                <div class="ptp-checkout-main">
                    <h1>Complete Your Registration</h1>
                    
                    <?php if (empty($cart)): ?>
                        <div class="ptp-empty-cart">
                            <p>Your cart is empty.</p>
                            <a href="<?php echo get_post_type_archive_link('ptp_camp'); ?>" class="ptp-btn-primary">Browse Camps</a>
                        </div>
                    <?php else: ?>
                        
                        <div class="ptp-checkout-items">
                            <h2>Camp Weeks (<?php echo $totals['count']; ?>)</h2>
                            <?php foreach ($cart as $key => $item): 
                                $camp = PTP_Camps_Manager::get($item['camp_id']);
                                if (!$camp) continue;
                            ?>
                            <div class="ptp-checkout-item" data-key="<?php echo esc_attr($key); ?>">
                                <div class="item-info">
                                    <strong><?php echo esc_html($camp['title']); ?></strong>
                                    <span><?php echo esc_html($camp['date']); ?> &bull; <?php echo esc_html($camp['location']); ?></span>
                                </div>
                                <div class="item-price">$<?php echo number_format($camp['price'], 0); ?></div>
                                <button type="button" class="remove-item" data-key="<?php echo esc_attr($key); ?>">&times;</button>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <form id="ptp-checkout-form" class="ptp-checkout-form">
                            <h2>Parent/Guardian Information</h2>
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="parent_name">Full Name *</label>
                                    <input type="text" id="parent_name" name="parent_name" required>
                                </div>
                                <div class="form-group">
                                    <label for="parent_email">Email *</label>
                                    <input type="email" id="parent_email" name="parent_email" required>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="parent_phone">Phone *</label>
                                    <input type="tel" id="parent_phone" name="parent_phone" required>
                                </div>
                            </div>
                            
                            <h2>Camper Information</h2>
                            <?php $i = 1; foreach ($cart as $key => $item): 
                                $camp = PTP_Camps_Manager::get($item['camp_id']);
                                if (!$camp) continue;
                            ?>
                            <div class="camper-form" data-key="<?php echo esc_attr($key); ?>">
                                <h3>Camper #<?php echo $i; ?> - <?php echo esc_html($camp['title']); ?></h3>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label>Camper Name *</label>
                                        <input type="text" name="camper[<?php echo esc_attr($key); ?>][name]" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Age *</label>
                                        <input type="number" name="camper[<?php echo esc_attr($key); ?>][age]" min="4" max="18" required>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label>T-Shirt Size *</label>
                                        <select name="camper[<?php echo esc_attr($key); ?>][shirt]" required>
                                            <option value="">Select size</option>
                                            <option value="YS">Youth S</option>
                                            <option value="YM">Youth M</option>
                                            <option value="YL">Youth L</option>
                                            <option value="AS">Adult S</option>
                                            <option value="AM">Adult M</option>
                                            <option value="AL">Adult L</option>
                                            <option value="AXL">Adult XL</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label>Emergency Contact Name *</label>
                                        <input type="text" name="camper[<?php echo esc_attr($key); ?>][emergency_name]" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Emergency Phone *</label>
                                        <input type="tel" name="camper[<?php echo esc_attr($key); ?>][emergency_phone]" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Medical Notes / Allergies</label>
                                    <textarea name="camper[<?php echo esc_attr($key); ?>][medical]" rows="2" placeholder="Optional - list any allergies, medications, or medical conditions we should know about"></textarea>
                                </div>
                            </div>
                            <?php $i++; endforeach; ?>
                            
                            <h2>Payment</h2>
                            <div id="card-element"></div>
                            <div id="card-errors" class="ptp-error" role="alert"></div>
                            
                            <button type="submit" id="submit-payment" class="ptp-btn-primary ptp-btn-large">
                                <span class="btn-text">Pay $<span id="pay-amount"><?php echo number_format($totals['total'], 0); ?></span></span>
                                <span class="btn-loading" style="display: none;">Processing...</span>
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
                
                <?php if (!empty($cart)): ?>
                <div class="ptp-checkout-sidebar">
                    <div class="order-summary">
                        <h3>Order Summary</h3>
                        
                        <div class="summary-row">
                            <span><?php echo $totals['count']; ?> Camp Week(s)</span>
                            <span>$<?php echo number_format($totals['subtotal'], 0); ?></span>
                        </div>
                        
                        <?php if ($totals['early_bird_discount'] > 0): ?>
                        <div class="summary-row discount">
                            <span>Early Bird Discount</span>
                            <span>-$<?php echo number_format($totals['early_bird_discount'], 0); ?></span>
                        </div>
                        <?php endif; ?>
                        
                        <?php if ($totals['multi_week_discount'] > 0): ?>
                        <div class="summary-row discount">
                            <span>Multi-Week Discount</span>
                            <span>-$<?php echo number_format($totals['multi_week_discount'], 0); ?></span>
                        </div>
                        <?php endif; ?>
                        
                        <div id="coupon-discount-row" class="summary-row discount" style="<?php echo $totals['coupon_discount'] > 0 ? '' : 'display:none;'; ?>">
                            <span>Coupon (<span id="coupon-code-display"><?php echo esc_html($totals['coupon_code']); ?></span>)</span>
                            <span>-$<span id="coupon-discount-amount"><?php echo number_format($totals['coupon_discount'], 0); ?></span></span>
                        </div>
                        
                        <div class="summary-row total">
                            <span>Total</span>
                            <span>$<span id="order-total"><?php echo number_format($totals['total'], 0); ?></span></span>
                        </div>
                        
                        <!-- Coupon Code -->
                        <div class="coupon-section">
                            <div id="coupon-form" style="<?php echo $totals['coupon_code'] ? 'display:none;' : ''; ?>">
                                <div class="coupon-input-wrap">
                                    <input type="text" id="coupon-code" placeholder="Coupon code">
                                    <button type="button" id="apply-coupon" class="ptp-btn-secondary">Apply</button>
                                </div>
                                <div id="coupon-error" class="ptp-error" style="display:none;"></div>
                            </div>
                            <div id="coupon-applied" style="<?php echo $totals['coupon_code'] ? '' : 'display:none;'; ?>">
                                <span class="coupon-badge"><?php echo esc_html($totals['coupon_code']); ?></span>
                                <button type="button" id="remove-coupon" class="remove-coupon">&times; Remove</button>
                            </div>
                        </div>
                    </div>
                    
                    <div class="trust-badges">
                        <div class="trust-item">
                            <span class="dashicons dashicons-lock"></span>
                            <span>Secure checkout</span>
                        </div>
                        <div class="trust-item">
                            <span class="dashicons dashicons-shield"></span>
                            <span>100% money back guarantee</span>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <script>
        (function() {
            var stripe = Stripe(ptpCamps.stripeKey);
            var elements = stripe.elements();
            var cardElement = elements.create('card', {
                style: {
                    base: {
                        fontSize: '16px',
                        color: '#0A0A0A',
                        '::placeholder': { color: '#999' }
                    }
                }
            });
            
            var cardEl = document.getElementById('card-element');
            if (cardEl) {
                cardElement.mount('#card-element');
            }
            
            cardElement.on('change', function(event) {
                var errEl = document.getElementById('card-errors');
                errEl.textContent = event.error ? event.error.message : '';
            });
            
            // Form submission
            var form = document.getElementById('ptp-checkout-form');
            if (form) {
                form.addEventListener('submit', async function(e) {
                    e.preventDefault();
                    
                    var btn = document.getElementById('submit-payment');
                    btn.disabled = true;
                    btn.querySelector('.btn-text').style.display = 'none';
                    btn.querySelector('.btn-loading').style.display = 'inline';
                    
                    try {
                        // Collect form data
                        var formData = new FormData(form);
                        formData.append('action', 'ptp_create_payment');
                        formData.append('nonce', ptpCamps.nonce);
                        
                        // Create payment intent
                        var response = await fetch(ptpCamps.ajaxUrl, {
                            method: 'POST',
                            body: formData,
                            credentials: 'same-origin'
                        });
                        var data = await response.json();
                        
                        if (!data.success) {
                            throw new Error(data.data || 'Payment failed');
                        }
                        
                        // Confirm with Stripe
                        var result = await stripe.confirmCardPayment(data.data.clientSecret, {
                            payment_method: { card: cardElement }
                        });
                        
                        if (result.error) {
                            throw new Error(result.error.message);
                        }
                        
                        // Confirm booking
                        var confirmData = new FormData();
                        confirmData.append('action', 'ptp_confirm_booking');
                        confirmData.append('nonce', ptpCamps.nonce);
                        confirmData.append('payment_intent', result.paymentIntent.id);
                        
                        var confirmResponse = await fetch(ptpCamps.ajaxUrl, {
                            method: 'POST',
                            body: confirmData,
                            credentials: 'same-origin'
                        });
                        var confirmResult = await confirmResponse.json();
                        
                        if (confirmResult.success) {
                            window.location.href = ptpCamps.checkoutUrl + '?success=1';
                        } else {
                            throw new Error(confirmResult.data || 'Booking confirmation failed');
                        }
                        
                    } catch (err) {
                        document.getElementById('card-errors').textContent = err.message;
                        btn.disabled = false;
                        btn.querySelector('.btn-text').style.display = 'inline';
                        btn.querySelector('.btn-loading').style.display = 'none';
                    }
                });
            }
            
            // Remove item
            document.querySelectorAll('.remove-item').forEach(function(btn) {
                btn.addEventListener('click', function() {
                    var key = this.dataset.key;
                    fetch(ptpCamps.ajaxUrl, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: 'action=ptp_remove_from_cart&nonce=' + ptpCamps.nonce + '&key=' + key,
                        credentials: 'same-origin'
                    }).then(function() {
                        window.location.reload();
                    });
                });
            });
            
            // Apply coupon
            var applyCouponBtn = document.getElementById('apply-coupon');
            if (applyCouponBtn) {
                applyCouponBtn.addEventListener('click', function() {
                    var code = document.getElementById('coupon-code').value.trim();
                    if (!code) return;
                    
                    this.disabled = true;
                    this.textContent = '...';
                    
                    fetch(ptpCamps.ajaxUrl, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: 'action=ptp_apply_coupon&nonce=' + ptpCamps.nonce + '&code=' + encodeURIComponent(code),
                        credentials: 'same-origin'
                    })
                    .then(function(r) { return r.json(); })
                    .then(function(data) {
                        if (data.success) {
                            updateTotals(data.data.totals);
                            document.getElementById('coupon-form').style.display = 'none';
                            document.getElementById('coupon-applied').style.display = 'flex';
                            document.querySelector('.coupon-badge').textContent = data.data.coupon.code;
                            document.getElementById('coupon-error').style.display = 'none';
                        } else {
                            document.getElementById('coupon-error').textContent = data.data.message;
                            document.getElementById('coupon-error').style.display = 'block';
                        }
                        applyCouponBtn.disabled = false;
                        applyCouponBtn.textContent = 'Apply';
                    });
                });
            }
            
            // Remove coupon
            var removeCouponBtn = document.getElementById('remove-coupon');
            if (removeCouponBtn) {
                removeCouponBtn.addEventListener('click', function() {
                    fetch(ptpCamps.ajaxUrl, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: 'action=ptp_remove_coupon&nonce=' + ptpCamps.nonce,
                        credentials: 'same-origin'
                    })
                    .then(function(r) { return r.json(); })
                    .then(function(data) {
                        if (data.success) {
                            updateTotals(data.data.totals);
                            document.getElementById('coupon-form').style.display = 'block';
                            document.getElementById('coupon-applied').style.display = 'none';
                            document.getElementById('coupon-code').value = '';
                        }
                    });
                });
            }
            
            function updateTotals(totals) {
                document.getElementById('order-total').textContent = Math.round(totals.total).toLocaleString();
                document.getElementById('pay-amount').textContent = Math.round(totals.total).toLocaleString();
                
                var couponRow = document.getElementById('coupon-discount-row');
                if (totals.coupon_discount > 0) {
                    couponRow.style.display = 'flex';
                    document.getElementById('coupon-code-display').textContent = totals.coupon_code;
                    document.getElementById('coupon-discount-amount').textContent = Math.round(totals.coupon_discount);
                } else {
                    couponRow.style.display = 'none';
                }
            }
        })();
        </script>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render success page
     */
    private static function render_success() {
        ob_start();
        ?>
        <div class="ptp-checkout-page">
            <div class="ptp-checkout-success">
                <div class="success-icon">✓</div>
                <h1>You're Registered!</h1>
                <p>Thank you for registering for PTP Soccer Camp. A confirmation email has been sent to your email address.</p>
                <div class="success-next-steps">
                    <h3>What's Next?</h3>
                    <ul>
                        <li>Check your email for confirmation details</li>
                        <li>Mark your calendar with camp dates</li>
                        <li>Pack cleats, shin guards, and water</li>
                        <li>Get ready for an amazing camp experience!</li>
                    </ul>
                </div>
                <a href="<?php echo home_url(); ?>" class="ptp-btn-primary">Back to Home</a>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}
