<?php
if (!defined('ABSPATH')) exit;

class PTP_Camps_Woo_Import {
    
    public function __construct() {
        add_action('admin_menu', array($this, 'add_import_menu'));
        add_action('wp_ajax_ptp_import_woo_products', array($this, 'ajax_import_products'));
        add_action('wp_ajax_ptp_import_woo_orders', array($this, 'ajax_import_orders'));
        add_action('wp_ajax_ptp_get_import_preview', array($this, 'ajax_get_preview'));
    }
    
    public function add_import_menu() {
        add_submenu_page(
            'edit.php?post_type=ptp_camp',
            'Import from WooCommerce',
            'Import Data',
            'manage_options',
            'ptp-woo-import',
            array($this, 'render_import_page')
        );
    }
    
    public function render_import_page() {
        $woo_active = class_exists('WooCommerce');
        ?>
        <div class="wrap ptp-import-wrap">
            <style>
                .ptp-import-wrap { max-width: 900px; }
                .ptp-import-card { background: #fff; border: 1px solid #c3c4c7; padding: 24px; margin-bottom: 20px; }
                .ptp-import-card h2 { margin-top: 0; padding-bottom: 12px; border-bottom: 1px solid #eee; display: flex; align-items: center; gap: 10px; }
                .ptp-import-card h2 .dashicons { color: #FCB900; }
                .ptp-stats { display: flex; gap: 20px; margin: 16px 0; }
                .ptp-stat { background: #f6f7f7; padding: 16px 20px; border-radius: 4px; flex: 1; }
                .ptp-stat-value { font-size: 28px; font-weight: 600; color: #1d2327; }
                .ptp-stat-label { color: #646970; font-size: 13px; margin-top: 4px; }
                .ptp-import-btn { background: #0A0A0A !important; color: #FCB900 !important; border: 2px solid #FCB900 !important; padding: 10px 24px !important; font-weight: 600 !important; text-transform: uppercase !important; }
                .ptp-import-btn:hover { background: #FCB900 !important; color: #0A0A0A !important; }
                .ptp-import-btn:disabled { opacity: 0.5; cursor: not-allowed; }
                .ptp-progress { display: none; margin-top: 16px; }
                .ptp-progress-bar { height: 24px; background: #f0f0f0; border-radius: 4px; overflow: hidden; }
                .ptp-progress-fill { height: 100%; background: #FCB900; width: 0%; transition: width 0.3s; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: 600; }
                .ptp-log { background: #1d2327; color: #fff; padding: 16px; max-height: 200px; overflow-y: auto; font-family: monospace; font-size: 12px; margin-top: 12px; display: none; border-radius: 4px; }
                .ptp-log .success { color: #00d084; }
                .ptp-log .error { color: #ff6b6b; }
                .ptp-log .info { color: #FCB900; }
                .ptp-warning { background: #fcf0f0; border-left: 4px solid #d63638; padding: 12px 16px; margin-bottom: 16px; }
                .ptp-success { background: #edfaef; border-left: 4px solid #00a32a; padding: 12px 16px; margin-bottom: 16px; }
                .ptp-preview-table { width: 100%; border-collapse: collapse; margin-top: 16px; font-size: 13px; }
                .ptp-preview-table th, .ptp-preview-table td { padding: 10px; text-align: left; border-bottom: 1px solid #eee; }
                .ptp-preview-table th { background: #f6f7f7; font-weight: 600; }
                .ptp-mapping-row { display: flex; align-items: center; gap: 12px; padding: 8px 0; border-bottom: 1px solid #f0f0f0; }
                .ptp-mapping-arrow { color: #FCB900; }
                .ptp-checkbox-list { max-height: 300px; overflow-y: auto; border: 1px solid #ddd; padding: 12px; margin: 12px 0; }
                .ptp-checkbox-item { padding: 8px; border-bottom: 1px solid #f5f5f5; display: flex; align-items: center; gap: 10px; }
                .ptp-checkbox-item:last-child { border-bottom: none; }
                .ptp-checkbox-item label { flex: 1; cursor: pointer; }
                .ptp-checkbox-item .meta { color: #666; font-size: 12px; }
            </style>
            
            <h1><span class="dashicons dashicons-database-import" style="font-size: 30px; color: #FCB900;"></span> Import from WooCommerce</h1>
            
            <?php if (!$woo_active): ?>
            <div class="ptp-warning">
                <strong>WooCommerce Not Active</strong><br>
                WooCommerce must be active to import data. Please activate WooCommerce temporarily if needed.
            </div>
            <?php endif; ?>
            
            <!-- Products Import -->
            <div class="ptp-import-card">
                <h2><span class="dashicons dashicons-products"></span> Import Products as Camps</h2>
                <p>Convert WooCommerce products into PTP Camp posts. This will map product data to camp fields.</p>
                
                <div class="ptp-stats">
                    <div class="ptp-stat">
                        <div class="ptp-stat-value" id="woo-product-count"><?php echo $this->count_woo_products(); ?></div>
                        <div class="ptp-stat-label">WooCommerce Products</div>
                    </div>
                    <div class="ptp-stat">
                        <div class="ptp-stat-value" id="ptp-camp-count"><?php echo wp_count_posts('ptp_camp')->publish; ?></div>
                        <div class="ptp-stat-label">Existing PTP Camps</div>
                    </div>
                </div>
                
                <div id="product-select-area">
                    <h4>Select Products to Import:</h4>
                    <p><label><input type="checkbox" id="select-all-products"> Select All</label></p>
                    <div class="ptp-checkbox-list" id="product-list">
                        <?php $this->render_product_list(); ?>
                    </div>
                </div>
                
                <div style="margin-top: 16px;">
                    <button type="button" class="button ptp-import-btn" id="import-products-btn" <?php echo !$woo_active ? 'disabled' : ''; ?>>
                        <span class="dashicons dashicons-download" style="margin-top: 3px;"></span> Import Selected Products
                    </button>
                </div>
                
                <div class="ptp-progress" id="products-progress">
                    <div class="ptp-progress-bar"><div class="ptp-progress-fill"></div></div>
                </div>
                <div class="ptp-log" id="products-log"></div>
            </div>
            
            <!-- Orders Import -->
            <div class="ptp-import-card">
                <h2><span class="dashicons dashicons-cart"></span> Import Orders as Bookings</h2>
                <p>Convert WooCommerce orders into PTP Camp bookings. Orders will be matched to camps by product ID mapping.</p>
                
                <div class="ptp-stats">
                    <div class="ptp-stat">
                        <div class="ptp-stat-value" id="woo-order-count"><?php echo $this->count_woo_orders(); ?></div>
                        <div class="ptp-stat-label">WooCommerce Orders</div>
                    </div>
                    <div class="ptp-stat">
                        <div class="ptp-stat-value" id="ptp-booking-count"><?php echo $this->count_ptp_bookings(); ?></div>
                        <div class="ptp-stat-label">Existing PTP Bookings</div>
                    </div>
                </div>
                
                <h4>Product → Camp Mapping:</h4>
                <p style="color: #666; font-size: 13px;">Products will be matched to camps by title or you can set manual mappings below.</p>
                <div id="mapping-area">
                    <?php $this->render_product_mapping(); ?>
                </div>
                
                <div style="margin-top: 16px;">
                    <label style="margin-right: 20px;">
                        <input type="checkbox" id="skip-existing-orders" checked> Skip already imported orders
                    </label>
                    <label>
                        <input type="checkbox" id="import-all-statuses"> Include non-completed orders
                    </label>
                </div>
                
                <div style="margin-top: 16px;">
                    <button type="button" class="button ptp-import-btn" id="import-orders-btn" <?php echo !$woo_active ? 'disabled' : ''; ?>>
                        <span class="dashicons dashicons-download" style="margin-top: 3px;"></span> Import Orders as Bookings
                    </button>
                </div>
                
                <div class="ptp-progress" id="orders-progress">
                    <div class="ptp-progress-bar"><div class="ptp-progress-fill"></div></div>
                </div>
                <div class="ptp-log" id="orders-log"></div>
            </div>
            
            <!-- Field Mapping Reference -->
            <div class="ptp-import-card">
                <h2><span class="dashicons dashicons-editor-table"></span> Field Mapping Reference</h2>
                <table class="ptp-preview-table">
                    <tr><th>WooCommerce Field</th><th></th><th>PTP Camp Field</th></tr>
                    <tr><td>Product Title</td><td class="ptp-mapping-arrow">→</td><td>Camp Title</td></tr>
                    <tr><td>Product Description</td><td class="ptp-mapping-arrow">→</td><td>Camp Description</td></tr>
                    <tr><td>Regular Price</td><td class="ptp-mapping-arrow">→</td><td>_camp_price</td></tr>
                    <tr><td>Featured Image</td><td class="ptp-mapping-arrow">→</td><td>Featured Image</td></tr>
                    <tr><td>_camp_date (meta)</td><td class="ptp-mapping-arrow">→</td><td>_camp_date</td></tr>
                    <tr><td>_camp_location (meta)</td><td class="ptp-mapping-arrow">→</td><td>_camp_location</td></tr>
                    <tr><td>_camp_time (meta)</td><td class="ptp-mapping-arrow">→</td><td>_camp_time</td></tr>
                    <tr><td>Stock Quantity</td><td class="ptp-mapping-arrow">→</td><td>_camp_capacity</td></tr>
                </table>
                
                <h4 style="margin-top: 24px;">Order → Booking Mapping:</h4>
                <table class="ptp-preview-table">
                    <tr><th>WooCommerce Order Field</th><th></th><th>PTP Booking Field</th></tr>
                    <tr><td>Billing Email</td><td class="ptp-mapping-arrow">→</td><td>customer_email</td></tr>
                    <tr><td>Billing Name</td><td class="ptp-mapping-arrow">→</td><td>customer_name</td></tr>
                    <tr><td>Billing Phone</td><td class="ptp-mapping-arrow">→</td><td>customer_phone</td></tr>
                    <tr><td>Order Total</td><td class="ptp-mapping-arrow">→</td><td>amount_paid</td></tr>
                    <tr><td>Order Status</td><td class="ptp-mapping-arrow">→</td><td>status (mapped)</td></tr>
                    <tr><td>Transaction ID</td><td class="ptp-mapping-arrow">→</td><td>stripe_payment_id</td></tr>
                    <tr><td>Camper Name (meta)</td><td class="ptp-mapping-arrow">→</td><td>camper_name</td></tr>
                    <tr><td>Camper Age (meta)</td><td class="ptp-mapping-arrow">→</td><td>camper_age</td></tr>
                </table>
            </div>
            
            <script>
            jQuery(function($) {
                // Select all products
                $('#select-all-products').on('change', function() {
                    $('.product-checkbox').prop('checked', this.checked);
                });
                
                // Import Products
                $('#import-products-btn').on('click', function() {
                    var selected = $('.product-checkbox:checked').map(function() { return this.value; }).get();
                    if (selected.length === 0) {
                        alert('Please select at least one product to import.');
                        return;
                    }
                    
                    var btn = $(this);
                    var progress = $('#products-progress');
                    var log = $('#products-log');
                    
                    btn.prop('disabled', true).text('Importing...');
                    progress.show();
                    log.show().empty();
                    
                    importProducts(selected, 0, log, progress, function() {
                        btn.prop('disabled', false).html('<span class="dashicons dashicons-download" style="margin-top: 3px;"></span> Import Selected Products');
                        log.append('<div class="success">✓ Import complete!</div>');
                        location.reload();
                    });
                });
                
                function importProducts(ids, index, log, progress, callback) {
                    if (index >= ids.length) {
                        progress.find('.ptp-progress-fill').css('width', '100%').text('100%');
                        callback();
                        return;
                    }
                    
                    var pct = Math.round((index / ids.length) * 100);
                    progress.find('.ptp-progress-fill').css('width', pct + '%').text(pct + '%');
                    
                    $.post(ajaxurl, {
                        action: 'ptp_import_woo_products',
                        nonce: '<?php echo wp_create_nonce('ptp_import'); ?>',
                        product_id: ids[index]
                    }, function(res) {
                        if (res.success) {
                            log.append('<div class="success">✓ ' + res.data.message + '</div>');
                        } else {
                            log.append('<div class="error">✗ ' + res.data.message + '</div>');
                        }
                        log.scrollTop(log[0].scrollHeight);
                        importProducts(ids, index + 1, log, progress, callback);
                    });
                }
                
                // Import Orders
                $('#import-orders-btn').on('click', function() {
                    var btn = $(this);
                    var progress = $('#orders-progress');
                    var log = $('#orders-log');
                    var skipExisting = $('#skip-existing-orders').is(':checked');
                    var allStatuses = $('#import-all-statuses').is(':checked');
                    
                    // Get mappings
                    var mappings = {};
                    $('.camp-mapping-select').each(function() {
                        var prodId = $(this).data('product-id');
                        var campId = $(this).val();
                        if (campId) mappings[prodId] = campId;
                    });
                    
                    btn.prop('disabled', true).text('Importing...');
                    progress.show();
                    log.show().empty();
                    log.append('<div class="info">⟳ Fetching orders...</div>');
                    
                    $.post(ajaxurl, {
                        action: 'ptp_import_woo_orders',
                        nonce: '<?php echo wp_create_nonce('ptp_import'); ?>',
                        skip_existing: skipExisting ? 1 : 0,
                        all_statuses: allStatuses ? 1 : 0,
                        mappings: JSON.stringify(mappings)
                    }, function(res) {
                        if (res.success) {
                            $.each(res.data.logs, function(i, entry) {
                                log.append('<div class="' + entry.type + '">' + (entry.type === 'success' ? '✓' : entry.type === 'error' ? '✗' : '•') + ' ' + entry.message + '</div>');
                            });
                            progress.find('.ptp-progress-fill').css('width', '100%').text('100%');
                            log.append('<div class="success">✓ Imported ' + res.data.imported + ' bookings</div>');
                        } else {
                            log.append('<div class="error">✗ ' + res.data.message + '</div>');
                        }
                        btn.prop('disabled', false).html('<span class="dashicons dashicons-download" style="margin-top: 3px;"></span> Import Orders as Bookings');
                        log.scrollTop(log[0].scrollHeight);
                    });
                });
            });
            </script>
        </div>
        <?php
    }
    
    private function count_woo_products() {
        if (!class_exists('WooCommerce')) return '—';
        $count = wp_count_posts('product');
        return $count->publish ?? 0;
    }
    
    private function count_woo_orders() {
        if (!class_exists('WooCommerce')) return '—';
        return wc_orders_count('completed') + wc_orders_count('processing');
    }
    
    private function count_ptp_bookings() {
        global $wpdb;
        return (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ptp_camp_bookings");
    }
    
    private function render_product_list() {
        if (!class_exists('WooCommerce')) {
            echo '<p style="color: #666;">WooCommerce not active</p>';
            return;
        }
        
        $products = wc_get_products(array('limit' => -1, 'status' => 'publish'));
        
        if (empty($products)) {
            echo '<p style="color: #666;">No products found</p>';
            return;
        }
        
        // Check which are already imported
        global $wpdb;
        $imported = $wpdb->get_col("SELECT meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_imported_woo_product_id'");
        
        foreach ($products as $product) {
            $already = in_array($product->get_id(), $imported);
            $price = $product->get_regular_price();
            ?>
            <div class="ptp-checkbox-item">
                <input type="checkbox" class="product-checkbox" value="<?php echo $product->get_id(); ?>" id="prod-<?php echo $product->get_id(); ?>" <?php echo $already ? 'disabled' : ''; ?>>
                <label for="prod-<?php echo $product->get_id(); ?>">
                    <strong><?php echo esc_html($product->get_name()); ?></strong>
                    <?php if ($already): ?><span style="color: #00a32a; font-size: 11px;">(already imported)</span><?php endif; ?>
                    <div class="meta">
                        ID: <?php echo $product->get_id(); ?> 
                        | Price: $<?php echo $price ? number_format($price, 2) : '—'; ?>
                        | Stock: <?php echo $product->get_stock_quantity() ?? 'Unlimited'; ?>
                    </div>
                </label>
            </div>
            <?php
        }
    }
    
    private function render_product_mapping() {
        if (!class_exists('WooCommerce')) {
            echo '<p style="color: #666;">WooCommerce not active</p>';
            return;
        }
        
        $products = wc_get_products(array('limit' => -1, 'status' => 'publish'));
        $camps = get_posts(array('post_type' => 'ptp_camp', 'posts_per_page' => -1, 'post_status' => 'publish'));
        
        if (empty($products)) {
            echo '<p style="color: #666;">No products to map</p>';
            return;
        }
        
        echo '<table class="ptp-preview-table">';
        echo '<tr><th>WooCommerce Product</th><th></th><th>PTP Camp</th></tr>';
        
        foreach ($products as $product) {
            $product_name = $product->get_name();
            $matched_camp = null;
            
            // Try to auto-match by title
            foreach ($camps as $camp) {
                if (strtolower($camp->post_title) === strtolower($product_name) || 
                    strpos(strtolower($camp->post_title), strtolower($product_name)) !== false ||
                    strpos(strtolower($product_name), strtolower($camp->post_title)) !== false) {
                    $matched_camp = $camp->ID;
                    break;
                }
            }
            
            // Also check if there's a stored mapping
            global $wpdb;
            $stored_camp = $wpdb->get_var($wpdb->prepare(
                "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_imported_woo_product_id' AND meta_value = %d",
                $product->get_id()
            ));
            if ($stored_camp) $matched_camp = $stored_camp;
            
            ?>
            <tr>
                <td><?php echo esc_html($product_name); ?> <span style="color:#999;">(#<?php echo $product->get_id(); ?>)</span></td>
                <td class="ptp-mapping-arrow">→</td>
                <td>
                    <select class="camp-mapping-select" data-product-id="<?php echo $product->get_id(); ?>" style="width: 100%;">
                        <option value="">— Select Camp —</option>
                        <?php foreach ($camps as $camp): ?>
                        <option value="<?php echo $camp->ID; ?>" <?php selected($matched_camp, $camp->ID); ?>>
                            <?php echo esc_html($camp->post_title); ?>
                        </option>
                        <?php endforeach; ?>
                        <option value="auto">+ Create new camp from product</option>
                    </select>
                </td>
            </tr>
            <?php
        }
        echo '</table>';
    }
    
    public function ajax_import_products() {
        check_ajax_referer('ptp_import', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Permission denied'));
        }
        
        $product_id = intval($_POST['product_id']);
        $product = wc_get_product($product_id);
        
        if (!$product) {
            wp_send_json_error(array('message' => "Product #$product_id not found"));
        }
        
        // Check if already imported
        global $wpdb;
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_imported_woo_product_id' AND meta_value = %d",
            $product_id
        ));
        
        if ($existing) {
            wp_send_json_error(array('message' => $product->get_name() . ' already imported as Camp #' . $existing));
        }
        
        // Create camp post
        $camp_id = wp_insert_post(array(
            'post_title' => $product->get_name(),
            'post_content' => $product->get_description(),
            'post_status' => 'publish',
            'post_type' => 'ptp_camp'
        ));
        
        if (is_wp_error($camp_id)) {
            wp_send_json_error(array('message' => 'Failed to create camp: ' . $camp_id->get_error_message()));
        }
        
        // Copy meta fields
        $meta_mappings = array(
            '_regular_price' => '_camp_price',
            '_price' => '_camp_price',
            '_stock' => '_camp_capacity',
            '_camp_date' => '_camp_date',
            '_camp_start_date' => '_camp_start_date',
            '_camp_end_date' => '_camp_end_date',
            '_camp_time' => '_camp_time',
            '_camp_location' => '_camp_location',
            '_camp_address' => '_camp_address',
            '_camp_ages' => '_camp_ages',
            '_camp_video_url' => '_camp_video_url',
            '_camp_maps_embed' => '_camp_maps_embed'
        );
        
        foreach ($meta_mappings as $woo_key => $ptp_key) {
            $value = get_post_meta($product_id, $woo_key, true);
            if ($value) {
                update_post_meta($camp_id, $ptp_key, $value);
            }
        }
        
        // Copy featured image
        $thumbnail_id = get_post_thumbnail_id($product_id);
        if ($thumbnail_id) {
            set_post_thumbnail($camp_id, $thumbnail_id);
        }
        
        // Store import reference
        update_post_meta($camp_id, '_imported_woo_product_id', $product_id);
        update_post_meta($camp_id, '_import_date', current_time('mysql'));
        
        wp_send_json_success(array(
            'message' => $product->get_name() . ' → Camp #' . $camp_id,
            'camp_id' => $camp_id
        ));
    }
    
    public function ajax_import_orders() {
        check_ajax_referer('ptp_import', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Permission denied'));
        }
        
        $skip_existing = !empty($_POST['skip_existing']);
        $all_statuses = !empty($_POST['all_statuses']);
        $mappings = json_decode(stripslashes($_POST['mappings']), true) ?: array();
        
        global $wpdb;
        
        // Build product → camp mapping
        $product_to_camp = array();
        
        // Get mappings from meta (imported products)
        $imported = $wpdb->get_results("SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_imported_woo_product_id'");
        foreach ($imported as $row) {
            $product_to_camp[$row->meta_value] = $row->post_id;
        }
        
        // Override with manual mappings
        foreach ($mappings as $prod_id => $camp_id) {
            if ($camp_id && $camp_id !== 'auto') {
                $product_to_camp[$prod_id] = $camp_id;
            }
        }
        
        // Get orders
        $statuses = $all_statuses ? array('completed', 'processing', 'on-hold') : array('completed');
        $orders = wc_get_orders(array(
            'limit' => -1,
            'status' => $statuses
        ));
        
        $logs = array();
        $imported_count = 0;
        
        foreach ($orders as $order) {
            $order_id = $order->get_id();
            
            // Check if already imported
            if ($skip_existing) {
                $exists = $wpdb->get_var($wpdb->prepare(
                    "SELECT id FROM {$wpdb->prefix}ptp_camp_bookings WHERE stripe_payment_id = %s",
                    'woo_' . $order_id
                ));
                if ($exists) {
                    continue;
                }
            }
            
            foreach ($order->get_items() as $item) {
                $product_id = $item->get_product_id();
                
                // Find camp mapping
                $camp_id = $product_to_camp[$product_id] ?? null;
                
                if (!$camp_id) {
                    $logs[] = array('type' => 'error', 'message' => "Order #{$order_id}: No camp mapping for product #{$product_id}");
                    continue;
                }
                
                // Get camper info from order meta or item meta
                $camper_name = $order->get_meta('_camper_name') ?: $item->get_meta('Camper Name') ?: $item->get_meta('camper_name') ?: $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
                $camper_age = $order->get_meta('_camper_age') ?: $item->get_meta('Camper Age') ?: $item->get_meta('camper_age') ?: null;
                $camper_shirt = $order->get_meta('_camper_shirt_size') ?: $item->get_meta('Shirt Size') ?: $item->get_meta('shirt_size') ?: null;
                
                // Map status
                $status_map = array(
                    'completed' => 'confirmed',
                    'processing' => 'confirmed',
                    'on-hold' => 'pending',
                    'pending' => 'pending',
                    'cancelled' => 'cancelled',
                    'refunded' => 'refunded',
                    'failed' => 'failed'
                );
                $status = $status_map[$order->get_status()] ?? 'pending';
                
                // Insert booking
                $booking_data = array(
                    'camp_id' => $camp_id,
                    'stripe_payment_id' => 'woo_' . $order_id,
                    'customer_email' => $order->get_billing_email(),
                    'customer_name' => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
                    'customer_phone' => $order->get_billing_phone(),
                    'camper_name' => $camper_name,
                    'camper_age' => $camper_age ? intval($camper_age) : null,
                    'camper_shirt' => $camper_shirt,
                    'emergency_contact' => $order->get_meta('_emergency_contact') ?: $item->get_meta('Emergency Contact'),
                    'emergency_phone' => $order->get_meta('_emergency_phone') ?: $item->get_meta('Emergency Phone'),
                    'medical_notes' => $order->get_meta('_medical_notes') ?: $item->get_meta('Medical Notes'),
                    'amount_paid' => $item->get_total(),
                    'discount_applied' => $order->get_discount_total() > 0 ? ($order->get_discount_total() / count($order->get_items())) : 0,
                    'status' => $status,
                    'created_at' => $order->get_date_created()->date('Y-m-d H:i:s')
                );
                
                $result = $wpdb->insert("{$wpdb->prefix}ptp_camp_bookings", $booking_data);
                
                if ($result) {
                    $logs[] = array('type' => 'success', 'message' => "Order #{$order_id}: {$camper_name} → Camp #{$camp_id}");
                    $imported_count++;
                } else {
                    $logs[] = array('type' => 'error', 'message' => "Order #{$order_id}: Database error");
                }
            }
        }
        
        wp_send_json_success(array(
            'imported' => $imported_count,
            'logs' => $logs
        ));
    }
}

new PTP_Camps_Woo_Import();
