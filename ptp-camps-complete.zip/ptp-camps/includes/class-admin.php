<?php
if (!defined('ABSPATH')) exit;

class PTP_Camps_Admin {
    
    public function __construct() {
        add_action('admin_menu', array($this, 'add_menu'));
        add_action('add_meta_boxes', array($this, 'add_meta_boxes'));
        add_action('save_post_ptp_camp', array($this, 'save_meta'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_init', array($this, 'handle_admin_actions'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
    }
    
    public function enqueue_admin_assets($hook) {
        if (strpos($hook, 'ptp-camp') === false && strpos($hook, 'ptp_camp') === false) return;
        
        wp_enqueue_style('ptp-admin', PTP_CAMPS_URL . 'assets/css/ptp-admin.css', array(), PTP_CAMPS_VERSION);
    }
    
    public function add_menu() {
        add_submenu_page(
            'edit.php?post_type=ptp_camp',
            'Bookings',
            'Bookings',
            'manage_options',
            'ptp-camp-bookings',
            array($this, 'bookings_page')
        );
        
        add_submenu_page(
            'edit.php?post_type=ptp_camp',
            'Coupons',
            'Coupons',
            'manage_options',
            'ptp-camp-coupons',
            array($this, 'coupons_page')
        );
        
        add_submenu_page(
            'edit.php?post_type=ptp_camp',
            'Waitlist',
            'Waitlist',
            'manage_options',
            'ptp-camp-waitlist',
            array($this, 'waitlist_page')
        );
        
        add_submenu_page(
            'edit.php?post_type=ptp_camp',
            'Settings',
            'Settings',
            'manage_options',
            'ptp-camp-settings',
            array($this, 'settings_page')
        );
    }
    
    public function add_meta_boxes() {
        add_meta_box('ptp_camp_details', 'Camp Details', array($this, 'render_meta_box'), 'ptp_camp', 'normal', 'high');
        add_meta_box('ptp_camp_stats', 'Registration Stats', array($this, 'render_stats_box'), 'ptp_camp', 'side', 'high');
    }
    
    public function render_meta_box($post) {
        wp_nonce_field('ptp_camp_meta', 'ptp_camp_nonce');
        $fields = array(
            '_camp_date' => array('label' => 'Date Display', 'placeholder' => 'June 16-20, 2026'),
            '_camp_start_date' => array('label' => 'Start Date', 'type' => 'date'),
            '_camp_end_date' => array('label' => 'End Date', 'type' => 'date'),
            '_camp_time' => array('label' => 'Time', 'placeholder' => '9:00 AM - 3:00 PM'),
            '_camp_location' => array('label' => 'Location', 'placeholder' => 'Radnor, PA'),
            '_camp_address' => array('label' => 'Full Address'),
            '_camp_ages' => array('label' => 'Ages', 'placeholder' => '6-14'),
            '_camp_price' => array('label' => 'Price ($)', 'type' => 'number', 'placeholder' => '399'),
            '_camp_capacity' => array('label' => 'Capacity', 'type' => 'number', 'placeholder' => '40'),
            '_camp_video_url' => array('label' => 'Video URL'),
            '_camp_maps_embed' => array('label' => 'Google Maps Embed', 'type' => 'textarea')
        );
        
        echo '<table class="form-table">';
        foreach ($fields as $key => $field) {
            $value = get_post_meta($post->ID, $key, true);
            $type = $field['type'] ?? 'text';
            echo '<tr><th><label for="' . $key . '">' . $field['label'] . '</label></th><td>';
            if ($type === 'textarea') {
                echo '<textarea name="' . $key . '" id="' . $key . '" class="large-text" rows="3">' . esc_textarea($value) . '</textarea>';
            } else {
                echo '<input type="' . $type . '" name="' . $key . '" id="' . $key . '" value="' . esc_attr($value) . '" class="regular-text" placeholder="' . ($field['placeholder'] ?? '') . '">';
            }
            echo '</td></tr>';
        }
        echo '</table>';
    }
    
    public function render_stats_box($post) {
        $camp = PTP_Camps_Manager::get($post->ID);
        if (!$camp) return;
        
        echo '<div style="padding: 10px 0;">';
        echo '<p><strong>Capacity:</strong> ' . $camp['capacity'] . '</p>';
        echo '<p><strong>Registered:</strong> ' . ($camp['capacity'] - $camp['spots_left']) . '</p>';
        echo '<p><strong>Spots Left:</strong> <span style="color: ' . ($camp['spots_left'] < 5 ? '#d63638' : '#00a32a') . '; font-weight: bold;">' . $camp['spots_left'] . '</span></p>';
        
        $waitlist_count = count(PTP_Camps_Database::get_waitlist($post->ID));
        if ($waitlist_count > 0) {
            echo '<p><strong>Waitlist:</strong> ' . $waitlist_count . ' people</p>';
        }
        
        echo '<hr style="margin: 15px 0;">';
        echo '<p><a href="' . admin_url('edit.php?post_type=ptp_camp&page=ptp-camp-bookings&camp_id=' . $post->ID) . '" class="button">View Bookings</a></p>';
        echo '</div>';
    }
    
    public function save_meta($post_id) {
        if (!isset($_POST['ptp_camp_nonce']) || !wp_verify_nonce($_POST['ptp_camp_nonce'], 'ptp_camp_meta')) return;
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        
        $fields = array('_camp_date', '_camp_start_date', '_camp_end_date', '_camp_time', '_camp_location', '_camp_address', '_camp_ages', '_camp_price', '_camp_capacity', '_camp_video_url', '_camp_maps_embed');
        
        foreach ($fields as $field) {
            if (isset($_POST[$field])) {
                update_post_meta($post_id, $field, sanitize_text_field($_POST[$field]));
            }
        }
    }
    
    public function register_settings() {
        register_setting('ptp_camps_settings', 'ptp_camps_stripe_pk');
        register_setting('ptp_camps_settings', 'ptp_camps_stripe_sk');
        register_setting('ptp_camps_settings', 'ptp_camps_webhook_secret');
        register_setting('ptp_camps_settings', 'ptp_camps_email');
        register_setting('ptp_camps_settings', 'ptp_camps_phone');
    }
    
    /**
     * Handle admin actions (refunds, exports, coupon management)
     */
    public function handle_admin_actions() {
        // Export bookings
        if (isset($_GET['ptp_export']) && $_GET['ptp_export'] === 'bookings' && current_user_can('manage_options')) {
            check_admin_referer('ptp_export_bookings');
            $this->export_bookings();
            exit;
        }
        
        // Process refund
        if (isset($_POST['ptp_refund_booking']) && current_user_can('manage_options')) {
            check_admin_referer('ptp_refund_booking');
            $this->process_refund();
        }
        
        // Create coupon
        if (isset($_POST['ptp_create_coupon']) && current_user_can('manage_options')) {
            check_admin_referer('ptp_create_coupon');
            $this->create_coupon();
        }
        
        // Delete coupon
        if (isset($_GET['ptp_delete_coupon']) && current_user_can('manage_options')) {
            check_admin_referer('ptp_delete_coupon_' . $_GET['ptp_delete_coupon']);
            PTP_Camps_Coupons::delete(intval($_GET['ptp_delete_coupon']));
            wp_redirect(admin_url('edit.php?post_type=ptp_camp&page=ptp-camp-coupons&deleted=1'));
            exit;
        }
    }
    
    /**
     * Export bookings to CSV
     */
    private function export_bookings() {
        global $wpdb;
        
        $camp_id = isset($_GET['camp_id']) ? intval($_GET['camp_id']) : 0;
        $status = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';
        
        $sql = "SELECT b.*, p.post_title as camp_name FROM {$wpdb->prefix}ptp_camp_bookings b 
                LEFT JOIN {$wpdb->posts} p ON b.camp_id = p.ID WHERE 1=1";
        
        if ($camp_id) {
            $sql .= $wpdb->prepare(" AND b.camp_id = %d", $camp_id);
        }
        if ($status) {
            $sql .= $wpdb->prepare(" AND b.status = %s", $status);
        }
        
        $sql .= " ORDER BY b.created_at DESC";
        $bookings = $wpdb->get_results($sql);
        
        $filename = 'ptp-camp-bookings-' . date('Y-m-d') . '.csv';
        
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=' . $filename);
        
        $output = fopen('php://output', 'w');
        
        // Header row
        fputcsv($output, array(
            'ID', 'Camp', 'Camper Name', 'Camper Age', 'Shirt Size',
            'Parent Name', 'Email', 'Phone',
            'Emergency Contact', 'Emergency Phone', 'Medical Notes',
            'Amount Paid', 'Discount', 'Coupon', 'Status', 'Date'
        ));
        
        foreach ($bookings as $b) {
            fputcsv($output, array(
                $b->id,
                $b->camp_name,
                $b->camper_name,
                $b->camper_age,
                $b->camper_shirt,
                $b->customer_name,
                $b->customer_email,
                $b->customer_phone,
                $b->emergency_contact,
                $b->emergency_phone,
                $b->medical_notes,
                $b->amount_paid,
                $b->discount_applied,
                $b->coupon_code,
                $b->status,
                $b->created_at
            ));
        }
        
        fclose($output);
    }
    
    /**
     * Process refund via Stripe
     */
    private function process_refund() {
        $booking_id = intval($_POST['booking_id']);
        $amount = floatval($_POST['refund_amount']);
        $reason = sanitize_textarea_field($_POST['refund_reason']);
        
        $booking = PTP_Camps_Database::get_booking($booking_id);
        
        if (!$booking || !$booking->stripe_payment_id) {
            add_settings_error('ptp_camps', 'refund_error', 'Invalid booking or no payment found', 'error');
            return;
        }
        
        // Skip Stripe for imported WooCommerce orders
        if (strpos($booking->stripe_payment_id, 'woo_') === 0) {
            PTP_Camps_Database::update_booking($booking_id, array(
                'status' => 'refunded',
                'refund_amount' => $amount,
                'refund_reason' => $reason,
                'refunded_at' => current_time('mysql')
            ));
            PTP_Camps_Database::check_waitlist_trigger($booking->camp_id);
            wp_redirect(admin_url('edit.php?post_type=ptp_camp&page=ptp-camp-bookings&refunded=1'));
            exit;
        }
        
        // Process via Stripe
        $stripe_sk = get_option('ptp_camps_stripe_sk', '');
        
        // Get the charge from payment intent
        $pi_response = wp_remote_get('https://api.stripe.com/v1/payment_intents/' . $booking->stripe_payment_id, array(
            'headers' => array('Authorization' => 'Bearer ' . $stripe_sk)
        ));
        
        if (is_wp_error($pi_response)) {
            add_settings_error('ptp_camps', 'refund_error', 'Could not retrieve payment intent', 'error');
            return;
        }
        
        $pi = json_decode(wp_remote_retrieve_body($pi_response), true);
        $charge_id = $pi['latest_charge'] ?? null;
        
        if (!$charge_id) {
            add_settings_error('ptp_camps', 'refund_error', 'No charge found for this payment', 'error');
            return;
        }
        
        // Create refund
        $refund_response = wp_remote_post('https://api.stripe.com/v1/refunds', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $stripe_sk,
                'Content-Type' => 'application/x-www-form-urlencoded'
            ),
            'body' => array(
                'charge' => $charge_id,
                'amount' => intval($amount * 100),
                'reason' => 'requested_by_customer'
            )
        ));
        
        if (is_wp_error($refund_response)) {
            add_settings_error('ptp_camps', 'refund_error', 'Stripe refund failed: ' . $refund_response->get_error_message(), 'error');
            return;
        }
        
        $refund = json_decode(wp_remote_retrieve_body($refund_response), true);
        
        if (isset($refund['error'])) {
            add_settings_error('ptp_camps', 'refund_error', 'Stripe error: ' . $refund['error']['message'], 'error');
            return;
        }
        
        // Update booking
        $is_full_refund = $amount >= $booking->amount_paid;
        PTP_Camps_Database::update_booking($booking_id, array(
            'status' => $is_full_refund ? 'refunded' : 'partial_refund',
            'refund_amount' => $amount,
            'refund_reason' => $reason,
            'refunded_at' => current_time('mysql')
        ));
        
        // Trigger waitlist if full refund
        if ($is_full_refund) {
            PTP_Camps_Database::check_waitlist_trigger($booking->camp_id);
        }
        
        // Send refund email
        PTP_Camps_Emails::send_refund_notification($booking->customer_email, array($booking_id), $amount);
        
        wp_redirect(admin_url('edit.php?post_type=ptp_camp&page=ptp-camp-bookings&refunded=1'));
        exit;
    }
    
    /**
     * Create coupon
     */
    private function create_coupon() {
        $result = PTP_Camps_Coupons::create(array(
            'code' => $_POST['coupon_code'],
            'description' => $_POST['coupon_description'],
            'discount_type' => $_POST['discount_type'],
            'discount_amount' => $_POST['discount_amount'],
            'minimum_spend' => $_POST['minimum_spend'],
            'usage_limit' => $_POST['usage_limit'],
            'expires_at' => $_POST['expires_at']
        ));
        
        if (is_wp_error($result)) {
            add_settings_error('ptp_camps', 'coupon_error', $result->get_error_message(), 'error');
        } else {
            wp_redirect(admin_url('edit.php?post_type=ptp_camp&page=ptp-camp-coupons&created=1'));
            exit;
        }
    }
    
    /**
     * Settings page
     */
    public function settings_page() {
        ?>
        <div class="wrap">
            <h1>PTP Camps Settings</h1>
            <form method="post" action="options.php">
                <?php settings_fields('ptp_camps_settings'); ?>
                
                <h2>Stripe Configuration</h2>
                <table class="form-table">
                    <tr>
                        <th>Stripe Publishable Key</th>
                        <td><input type="text" name="ptp_camps_stripe_pk" value="<?php echo esc_attr(get_option('ptp_camps_stripe_pk')); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th>Stripe Secret Key</th>
                        <td><input type="password" name="ptp_camps_stripe_sk" value="<?php echo esc_attr(get_option('ptp_camps_stripe_sk')); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th>Webhook Secret</th>
                        <td>
                            <input type="password" name="ptp_camps_webhook_secret" value="<?php echo esc_attr(get_option('ptp_camps_webhook_secret')); ?>" class="regular-text">
                            <p class="description">Webhook URL: <code><?php echo rest_url('ptp-camps/v1/webhook'); ?></code></p>
                        </td>
                    </tr>
                </table>
                
                <h2>Email Settings</h2>
                <table class="form-table">
                    <tr>
                        <th>From Email</th>
                        <td>
                            <input type="email" name="ptp_camps_email" value="<?php echo esc_attr(get_option('ptp_camps_email', 'camps@ptpsoccercamps.com')); ?>" class="regular-text">
                        </td>
                    </tr>
                    <tr>
                        <th>Contact Phone</th>
                        <td>
                            <input type="text" name="ptp_camps_phone" value="<?php echo esc_attr(get_option('ptp_camps_phone', '(610) 888-1234')); ?>" class="regular-text">
                        </td>
                    </tr>
                </table>
                
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }
    
    /**
     * Bookings page with filters, export, and refund modal
     */
    public function bookings_page() {
        global $wpdb;
        
        // Get filters
        $camp_id = isset($_GET['camp_id']) ? intval($_GET['camp_id']) : 0;
        $status = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';
        $search = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';
        
        // Build query
        $sql = "SELECT b.*, p.post_title as camp_name FROM {$wpdb->prefix}ptp_camp_bookings b 
                LEFT JOIN {$wpdb->posts} p ON b.camp_id = p.ID WHERE 1=1";
        
        if ($camp_id) {
            $sql .= $wpdb->prepare(" AND b.camp_id = %d", $camp_id);
        }
        if ($status) {
            $sql .= $wpdb->prepare(" AND b.status = %s", $status);
        }
        if ($search) {
            $sql .= $wpdb->prepare(" AND (b.camper_name LIKE %s OR b.customer_name LIKE %s OR b.customer_email LIKE %s)", 
                '%' . $wpdb->esc_like($search) . '%',
                '%' . $wpdb->esc_like($search) . '%',
                '%' . $wpdb->esc_like($search) . '%'
            );
        }
        
        $sql .= " ORDER BY b.created_at DESC LIMIT 200";
        $bookings = $wpdb->get_results($sql);
        
        // Get camps for filter dropdown
        $camps = get_posts(array('post_type' => 'ptp_camp', 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC'));
        
        // Get stats
        $total_revenue = $wpdb->get_var("SELECT SUM(amount_paid) FROM {$wpdb->prefix}ptp_camp_bookings WHERE status = 'confirmed'");
        $total_bookings = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ptp_camp_bookings WHERE status = 'confirmed'");
        
        ?>
        <div class="wrap">
            <h1>Camp Bookings</h1>
            
            <?php if (isset($_GET['refunded'])): ?>
            <div class="notice notice-success"><p>Refund processed successfully!</p></div>
            <?php endif; ?>
            
            <!-- Stats -->
            <div class="ptp-admin-stats" style="display: flex; gap: 20px; margin: 20px 0;">
                <div style="background: #fff; border: 1px solid #ccd0d4; padding: 20px; flex: 1;">
                    <div style="font-size: 28px; font-weight: 600; color: #1d2327;">$<?php echo number_format($total_revenue ?: 0, 0); ?></div>
                    <div style="color: #646970;">Total Revenue</div>
                </div>
                <div style="background: #fff; border: 1px solid #ccd0d4; padding: 20px; flex: 1;">
                    <div style="font-size: 28px; font-weight: 600; color: #1d2327;"><?php echo number_format($total_bookings ?: 0); ?></div>
                    <div style="color: #646970;">Confirmed Bookings</div>
                </div>
            </div>
            
            <!-- Filters -->
            <form method="get" style="margin-bottom: 20px;">
                <input type="hidden" name="post_type" value="ptp_camp">
                <input type="hidden" name="page" value="ptp-camp-bookings">
                
                <select name="camp_id">
                    <option value="">All Camps</option>
                    <?php foreach ($camps as $camp): ?>
                    <option value="<?php echo $camp->ID; ?>" <?php selected($camp_id, $camp->ID); ?>><?php echo esc_html($camp->post_title); ?></option>
                    <?php endforeach; ?>
                </select>
                
                <select name="status">
                    <option value="">All Statuses</option>
                    <option value="confirmed" <?php selected($status, 'confirmed'); ?>>Confirmed</option>
                    <option value="pending" <?php selected($status, 'pending'); ?>>Pending</option>
                    <option value="refunded" <?php selected($status, 'refunded'); ?>>Refunded</option>
                    <option value="cancelled" <?php selected($status, 'cancelled'); ?>>Cancelled</option>
                </select>
                
                <input type="text" name="s" placeholder="Search..." value="<?php echo esc_attr($search); ?>">
                
                <input type="submit" class="button" value="Filter">
                
                <a href="<?php echo wp_nonce_url(admin_url('edit.php?post_type=ptp_camp&page=ptp-camp-bookings&ptp_export=bookings&camp_id=' . $camp_id . '&status=' . $status), 'ptp_export_bookings'); ?>" class="button" style="margin-left: 10px;">Export CSV</a>
            </form>
            
            <!-- Bookings Table -->
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th style="width: 50px;">ID</th>
                        <th>Camp</th>
                        <th>Camper</th>
                        <th>Parent</th>
                        <th>Contact</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Date</th>
                        <th style="width: 100px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($bookings)): ?>
                    <tr><td colspan="9">No bookings found.</td></tr>
                <?php else: foreach ($bookings as $b): ?>
                <tr>
                    <td><?php echo $b->id; ?></td>
                    <td><?php echo esc_html($b->camp_name); ?></td>
                    <td>
                        <strong><?php echo esc_html($b->camper_name); ?></strong>
                        <?php if ($b->camper_age): ?><br><span style="color: #666;">Age <?php echo $b->camper_age; ?></span><?php endif; ?>
                        <?php if ($b->camper_shirt): ?><br><span style="color: #666;">Shirt: <?php echo $b->camper_shirt; ?></span><?php endif; ?>
                    </td>
                    <td><?php echo esc_html($b->customer_name); ?></td>
                    <td>
                        <a href="mailto:<?php echo esc_attr($b->customer_email); ?>"><?php echo esc_html($b->customer_email); ?></a>
                        <?php if ($b->customer_phone): ?><br><?php echo esc_html($b->customer_phone); ?><?php endif; ?>
                    </td>
                    <td>
                        $<?php echo number_format($b->amount_paid, 2); ?>
                        <?php if ($b->discount_applied > 0): ?><br><span style="color: #00a32a;">-$<?php echo number_format($b->discount_applied, 2); ?></span><?php endif; ?>
                        <?php if ($b->refund_amount > 0): ?><br><span style="color: #d63638;">Refund: $<?php echo number_format($b->refund_amount, 2); ?></span><?php endif; ?>
                    </td>
                    <td>
                        <span style="padding: 3px 8px; border-radius: 3px; font-size: 12px; background: <?php 
                            echo $b->status === 'confirmed' ? '#d7f7c2' : ($b->status === 'refunded' ? '#fcf0f0' : '#fff3cd');
                        ?>; color: <?php 
                            echo $b->status === 'confirmed' ? '#006600' : ($b->status === 'refunded' ? '#8b0000' : '#856404');
                        ?>;">
                            <?php echo ucfirst($b->status); ?>
                        </span>
                    </td>
                    <td><?php echo date('M j, Y', strtotime($b->created_at)); ?></td>
                    <td>
                        <button type="button" class="button button-small ptp-view-booking" data-booking='<?php echo esc_attr(json_encode($b)); ?>'>View</button>
                        <?php if ($b->status === 'confirmed' && $b->stripe_payment_id): ?>
                        <button type="button" class="button button-small ptp-refund-booking" data-id="<?php echo $b->id; ?>" data-amount="<?php echo $b->amount_paid; ?>">Refund</button>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Booking Detail Modal -->
        <div id="ptp-booking-modal" style="display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.6); z-index: 100000;">
            <div style="background: #fff; max-width: 600px; margin: 50px auto; padding: 30px; border-radius: 4px; max-height: 80vh; overflow-y: auto;">
                <h2 style="margin-top: 0;">Booking Details</h2>
                <div id="ptp-booking-content"></div>
                <p><button type="button" class="button" onclick="document.getElementById('ptp-booking-modal').style.display='none'">Close</button></p>
            </div>
        </div>
        
        <!-- Refund Modal -->
        <div id="ptp-refund-modal" style="display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.6); z-index: 100000;">
            <div style="background: #fff; max-width: 400px; margin: 100px auto; padding: 30px; border-radius: 4px;">
                <h2 style="margin-top: 0;">Process Refund</h2>
                <form method="post">
                    <?php wp_nonce_field('ptp_refund_booking'); ?>
                    <input type="hidden" name="ptp_refund_booking" value="1">
                    <input type="hidden" name="booking_id" id="refund-booking-id" value="">
                    
                    <p>
                        <label><strong>Refund Amount ($)</strong></label><br>
                        <input type="number" name="refund_amount" id="refund-amount" step="0.01" min="0" required style="width: 100%;">
                    </p>
                    <p>
                        <label><strong>Reason</strong></label><br>
                        <textarea name="refund_reason" rows="3" style="width: 100%;" placeholder="Optional reason for refund..."></textarea>
                    </p>
                    <p>
                        <button type="submit" class="button button-primary">Process Refund</button>
                        <button type="button" class="button" onclick="document.getElementById('ptp-refund-modal').style.display='none'">Cancel</button>
                    </p>
                </form>
            </div>
        </div>
        
        <script>
        document.querySelectorAll('.ptp-view-booking').forEach(function(btn) {
            btn.addEventListener('click', function() {
                var b = JSON.parse(this.dataset.booking);
                var html = '<table class="form-table">' +
                    '<tr><th>Camper</th><td>' + b.camper_name + ' (Age ' + (b.camper_age || 'N/A') + ')</td></tr>' +
                    '<tr><th>Shirt Size</th><td>' + (b.camper_shirt || 'N/A') + '</td></tr>' +
                    '<tr><th>Parent</th><td>' + b.customer_name + '</td></tr>' +
                    '<tr><th>Email</th><td>' + b.customer_email + '</td></tr>' +
                    '<tr><th>Phone</th><td>' + (b.customer_phone || 'N/A') + '</td></tr>' +
                    '<tr><th>Emergency Contact</th><td>' + (b.emergency_contact || 'N/A') + ' - ' + (b.emergency_phone || 'N/A') + '</td></tr>' +
                    '<tr><th>Medical Notes</th><td>' + (b.medical_notes || 'None') + '</td></tr>' +
                    '<tr><th>Amount Paid</th><td>$' + parseFloat(b.amount_paid).toFixed(2) + '</td></tr>' +
                    '<tr><th>Stripe ID</th><td><code>' + (b.stripe_payment_id || 'N/A') + '</code></td></tr>' +
                    '</table>';
                document.getElementById('ptp-booking-content').innerHTML = html;
                document.getElementById('ptp-booking-modal').style.display = 'block';
            });
        });
        
        document.querySelectorAll('.ptp-refund-booking').forEach(function(btn) {
            btn.addEventListener('click', function() {
                document.getElementById('refund-booking-id').value = this.dataset.id;
                document.getElementById('refund-amount').value = this.dataset.amount;
                document.getElementById('ptp-refund-modal').style.display = 'block';
            });
        });
        </script>
        <?php
    }
    
    /**
     * Coupons page
     */
    public function coupons_page() {
        $coupons = PTP_Camps_Coupons::get_all();
        ?>
        <div class="wrap">
            <h1>Coupon Codes</h1>
            
            <?php if (isset($_GET['created'])): ?>
            <div class="notice notice-success"><p>Coupon created successfully!</p></div>
            <?php endif; ?>
            <?php if (isset($_GET['deleted'])): ?>
            <div class="notice notice-success"><p>Coupon deleted.</p></div>
            <?php endif; ?>
            
            <!-- Create Coupon Form -->
            <div style="background: #fff; border: 1px solid #ccd0d4; padding: 20px; margin: 20px 0; max-width: 600px;">
                <h2 style="margin-top: 0;">Create New Coupon</h2>
                <form method="post">
                    <?php wp_nonce_field('ptp_create_coupon'); ?>
                    <input type="hidden" name="ptp_create_coupon" value="1">
                    
                    <table class="form-table">
                        <tr>
                            <th><label for="coupon_code">Code</label></th>
                            <td><input type="text" name="coupon_code" id="coupon_code" required class="regular-text" style="text-transform: uppercase;" placeholder="SUMMER2026"></td>
                        </tr>
                        <tr>
                            <th><label for="coupon_description">Description</label></th>
                            <td><input type="text" name="coupon_description" id="coupon_description" class="regular-text" placeholder="Summer promo"></td>
                        </tr>
                        <tr>
                            <th><label>Discount</label></th>
                            <td>
                                <input type="number" name="discount_amount" step="0.01" min="0" required style="width: 100px;">
                                <select name="discount_type">
                                    <option value="percent">% Off</option>
                                    <option value="fixed">$ Off</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="minimum_spend">Minimum Spend</label></th>
                            <td><input type="number" name="minimum_spend" id="minimum_spend" step="0.01" min="0" value="0" style="width: 100px;"> $</td>
                        </tr>
                        <tr>
                            <th><label for="usage_limit">Usage Limit</label></th>
                            <td><input type="number" name="usage_limit" id="usage_limit" min="0" value="0" style="width: 100px;"> <span class="description">(0 = unlimited)</span></td>
                        </tr>
                        <tr>
                            <th><label for="expires_at">Expires</label></th>
                            <td><input type="datetime-local" name="expires_at" id="expires_at"></td>
                        </tr>
                    </table>
                    
                    <?php submit_button('Create Coupon'); ?>
                </form>
            </div>
            
            <!-- Existing Coupons -->
            <h2>Existing Coupons</h2>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>Code</th>
                        <th>Description</th>
                        <th>Discount</th>
                        <th>Usage</th>
                        <th>Expires</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($coupons)): ?>
                    <tr><td colspan="7">No coupons yet.</td></tr>
                <?php else: foreach ($coupons as $c): ?>
                <tr>
                    <td><code style="font-size: 14px; font-weight: bold;"><?php echo esc_html($c['code']); ?></code></td>
                    <td><?php echo esc_html($c['description']); ?></td>
                    <td><?php echo $c['discount_type'] === 'percent' ? $c['discount_amount'] . '%' : '$' . number_format($c['discount_amount'], 2); ?></td>
                    <td><?php echo $c['usage_count']; ?><?php echo $c['usage_limit'] ? '/' . $c['usage_limit'] : ''; ?></td>
                    <td><?php echo $c['expires_at'] ? date('M j, Y', strtotime($c['expires_at'])) : 'Never'; ?></td>
                    <td>
                        <span style="color: <?php echo $c['status'] === 'active' ? '#00a32a' : '#d63638'; ?>;">
                            <?php echo ucfirst($c['status']); ?>
                        </span>
                    </td>
                    <td>
                        <a href="<?php echo wp_nonce_url(admin_url('edit.php?post_type=ptp_camp&page=ptp-camp-coupons&ptp_delete_coupon=' . $c['id']), 'ptp_delete_coupon_' . $c['id']); ?>" class="button button-small" onclick="return confirm('Delete this coupon?');">Delete</a>
                    </td>
                </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }
    
    /**
     * Waitlist page
     */
    public function waitlist_page() {
        global $wpdb;
        
        $waitlist = $wpdb->get_results(
            "SELECT w.*, p.post_title as camp_name 
             FROM {$wpdb->prefix}ptp_camp_waitlist w 
             LEFT JOIN {$wpdb->posts} p ON w.camp_id = p.ID 
             ORDER BY w.created_at DESC LIMIT 200"
        );
        ?>
        <div class="wrap">
            <h1>Camp Waitlist</h1>
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>Camp</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Status</th>
                        <th>Signed Up</th>
                        <th>Notified</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($waitlist)): ?>
                    <tr><td colspan="7">No waitlist entries.</td></tr>
                <?php else: foreach ($waitlist as $w): ?>
                <tr>
                    <td><?php echo esc_html($w->camp_name); ?></td>
                    <td><?php echo esc_html($w->name); ?></td>
                    <td><a href="mailto:<?php echo esc_attr($w->email); ?>"><?php echo esc_html($w->email); ?></a></td>
                    <td><?php echo esc_html($w->phone); ?></td>
                    <td>
                        <span style="color: <?php echo $w->status === 'waiting' ? '#0073aa' : ($w->status === 'notified' ? '#00a32a' : '#666'); ?>;">
                            <?php echo ucfirst($w->status); ?>
                        </span>
                    </td>
                    <td><?php echo date('M j, Y', strtotime($w->created_at)); ?></td>
                    <td><?php echo $w->notified_at ? date('M j, Y', strtotime($w->notified_at)) : '-'; ?></td>
                </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }
}

new PTP_Camps_Admin();
