<?php
if (!defined('ABSPATH')) exit;

/**
 * Cart handler using cookies + transients for reliability
 * Works on object-cached hosts where sessions fail
 */
class PTP_Camps_Cart {
    private static $cookie_name = 'ptp_camp_cart_id';
    private static $cookie_expiry = 7 * DAY_IN_SECONDS;
    
    /**
     * Get or create cart session ID
     */
    private static function get_cart_id() {
        if (isset($_COOKIE[self::$cookie_name])) {
            return sanitize_text_field($_COOKIE[self::$cookie_name]);
        }
        
        $cart_id = wp_generate_uuid4();
        setcookie(self::$cookie_name, $cart_id, time() + self::$cookie_expiry, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true);
        $_COOKIE[self::$cookie_name] = $cart_id;
        
        return $cart_id;
    }
    
    /**
     * Get cart contents
     */
    public static function get() {
        $cart_id = self::get_cart_id();
        $cart = get_transient('ptp_cart_' . $cart_id);
        return is_array($cart) ? $cart : array();
    }
    
    /**
     * Save cart contents
     */
    private static function save($cart) {
        $cart_id = self::get_cart_id();
        set_transient('ptp_cart_' . $cart_id, $cart, self::$cookie_expiry);
    }
    
    /**
     * Add camp to cart
     */
    public static function add($camp_id, $camper_data = array()) {
        $cart = self::get();
        
        $camp = PTP_Camps_Manager::get($camp_id);
        if (!$camp || $camp['sold_out']) {
            return false;
        }
        
        $key = 'item_' . uniqid();
        $cart[$key] = array(
            'camp_id' => intval($camp_id),
            'camper' => $camper_data,
            'added_at' => time()
        );
        
        self::save($cart);
        return $key;
    }
    
    /**
     * Remove item from cart
     */
    public static function remove($key) {
        $cart = self::get();
        if (isset($cart[$key])) {
            unset($cart[$key]);
            self::save($cart);
            return true;
        }
        return false;
    }
    
    /**
     * Clear entire cart
     */
    public static function clear() {
        self::save(array());
        self::remove_coupon();
    }
    
    /**
     * Get cart count
     */
    public static function count() {
        return count(self::get());
    }
    
    /**
     * Apply coupon to cart
     */
    public static function apply_coupon($code) {
        $coupon = PTP_Camps_Coupons::validate($code);
        if (!$coupon) {
            return array('success' => false, 'message' => 'Invalid or expired coupon code');
        }
        
        $cart_id = self::get_cart_id();
        set_transient('ptp_cart_coupon_' . $cart_id, $coupon, self::$cookie_expiry);
        
        return array('success' => true, 'coupon' => $coupon);
    }
    
    /**
     * Remove coupon from cart
     */
    public static function remove_coupon() {
        $cart_id = self::get_cart_id();
        delete_transient('ptp_cart_coupon_' . $cart_id);
    }
    
    /**
     * Get applied coupon
     */
    public static function get_coupon() {
        $cart_id = self::get_cart_id();
        return get_transient('ptp_cart_coupon_' . $cart_id);
    }
    
    /**
     * Calculate cart totals with all discounts
     */
    public static function get_totals() {
        $items = self::get();
        $count = count($items);
        $subtotal = 0;
        $base_prices = array();
        
        foreach ($items as $item) {
            $camp = PTP_Camps_Manager::get($item['camp_id']);
            if ($camp) {
                $price = $camp['price'];
                $base_prices[] = $price;
                $subtotal += $price;
            }
        }
        
        // Early bird discount ($50 per week if active)
        $early_bird_discount = 0;
        if (ptp_camps_is_early_bird()) {
            $early_bird_discount = $count * 50;
        }
        
        // Multi-week discount (10% for 2, 20% for 3+)
        $multi_week_discount = 0;
        if ($count >= 2 && !empty($base_prices)) {
            $avg_price = array_sum($base_prices) / count($base_prices);
            $multi_week_discount = PTP_Camps_Manager::calculate_multi_week_discount($count, $avg_price);
        }
        
        // Coupon discount
        $coupon_discount = 0;
        $coupon = self::get_coupon();
        $after_auto_discounts = $subtotal - $early_bird_discount - $multi_week_discount;
        
        if ($coupon) {
            if ($coupon['type'] === 'percent') {
                $coupon_discount = round($after_auto_discounts * ($coupon['amount'] / 100), 2);
            } else {
                $coupon_discount = min($coupon['amount'], $after_auto_discounts);
            }
        }
        
        $total = max(0, $subtotal - $early_bird_discount - $multi_week_discount - $coupon_discount);
        
        return array(
            'count' => $count,
            'subtotal' => $subtotal,
            'early_bird_discount' => $early_bird_discount,
            'multi_week_discount' => $multi_week_discount,
            'coupon_discount' => $coupon_discount,
            'coupon_code' => $coupon ? $coupon['code'] : null,
            'total' => $total
        );
    }
}
