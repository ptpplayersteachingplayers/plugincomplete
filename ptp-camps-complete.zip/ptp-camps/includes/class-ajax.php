<?php
if (!defined('ABSPATH')) exit;

class PTP_Camps_Ajax {
    
    public function __construct() {
        // Cart actions
        add_action('wp_ajax_ptp_add_to_cart', array($this, 'add_to_cart'));
        add_action('wp_ajax_nopriv_ptp_add_to_cart', array($this, 'add_to_cart'));
        add_action('wp_ajax_ptp_remove_from_cart', array($this, 'remove_from_cart'));
        add_action('wp_ajax_nopriv_ptp_remove_from_cart', array($this, 'remove_from_cart'));
        add_action('wp_ajax_ptp_get_cart', array($this, 'get_cart'));
        add_action('wp_ajax_nopriv_ptp_get_cart', array($this, 'get_cart'));
        
        // Coupon actions
        add_action('wp_ajax_ptp_apply_coupon', array($this, 'apply_coupon'));
        add_action('wp_ajax_nopriv_ptp_apply_coupon', array($this, 'apply_coupon'));
        add_action('wp_ajax_ptp_remove_coupon', array($this, 'remove_coupon'));
        add_action('wp_ajax_nopriv_ptp_remove_coupon', array($this, 'remove_coupon'));
        
        // Checkout actions
        add_action('wp_ajax_ptp_create_payment', array($this, 'create_payment'));
        add_action('wp_ajax_nopriv_ptp_create_payment', array($this, 'create_payment'));
        add_action('wp_ajax_ptp_confirm_booking', array($this, 'confirm_booking'));
        add_action('wp_ajax_nopriv_ptp_confirm_booking', array($this, 'confirm_booking'));
        
        // Waitlist actions
        add_action('wp_ajax_ptp_join_waitlist', array($this, 'join_waitlist'));
        add_action('wp_ajax_nopriv_ptp_join_waitlist', array($this, 'join_waitlist'));
        
        // Multi-week add (from product page)
        add_action('wp_ajax_ptp_camps_add_multiple_weeks', array($this, 'add_multiple_weeks'));
        add_action('wp_ajax_nopriv_ptp_camps_add_multiple_weeks', array($this, 'add_multiple_weeks'));
        add_action('wp_ajax_ptp_camps_add_to_cart', array($this, 'add_single_to_cart'));
        add_action('wp_ajax_nopriv_ptp_camps_add_to_cart', array($this, 'add_single_to_cart'));
    }
    
    /**
     * Add camp(s) to cart
     */
    public function add_to_cart() {
        check_ajax_referer('ptp_camps_nonce', 'nonce');
        
        $camp_ids = isset($_POST['camp_ids']) ? array_map('intval', (array)$_POST['camp_ids']) : array();
        
        if (empty($camp_ids)) {
            wp_send_json_error('No camps selected');
        }
        
        $added = 0;
        foreach ($camp_ids as $camp_id) {
            $camp = PTP_Camps_Manager::get($camp_id);
            if (!$camp || $camp['sold_out']) continue;
            
            if (PTP_Camps_Cart::add($camp_id)) {
                $added++;
            }
        }
        
        wp_send_json_success(array(
            'added' => $added,
            'cart' => PTP_Camps_Cart::get(),
            'totals' => PTP_Camps_Cart::get_totals(),
            'redirect' => home_url('/camp-checkout/')
        ));
    }
    
    /**
     * Add single camp (from product page JS)
     */
    public function add_single_to_cart() {
        check_ajax_referer('ptp_camps_nonce', 'nonce');
        
        $camp_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
        
        if (!$camp_id) {
            wp_send_json_error('No camp specified');
        }
        
        $camp = PTP_Camps_Manager::get($camp_id);
        if (!$camp) {
            wp_send_json_error('Camp not found');
        }
        
        if ($camp['sold_out']) {
            wp_send_json_error('This camp is sold out');
        }
        
        PTP_Camps_Cart::add($camp_id);
        
        wp_send_json_success(array(
            'cart' => PTP_Camps_Cart::get(),
            'totals' => PTP_Camps_Cart::get_totals(),
            'redirect' => home_url('/camp-checkout/')
        ));
    }
    
    /**
     * Add multiple weeks (from product page multi-select)
     */
    public function add_multiple_weeks() {
        check_ajax_referer('ptp_camps_nonce', 'nonce');
        
        $camp_ids = isset($_POST['product_ids']) ? array_map('intval', (array)$_POST['product_ids']) : array();
        
        if (empty($camp_ids)) {
            wp_send_json_error('No camps selected');
        }
        
        // Clear existing cart and add new selections
        PTP_Camps_Cart::clear();
        
        $added = 0;
        foreach ($camp_ids as $camp_id) {
            $camp = PTP_Camps_Manager::get($camp_id);
            if (!$camp || $camp['sold_out']) continue;
            
            if (PTP_Camps_Cart::add($camp_id)) {
                $added++;
            }
        }
        
        if ($added === 0) {
            wp_send_json_error('No available camps could be added');
        }
        
        wp_send_json_success(array(
            'added' => $added,
            'cart' => PTP_Camps_Cart::get(),
            'totals' => PTP_Camps_Cart::get_totals(),
            'redirect' => home_url('/camp-checkout/')
        ));
    }
    
    /**
     * Remove item from cart
     */
    public function remove_from_cart() {
        check_ajax_referer('ptp_camps_nonce', 'nonce');
        
        $key = sanitize_text_field($_POST['key']);
        PTP_Camps_Cart::remove($key);
        
        wp_send_json_success(array(
            'cart' => PTP_Camps_Cart::get(),
            'totals' => PTP_Camps_Cart::get_totals()
        ));
    }
    
    /**
     * Get cart contents
     */
    public function get_cart() {
        wp_send_json_success(array(
            'cart' => PTP_Camps_Cart::get(),
            'totals' => PTP_Camps_Cart::get_totals()
        ));
    }
    
    /**
     * Apply coupon code
     */
    public function apply_coupon() {
        check_ajax_referer('ptp_camps_nonce', 'nonce');
        
        $code = sanitize_text_field($_POST['code'] ?? '');
        
        if (empty($code)) {
            wp_send_json_error(array('message' => 'Please enter a coupon code'));
        }
        
        $result = PTP_Camps_Cart::apply_coupon($code);
        
        if ($result['success']) {
            wp_send_json_success(array(
                'coupon' => $result['coupon'],
                'totals' => PTP_Camps_Cart::get_totals(),
                'message' => 'Coupon applied!'
            ));
        } else {
            wp_send_json_error(array('message' => $result['message']));
        }
    }
    
    /**
     * Remove coupon
     */
    public function remove_coupon() {
        check_ajax_referer('ptp_camps_nonce', 'nonce');
        
        PTP_Camps_Cart::remove_coupon();
        
        wp_send_json_success(array(
            'totals' => PTP_Camps_Cart::get_totals()
        ));
    }
    
    /**
     * Create Stripe payment intent and pending bookings
     */
    public function create_payment() {
        check_ajax_referer('ptp_camps_nonce', 'nonce');
        
        $cart = PTP_Camps_Cart::get();
        $totals = PTP_Camps_Cart::get_totals();
        
        if (empty($cart)) {
            wp_send_json_error('Cart is empty');
        }
        
        // Validate required fields
        $parent_name = sanitize_text_field($_POST['parent_name'] ?? '');
        $parent_email = sanitize_email($_POST['parent_email'] ?? '');
        $parent_phone = sanitize_text_field($_POST['parent_phone'] ?? '');
        
        if (empty($parent_name) || empty($parent_email)) {
            wp_send_json_error('Name and email are required');
        }
        
        $campers = isset($_POST['camper']) ? $_POST['camper'] : array();
        
        // Re-validate spots are still available
        foreach ($cart as $item) {
            $camp = PTP_Camps_Manager::get($item['camp_id']);
            if (!$camp || $camp['sold_out']) {
                wp_send_json_error('Sorry, ' . ($camp ? $camp['title'] : 'A camp') . ' is now sold out. Please refresh and try again.');
            }
        }
        
        // Create pending bookings
        $booking_ids = array();
        $coupon = PTP_Camps_Cart::get_coupon();
        
        foreach ($cart as $key => $item) {
            $camper = isset($campers[$key]) ? $campers[$key] : array();
            
            $booking_id = PTP_Camps_Database::insert_booking(array(
                'camp_id' => $item['camp_id'],
                'customer_email' => $parent_email,
                'customer_name' => $parent_name,
                'customer_phone' => $parent_phone,
                'camper_name' => sanitize_text_field($camper['name'] ?? ''),
                'camper_age' => intval($camper['age'] ?? 0),
                'camper_shirt' => sanitize_text_field($camper['shirt'] ?? ''),
                'emergency_contact' => sanitize_text_field($camper['emergency_name'] ?? ''),
                'emergency_phone' => sanitize_text_field($camper['emergency_phone'] ?? ''),
                'medical_notes' => sanitize_textarea_field($camper['medical'] ?? ''),
                'amount_paid' => $totals['total'] / $totals['count'],
                'discount_applied' => ($totals['early_bird_discount'] + $totals['multi_week_discount'] + $totals['coupon_discount']) / $totals['count'],
                'coupon_code' => $coupon ? $coupon['code'] : null,
                'status' => 'pending'
            ));
            
            $booking_ids[] = $booking_id;
        }
        
        // Create Stripe payment intent
        $metadata = array(
            'booking_ids' => implode(',', $booking_ids),
            'customer_email' => $parent_email,
            'customer_name' => $parent_name
        );
        
        if ($coupon) {
            $metadata['coupon_id'] = $coupon['id'];
            $metadata['coupon_code'] = $coupon['code'];
        }
        
        $intent = PTP_Camps_Stripe::create_payment_intent($totals['total'], $metadata);
        
        if (isset($intent['error'])) {
            // Clean up pending bookings
            foreach ($booking_ids as $id) {
                PTP_Camps_Database::update_booking($id, array('status' => 'failed'));
            }
            wp_send_json_error($intent['error']['message'] ?? 'Payment error');
        }
        
        wp_send_json_success(array(
            'clientSecret' => $intent['client_secret'],
            'booking_ids' => $booking_ids
        ));
    }
    
    /**
     * Confirm booking after successful payment
     */
    public function confirm_booking() {
        check_ajax_referer('ptp_camps_nonce', 'nonce');
        
        $payment_intent_id = sanitize_text_field($_POST['payment_intent'] ?? '');
        
        if (empty($payment_intent_id)) {
            wp_send_json_error('Missing payment ID');
        }
        
        $intent = PTP_Camps_Stripe::retrieve_payment_intent($payment_intent_id);
        
        if (!$intent || $intent['status'] !== 'succeeded') {
            wp_send_json_error('Payment not confirmed');
        }
        
        $booking_ids = explode(',', $intent['metadata']['booking_ids'] ?? '');
        $coupon_id = isset($intent['metadata']['coupon_id']) ? intval($intent['metadata']['coupon_id']) : null;
        
        foreach ($booking_ids as $id) {
            $booking = PTP_Camps_Database::get_booking($id);
            
            // Skip if already confirmed (idempotency)
            if ($booking && $booking->status === 'confirmed') {
                continue;
            }
            
            PTP_Camps_Database::update_booking($id, array(
                'status' => 'confirmed',
                'stripe_payment_id' => $payment_intent_id
            ));
        }
        
        // Increment coupon usage
        if ($coupon_id) {
            PTP_Camps_Coupons::increment_usage($coupon_id);
        }
        
        // Send confirmation email
        PTP_Camps_Emails::send_confirmation($intent['metadata']['customer_email'], $booking_ids);
        
        // Clear cart
        PTP_Camps_Cart::clear();
        
        wp_send_json_success(array(
            'message' => 'Booking confirmed!',
            'redirect' => home_url('/camp-checkout/?success=1')
        ));
    }
    
    /**
     * Join waitlist
     */
    public function join_waitlist() {
        check_ajax_referer('ptp_camps_nonce', 'nonce');
        
        $camp_id = intval($_POST['camp_id'] ?? 0);
        $email = sanitize_email($_POST['email'] ?? '');
        $name = sanitize_text_field($_POST['name'] ?? '');
        $phone = sanitize_text_field($_POST['phone'] ?? '');
        
        if (!$camp_id || !$email) {
            wp_send_json_error(array('message' => 'Camp and email are required'));
        }
        
        $camp = PTP_Camps_Manager::get($camp_id);
        if (!$camp) {
            wp_send_json_error(array('message' => 'Camp not found'));
        }
        
        // Only allow waitlist if actually sold out
        if (!$camp['sold_out']) {
            wp_send_json_error(array('message' => 'This camp still has spots available'));
        }
        
        $result = PTP_Camps_Database::add_to_waitlist($camp_id, $email, $name, $phone);
        
        if ($result['success']) {
            wp_send_json_success(array('message' => "You're on the waitlist! We'll email you if a spot opens."));
        } else {
            wp_send_json_error(array('message' => $result['message']));
        }
    }
}

new PTP_Camps_Ajax();
