<?php
if (!defined('ABSPATH')) exit;

class PTP_Camps_Stripe {
    private static $secret_key;
    
    public static function init() {
        self::$secret_key = get_option('ptp_camps_stripe_sk', '');
    }
    
    public static function create_payment_intent($amount, $metadata = array()) {
        self::init();
        
        $response = wp_remote_post('https://api.stripe.com/v1/payment_intents', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . self::$secret_key,
                'Content-Type' => 'application/x-www-form-urlencoded'
            ),
            'body' => array(
                'amount' => $amount * 100,
                'currency' => 'usd',
                'metadata' => $metadata,
                'automatic_payment_methods' => array('enabled' => 'true')
            )
        ));
        
        if (is_wp_error($response)) {
            return array('error' => $response->get_error_message());
        }
        
        return json_decode(wp_remote_retrieve_body($response), true);
    }
    
    public static function retrieve_payment_intent($id) {
        self::init();
        
        $response = wp_remote_get('https://api.stripe.com/v1/payment_intents/' . $id, array(
            'headers' => array('Authorization' => 'Bearer ' . self::$secret_key)
        ));
        
        if (is_wp_error($response)) {
            return null;
        }
        
        return json_decode(wp_remote_retrieve_body($response), true);
    }
}
