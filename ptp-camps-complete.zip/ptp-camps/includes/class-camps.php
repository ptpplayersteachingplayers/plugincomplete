<?php
if (!defined('ABSPATH')) exit;

class PTP_Camps_Manager {
    public static function get_all($args = array()) {
        $defaults = array(
            'post_type' => 'ptp_camp',
            'posts_per_page' => -1,
            'orderby' => 'meta_value',
            'meta_key' => '_camp_start_date',
            'order' => 'ASC'
        );
        $posts = get_posts(wp_parse_args($args, $defaults));
        return array_map(array(__CLASS__, 'format_camp'), $posts);
    }
    
    public static function get($camp_id) {
        $post = get_post($camp_id);
        return $post ? self::format_camp($post) : null;
    }
    
    public static function format_camp($post) {
        $capacity = (int) get_post_meta($post->ID, '_camp_capacity', true) ?: 40;
        $booked = PTP_Camps_Database::count_bookings($post->ID);
        $price = (float) get_post_meta($post->ID, '_camp_price', true) ?: 399;
        
        return array(
            'id' => $post->ID,
            'title' => $post->post_title,
            'slug' => $post->post_name,
            'description' => $post->post_content,
            'price' => $price,
            'early_bird_price' => ptp_camps_is_early_bird() ? $price - 50 : $price,
            'date' => get_post_meta($post->ID, '_camp_date', true),
            'start_date' => get_post_meta($post->ID, '_camp_start_date', true),
            'end_date' => get_post_meta($post->ID, '_camp_end_date', true),
            'time' => get_post_meta($post->ID, '_camp_time', true) ?: '9:00 AM - 3:00 PM',
            'location' => get_post_meta($post->ID, '_camp_location', true),
            'address' => get_post_meta($post->ID, '_camp_address', true),
            'ages' => get_post_meta($post->ID, '_camp_ages', true) ?: '6-14',
            'capacity' => $capacity,
            'spots_left' => max(0, $capacity - $booked),
            'sold_out' => $booked >= $capacity,
            'image' => get_the_post_thumbnail_url($post->ID, 'large'),
            'video_url' => get_post_meta($post->ID, '_camp_video_url', true),
            'maps_embed' => get_post_meta($post->ID, '_camp_maps_embed', true)
        );
    }
    
    public static function get_available_weeks() {
        $camps = self::get_all();
        return array_filter($camps, function($c) { return !$c['sold_out']; });
    }
    
    public static function calculate_multi_week_discount($count, $base_price) {
        if ($count >= 3) return $base_price * $count * 0.20; // 20% off 3+
        if ($count >= 2) return $base_price * $count * 0.10; // 10% off 2
        return 0;
    }
}
