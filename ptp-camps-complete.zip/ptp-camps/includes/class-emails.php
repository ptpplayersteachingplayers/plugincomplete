<?php
if (!defined('ABSPATH')) exit;

class PTP_Camps_Emails {
    
    private static function get_header() {
        return '
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@600;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
        </head>
        <body style="margin: 0; padding: 0; background-color: #f5f5f5; font-family: Inter, -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, sans-serif;">
            <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f5f5f5; padding: 40px 20px;">
                <tr>
                    <td align="center">
                        <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width: 600px; background: #ffffff;">
                            <!-- Header -->
                            <tr>
                                <td style="background: #0A0A0A; padding: 32px 40px; text-align: center;">
                                    <h1 style="margin: 0; font-family: Oswald, Impact, Arial Black, sans-serif; font-size: 28px; font-weight: 700; color: #FCB900; letter-spacing: 2px; text-transform: uppercase;">PTP SOCCER CAMPS</h1>
                                    <p style="margin: 8px 0 0 0; font-size: 12px; color: #888; letter-spacing: 1px; text-transform: uppercase;">Players Teaching Players</p>
                                </td>
                            </tr>';
    }
    
    private static function get_footer() {
        $phone = get_option('ptp_camps_phone', '(610) 888-1234');
        $email = get_option('ptp_camps_email', 'camps@ptpsoccercamps.com');
        
        return '
                            <!-- Footer -->
                            <tr>
                                <td style="background: #0A0A0A; padding: 32px 40px; text-align: center;">
                                    <p style="margin: 0 0 12px 0; font-size: 14px; color: #fff;">Questions? We\'re here to help.</p>
                                    <p style="margin: 0 0 8px 0;">
                                        <a href="tel:' . preg_replace('/[^0-9]/', '', $phone) . '" style="color: #FCB900; text-decoration: none; font-weight: 600;">' . esc_html($phone) . '</a>
                                    </p>
                                    <p style="margin: 0 0 24px 0;">
                                        <a href="mailto:' . esc_attr($email) . '" style="color: #FCB900; text-decoration: none;">' . esc_html($email) . '</a>
                                    </p>
                                    <p style="margin: 20px 0 0 0; font-size: 11px; color: #666;">
                                        © ' . date('Y') . ' PTP Soccer Camps. All rights reserved.<br>
                                        <a href="https://ptpsoccercamps.com" style="color: #666;">ptpsoccercamps.com</a>
                                    </p>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </body>
        </html>';
    }
    
    public static function send_confirmation($email, $booking_ids) {
        global $wpdb;
        
        if (!is_array($booking_ids)) {
            $booking_ids = array($booking_ids);
        }
        
        $bookings = $wpdb->get_results(
            "SELECT * FROM {$wpdb->prefix}ptp_camp_bookings WHERE id IN (" . implode(',', array_map('intval', $booking_ids)) . ")"
        );
        
        if (empty($bookings)) return false;
        
        $subject = 'You\'re Registered! PTP Soccer Camp Confirmation';
        
        $message = self::get_header();
        
        // Confirmation banner
        $message .= '
                            <tr>
                                <td style="padding: 40px; text-align: center; border-bottom: 4px solid #FCB900;">
                                    <div style="width: 64px; height: 64px; background: #00C853; border-radius: 50%; margin: 0 auto 16px; line-height: 64px; font-size: 32px; color: #fff;">✓</div>
                                    <h2 style="margin: 0; font-family: Oswald, Impact, sans-serif; font-size: 32px; color: #0A0A0A; text-transform: uppercase;">Registration Confirmed!</h2>
                                    <p style="margin: 12px 0 0 0; font-size: 16px; color: #666;">Get ready for an incredible camp experience</p>
                                </td>
                            </tr>';
        
        // Booking details
        $message .= '
                            <tr>
                                <td style="padding: 40px;">';
        
        foreach ($bookings as $booking) {
            $camp = get_post($booking->camp_id);
            if (!$camp) continue;
            
            $camp_date = get_post_meta($booking->camp_id, '_camp_date', true);
            $camp_time = get_post_meta($booking->camp_id, '_camp_time', true);
            $camp_location = get_post_meta($booking->camp_id, '_camp_location', true);
            $camp_address = get_post_meta($booking->camp_id, '_camp_address', true);
            
            $message .= '
                                    <div style="background: #f8f8f8; border-left: 4px solid #FCB900; padding: 24px; margin-bottom: 20px;">
                                        <h3 style="margin: 0 0 16px 0; font-family: Oswald, Impact, sans-serif; font-size: 20px; color: #0A0A0A; text-transform: uppercase;">' . esc_html($camp->post_title) . '</h3>
                                        <table role="presentation" cellspacing="0" cellpadding="0" style="font-size: 14px; color: #333;">
                                            <tr>
                                                <td style="padding: 6px 16px 6px 0; color: #666; vertical-align: top; width: 80px;">Camper:</td>
                                                <td style="padding: 6px 0; font-weight: 600;">' . esc_html($booking->camper_name) . ($booking->camper_age ? ' (Age ' . $booking->camper_age . ')' : '') . '</td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 6px 16px 6px 0; color: #666; vertical-align: top;">Dates:</td>
                                                <td style="padding: 6px 0; font-weight: 600;">' . esc_html($camp_date) . '</td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 6px 16px 6px 0; color: #666; vertical-align: top;">Time:</td>
                                                <td style="padding: 6px 0; font-weight: 600;">' . esc_html($camp_time) . '</td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 6px 16px 6px 0; color: #666; vertical-align: top;">Location:</td>
                                                <td style="padding: 6px 0; font-weight: 600;">' . esc_html($camp_location) . ($camp_address ? '<br><span style="font-weight: 400; color: #666; font-size: 13px;">' . esc_html($camp_address) . '</span>' : '') . '</td>
                                            </tr>
                                        </table>
                                    </div>';
        }
        
        // Payment summary
        $total = array_sum(array_column($bookings, 'amount_paid'));
        $message .= '
                                    <div style="background: #0A0A0A; padding: 20px 24px; margin-top: 24px;">
                                        <table role="presentation" width="100%" cellspacing="0" cellpadding="0">
                                            <tr>
                                                <td style="color: #fff; font-size: 14px;">Total Paid</td>
                                                <td style="text-align: right; color: #FCB900; font-size: 24px; font-weight: 700; font-family: Oswald, sans-serif;">$' . number_format($total, 2) . '</td>
                                            </tr>
                                        </table>
                                    </div>';
        
        $message .= '
                                </td>
                            </tr>';
        
        // What to bring section
        $message .= '
                            <tr>
                                <td style="padding: 0 40px 40px 40px;">
                                    <h3 style="margin: 0 0 20px 0; font-family: Oswald, Impact, sans-serif; font-size: 18px; color: #0A0A0A; text-transform: uppercase; border-bottom: 2px solid #FCB900; padding-bottom: 8px;">What to Bring</h3>
                                    <table role="presentation" width="100%" cellspacing="0" cellpadding="0">
                                        <tr>
                                            <td width="50%" style="padding: 8px 0; font-size: 14px; color: #333;">• Soccer ball</td>
                                            <td width="50%" style="padding: 8px 0; font-size: 14px; color: #333;">• Water bottle</td>
                                        </tr>
                                        <tr>
                                            <td style="padding: 8px 0; font-size: 14px; color: #333;">• Cleats</td>
                                            <td style="padding: 8px 0; font-size: 14px; color: #333;">• Shin guards</td>
                                        </tr>
                                        <tr>
                                            <td style="padding: 8px 0; font-size: 14px; color: #333;">• Sunscreen</td>
                                            <td style="padding: 8px 0; font-size: 14px; color: #333;">• Lunch & snacks</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>';
        
        // CTA Button
        $message .= '
                            <tr>
                                <td style="padding: 0 40px 40px 40px; text-align: center;">
                                    <a href="https://ptpsoccercamps.com/my-account/" style="display: inline-block; background: #FCB900; color: #0A0A0A; padding: 16px 40px; font-family: Oswald, Impact, sans-serif; font-size: 16px; font-weight: 700; text-transform: uppercase; text-decoration: none; letter-spacing: 1px;">View My Registrations</a>
                                </td>
                            </tr>';
        
        $message .= self::get_footer();
        
        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: PTP Soccer Camps <' . get_option('ptp_camps_email', 'camps@ptpsoccercamps.com') . '>',
            'Reply-To: ' . get_option('ptp_camps_email', 'camps@ptpsoccercamps.com')
        );
        
        $sent = wp_mail($email, $subject, $message, $headers);
        
        // Schedule reminders
        if ($sent) {
            foreach ($booking_ids as $bid) {
                self::schedule_reminders($bid);
            }
        }
        
        return $sent;
    }
    
    public static function send_reminder($booking_id, $days_before = 3) {
        global $wpdb;
        
        $booking = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_camp_bookings WHERE id = %d",
            $booking_id
        ));
        
        if (!$booking || $booking->status !== 'confirmed') return false;
        
        $camp = get_post($booking->camp_id);
        if (!$camp) return false;
        
        $camp_date = get_post_meta($booking->camp_id, '_camp_date', true);
        $camp_time = get_post_meta($booking->camp_id, '_camp_time', true);
        $camp_location = get_post_meta($booking->camp_id, '_camp_location', true);
        $camp_address = get_post_meta($booking->camp_id, '_camp_address', true);
        
        $subject = "{$days_before} Days Until Camp! - " . $camp->post_title;
        
        $message = self::get_header();
        
        $message .= '
                            <tr>
                                <td style="padding: 40px; text-align: center; border-bottom: 4px solid #FCB900;">
                                    <h2 style="margin: 0; font-family: Oswald, Impact, sans-serif; font-size: 32px; color: #0A0A0A; text-transform: uppercase;">' . $days_before . ' Days to Go!</h2>
                                    <p style="margin: 12px 0 0 0; font-size: 16px; color: #666;">Camp is almost here - here\'s what you need to know</p>
                                </td>
                            </tr>
                            <tr>
                                <td style="padding: 40px;">
                                    <div style="background: #f8f8f8; border-left: 4px solid #FCB900; padding: 24px;">
                                        <h3 style="margin: 0 0 16px 0; font-family: Oswald, Impact, sans-serif; font-size: 20px; color: #0A0A0A;">' . esc_html($camp->post_title) . '</h3>
                                        <p style="margin: 0 0 8px 0; font-size: 14px;"><strong>Camper:</strong> ' . esc_html($booking->camper_name) . '</p>
                                        <p style="margin: 0 0 8px 0; font-size: 14px;"><strong>Date:</strong> ' . esc_html($camp_date) . '</p>
                                        <p style="margin: 0 0 8px 0; font-size: 14px;"><strong>Time:</strong> ' . esc_html($camp_time) . '</p>
                                        <p style="margin: 0; font-size: 14px;"><strong>Location:</strong> ' . esc_html($camp_location) . '</p>
                                        ' . ($camp_address ? '<p style="margin: 4px 0 0 0; font-size: 13px; color: #666;">' . esc_html($camp_address) . '</p>' : '') . '
                                    </div>
                                </td>
                            </tr>';
        
        $message .= self::get_footer();
        
        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: PTP Soccer Camps <' . get_option('ptp_camps_email', 'camps@ptpsoccercamps.com') . '>'
        );
        
        return wp_mail($booking->customer_email, $subject, $message, $headers);
    }
    
    public static function send_waitlist_notification($email, $camp_id) {
        $camp = get_post($camp_id);
        if (!$camp) return false;
        
        $camp_date = get_post_meta($camp_id, '_camp_date', true);
        
        $subject = "Spot Available! - " . $camp->post_title;
        
        $message = self::get_header();
        
        $message .= '
                            <tr>
                                <td style="padding: 40px; text-align: center;">
                                    <h2 style="margin: 0 0 16px 0; font-family: Oswald, Impact, sans-serif; font-size: 28px; color: #0A0A0A; text-transform: uppercase;">A Spot Just Opened Up!</h2>
                                    <p style="margin: 0 0 24px 0; font-size: 16px; color: #666;">Good news - a spot is now available for:</p>
                                    <div style="background: #FCB900; padding: 24px; margin-bottom: 24px;">
                                        <h3 style="margin: 0; font-family: Oswald, Impact, sans-serif; font-size: 24px; color: #0A0A0A;">' . esc_html($camp->post_title) . '</h3>
                                        <p style="margin: 8px 0 0 0; font-size: 16px; color: #0A0A0A;">' . esc_html($camp_date) . '</p>
                                    </div>
                                    <p style="margin: 0 0 24px 0; font-size: 14px; color: #666;">Spots fill fast - register now to secure your place!</p>
                                    <a href="' . get_permalink($camp_id) . '" style="display: inline-block; background: #0A0A0A; color: #FCB900; padding: 16px 40px; font-family: Oswald, Impact, sans-serif; font-size: 16px; font-weight: 700; text-transform: uppercase; text-decoration: none;">Register Now</a>
                                </td>
                            </tr>';
        
        $message .= self::get_footer();
        
        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: PTP Soccer Camps <' . get_option('ptp_camps_email', 'camps@ptpsoccercamps.com') . '>'
        );
        
        return wp_mail($email, $subject, $message, $headers);
    }
    
    public static function schedule_reminders($booking_id) {
        global $wpdb;
        
        $booking = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_camp_bookings WHERE id = %d",
            $booking_id
        ));
        
        if (!$booking) return;
        
        $start_date = get_post_meta($booking->camp_id, '_camp_start_date', true);
        if (!$start_date) return;
        
        $camp_time = strtotime($start_date . ' 08:00:00');
        $now = time();
        
        // Schedule 3-day reminder (send at 9am)
        $three_days = strtotime('-3 days 09:00:00', $camp_time);
        if ($three_days > $now) {
            wp_schedule_single_event($three_days, 'ptp_send_camp_reminder', array($booking_id, 3));
        }
        
        // Schedule 1-day reminder
        $one_day = strtotime('-1 day 09:00:00', $camp_time);
        if ($one_day > $now) {
            wp_schedule_single_event($one_day, 'ptp_send_camp_reminder', array($booking_id, 1));
        }
    }
}

/**
     * Send refund notification
     */
    public static function send_refund_notification($email, $booking_ids, $refund_amount) {
        global $wpdb;
        
        if (!is_array($booking_ids)) {
            $booking_ids = array($booking_ids);
        }
        
        $bookings = $wpdb->get_results(
            "SELECT * FROM {$wpdb->prefix}ptp_camp_bookings WHERE id IN (" . implode(',', array_map('intval', $booking_ids)) . ")"
        );
        
        if (empty($bookings)) return false;
        
        $subject = 'Your PTP Soccer Camp Refund Has Been Processed';
        
        $message = self::get_header();
        
        $message .= '
                            <tr>
                                <td style="padding: 40px; text-align: center; border-bottom: 4px solid #FCB900;">
                                    <h2 style="margin: 0; font-family: Oswald, Impact, sans-serif; font-size: 28px; color: #0A0A0A; text-transform: uppercase;">Refund Processed</h2>
                                    <p style="margin: 12px 0 0 0; font-size: 16px; color: #666;">Your refund has been processed successfully</p>
                                </td>
                            </tr>
                            <tr>
                                <td style="padding: 40px;">';
        
        foreach ($bookings as $booking) {
            $camp = get_post($booking->camp_id);
            if (!$camp) continue;
            
            $message .= '
                                    <div style="background: #f8f8f8; border-left: 4px solid #FCB900; padding: 24px; margin-bottom: 20px;">
                                        <h3 style="margin: 0 0 8px 0; font-family: Oswald, Impact, sans-serif; font-size: 18px; color: #0A0A0A;">' . esc_html($camp->post_title) . '</h3>
                                        <p style="margin: 0; color: #666;">Camper: ' . esc_html($booking->camper_name) . '</p>
                                    </div>';
        }
        
        $message .= '
                                    <div style="background: #0A0A0A; padding: 20px 24px; margin-top: 24px;">
                                        <table role="presentation" width="100%" cellspacing="0" cellpadding="0">
                                            <tr>
                                                <td style="color: #fff; font-size: 14px;">Refund Amount</td>
                                                <td style="text-align: right; color: #FCB900; font-size: 24px; font-weight: 700; font-family: Oswald, sans-serif;">$' . number_format($refund_amount, 2) . '</td>
                                            </tr>
                                        </table>
                                    </div>
                                    <p style="margin: 24px 0 0 0; font-size: 14px; color: #666;">
                                        Please allow 5-10 business days for the refund to appear on your statement.
                                    </p>
                                </td>
                            </tr>';
        
        $message .= self::get_footer();
        
        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: PTP Soccer Camps <' . get_option('ptp_camps_email', 'camps@ptpsoccercamps.com') . '>'
        );
        
        return wp_mail($email, $subject, $message, $headers);
    }
    
    /**
     * Send waitlist joined confirmation
     */
    public static function send_waitlist_confirmation($email, $camp_id, $name = '') {
        $camp = get_post($camp_id);
        if (!$camp) return false;
        
        $camp_date = get_post_meta($camp_id, '_camp_date', true);
        
        $subject = "You're on the Waitlist - " . $camp->post_title;
        
        $message = self::get_header();
        
        $message .= '
                            <tr>
                                <td style="padding: 40px; text-align: center;">
                                    <h2 style="margin: 0 0 16px 0; font-family: Oswald, Impact, sans-serif; font-size: 28px; color: #0A0A0A; text-transform: uppercase;">You\'re on the Waitlist!</h2>
                                    <p style="margin: 0 0 24px 0; font-size: 16px; color: #666;">We\'ll notify you immediately if a spot opens up for:</p>
                                    <div style="background: #f8f8f8; border-left: 4px solid #FCB900; padding: 24px; text-align: left;">
                                        <h3 style="margin: 0 0 8px 0; font-family: Oswald, Impact, sans-serif; font-size: 20px; color: #0A0A0A;">' . esc_html($camp->post_title) . '</h3>
                                        <p style="margin: 0; font-size: 14px; color: #666;">' . esc_html($camp_date) . '</p>
                                    </div>
                                    <p style="margin: 24px 0 0 0; font-size: 14px; color: #666;">
                                        When a spot becomes available, you\'ll receive an email with a link to register. Spots are offered on a first-come, first-served basis to waitlist members who respond.
                                    </p>
                                </td>
                            </tr>';
        
        $message .= self::get_footer();
        
        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: PTP Soccer Camps <' . get_option('ptp_camps_email', 'camps@ptpsoccercamps.com') . '>'
        );
        
        return wp_mail($email, $subject, $message, $headers);
    }
}

// Hook for scheduled reminders
add_action('ptp_send_camp_reminder', function($booking_id, $days) {
    PTP_Camps_Emails::send_reminder($booking_id, $days);
}, 10, 2);
