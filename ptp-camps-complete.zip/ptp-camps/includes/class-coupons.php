<?php
if (!defined('ABSPATH')) exit;

/**
 * Coupon code management
 */
class PTP_Camps_Coupons {
    
    /**
     * Validate a coupon code
     * Returns coupon data array or false
     */
    public static function validate($code) {
        global $wpdb;
        
        $code = strtoupper(trim($code));
        if (empty($code)) return false;
        
        $coupon = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_camp_coupons WHERE code = %s AND status = 'active'",
            $code
        ), ARRAY_A);
        
        if (!$coupon) return false;
        
        // Check expiry
        if ($coupon['expires_at'] && strtotime($coupon['expires_at']) < time()) {
            return false;
        }
        
        // Check usage limit
        if ($coupon['usage_limit'] > 0 && $coupon['usage_count'] >= $coupon['usage_limit']) {
            return false;
        }
        
        // Check minimum spend
        $totals = PTP_Camps_Cart::get_totals();
        if ($coupon['minimum_spend'] > 0 && $totals['subtotal'] < $coupon['minimum_spend']) {
            return false;
        }
        
        return array(
            'id' => $coupon['id'],
            'code' => $coupon['code'],
            'type' => $coupon['discount_type'],
            'amount' => floatval($coupon['discount_amount']),
            'description' => $coupon['description']
        );
    }
    
    /**
     * Increment usage count after successful payment
     */
    public static function increment_usage($coupon_id) {
        global $wpdb;
        $wpdb->query($wpdb->prepare(
            "UPDATE {$wpdb->prefix}ptp_camp_coupons SET usage_count = usage_count + 1 WHERE id = %d",
            $coupon_id
        ));
    }
    
    /**
     * Get all coupons for admin
     */
    public static function get_all() {
        global $wpdb;
        return $wpdb->get_results(
            "SELECT * FROM {$wpdb->prefix}ptp_camp_coupons ORDER BY created_at DESC",
            ARRAY_A
        );
    }
    
    /**
     * Create a new coupon
     */
    public static function create($data) {
        global $wpdb;
        
        $code = strtoupper(sanitize_text_field($data['code']));
        
        // Check for duplicate
        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}ptp_camp_coupons WHERE code = %s",
            $code
        ));
        
        if ($exists) {
            return new WP_Error('duplicate', 'Coupon code already exists');
        }
        
        $result = $wpdb->insert("{$wpdb->prefix}ptp_camp_coupons", array(
            'code' => $code,
            'description' => sanitize_text_field($data['description'] ?? ''),
            'discount_type' => in_array($data['discount_type'], array('percent', 'fixed')) ? $data['discount_type'] : 'percent',
            'discount_amount' => floatval($data['discount_amount']),
            'minimum_spend' => floatval($data['minimum_spend'] ?? 0),
            'usage_limit' => intval($data['usage_limit'] ?? 0),
            'usage_count' => 0,
            'expires_at' => !empty($data['expires_at']) ? $data['expires_at'] : null,
            'status' => 'active',
            'created_at' => current_time('mysql')
        ));
        
        return $result ? $wpdb->insert_id : false;
    }
    
    /**
     * Update coupon
     */
    public static function update($id, $data) {
        global $wpdb;
        
        $update = array();
        
        if (isset($data['code'])) {
            $update['code'] = strtoupper(sanitize_text_field($data['code']));
        }
        if (isset($data['description'])) {
            $update['description'] = sanitize_text_field($data['description']);
        }
        if (isset($data['discount_type'])) {
            $update['discount_type'] = in_array($data['discount_type'], array('percent', 'fixed')) ? $data['discount_type'] : 'percent';
        }
        if (isset($data['discount_amount'])) {
            $update['discount_amount'] = floatval($data['discount_amount']);
        }
        if (isset($data['minimum_spend'])) {
            $update['minimum_spend'] = floatval($data['minimum_spend']);
        }
        if (isset($data['usage_limit'])) {
            $update['usage_limit'] = intval($data['usage_limit']);
        }
        if (isset($data['expires_at'])) {
            $update['expires_at'] = !empty($data['expires_at']) ? $data['expires_at'] : null;
        }
        if (isset($data['status'])) {
            $update['status'] = in_array($data['status'], array('active', 'inactive')) ? $data['status'] : 'active';
        }
        
        if (empty($update)) return false;
        
        return $wpdb->update("{$wpdb->prefix}ptp_camp_coupons", $update, array('id' => $id));
    }
    
    /**
     * Delete coupon
     */
    public static function delete($id) {
        global $wpdb;
        return $wpdb->delete("{$wpdb->prefix}ptp_camp_coupons", array('id' => $id));
    }
}
