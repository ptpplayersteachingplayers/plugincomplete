<?php
if (!defined('ABSPATH')) exit;

/**
 * Stripe webhook handler with proper signature verification
 */
class PTP_Camps_Webhooks {
    
    public function __construct() {
        add_action('rest_api_init', array($this, 'register_webhook'));
    }
    
    public function register_webhook() {
        register_rest_route('ptp-camps/v1', '/webhook', array(
            'methods' => 'POST',
            'callback' => array($this, 'handle_webhook'),
            'permission_callback' => '__return_true'
        ));
    }
    
    /**
     * Verify Stripe webhook signature
     */
    private function verify_signature($payload, $sig_header, $secret) {
        if (empty($secret)) {
            return true; // Skip verification if no secret configured (dev mode)
        }
        
        $elements = explode(',', $sig_header);
        $timestamp = null;
        $signatures = array();
        
        foreach ($elements as $element) {
            $parts = explode('=', $element, 2);
            if (count($parts) !== 2) continue;
            
            if ($parts[0] === 't') {
                $timestamp = $parts[1];
            } elseif ($parts[0] === 'v1') {
                $signatures[] = $parts[1];
            }
        }
        
        if (!$timestamp || empty($signatures)) {
            return false;
        }
        
        // Check timestamp (reject if older than 5 minutes)
        if (abs(time() - intval($timestamp)) > 300) {
            return false;
        }
        
        // Calculate expected signature
        $signed_payload = $timestamp . '.' . $payload;
        $expected = hash_hmac('sha256', $signed_payload, $secret);
        
        // Compare signatures
        foreach ($signatures as $sig) {
            if (hash_equals($expected, $sig)) {
                return true;
            }
        }
        
        return false;
    }
    
    public function handle_webhook($request) {
        $payload = $request->get_body();
        $sig_header = $request->get_header('Stripe-Signature');
        $secret = get_option('ptp_camps_webhook_secret', '');
        
        // Verify signature
        if (!$this->verify_signature($payload, $sig_header, $secret)) {
            error_log('PTP Camps: Webhook signature verification failed');
            return new WP_REST_Response(array('error' => 'Invalid signature'), 400);
        }
        
        $event = json_decode($payload, true);
        
        if (!$event || !isset($event['type'])) {
            return new WP_REST_Response(array('error' => 'Invalid payload'), 400);
        }
        
        // Log webhook for debugging
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('PTP Camps Webhook: ' . $event['type']);
        }
        
        switch ($event['type']) {
            case 'payment_intent.succeeded':
                $this->handle_payment_success($event['data']['object']);
                break;
                
            case 'payment_intent.payment_failed':
                $this->handle_payment_failed($event['data']['object']);
                break;
                
            case 'charge.refunded':
                $this->handle_refund($event['data']['object']);
                break;
                
            case 'charge.dispute.created':
                $this->handle_dispute($event['data']['object']);
                break;
        }
        
        return new WP_REST_Response(array('received' => true), 200);
    }
    
    /**
     * Handle successful payment
     */
    private function handle_payment_success($payment_intent) {
        $metadata = $payment_intent['metadata'] ?? array();
        
        if (!isset($metadata['booking_ids'])) {
            error_log('PTP Camps: Payment succeeded but no booking_ids in metadata');
            return;
        }
        
        $booking_ids = explode(',', $metadata['booking_ids']);
        $coupon_id = isset($metadata['coupon_id']) ? intval($metadata['coupon_id']) : null;
        
        foreach ($booking_ids as $id) {
            $booking = PTP_Camps_Database::get_booking($id);
            
            // Skip if already confirmed (idempotency)
            if ($booking && $booking->status === 'confirmed') {
                continue;
            }
            
            PTP_Camps_Database::update_booking($id, array(
                'status' => 'confirmed',
                'stripe_payment_id' => $payment_intent['id']
            ));
        }
        
        // Increment coupon usage
        if ($coupon_id) {
            PTP_Camps_Coupons::increment_usage($coupon_id);
        }
        
        // Send confirmation email (only if not already sent)
        if (isset($metadata['customer_email'])) {
            $first_booking = PTP_Camps_Database::get_booking($booking_ids[0]);
            if ($first_booking && $first_booking->status === 'confirmed') {
                PTP_Camps_Emails::send_confirmation($metadata['customer_email'], $booking_ids);
            }
        }
    }
    
    /**
     * Handle failed payment
     */
    private function handle_payment_failed($payment_intent) {
        $metadata = $payment_intent['metadata'] ?? array();
        
        if (!isset($metadata['booking_ids'])) return;
        
        $booking_ids = explode(',', $metadata['booking_ids']);
        
        foreach ($booking_ids as $id) {
            PTP_Camps_Database::update_booking($id, array(
                'status' => 'failed'
            ));
        }
    }
    
    /**
     * Handle refund from Stripe
     */
    private function handle_refund($charge) {
        $payment_intent_id = $charge['payment_intent'] ?? null;
        
        if (!$payment_intent_id) return;
        
        $bookings = PTP_Camps_Database::get_booking_by_payment($payment_intent_id);
        
        if (empty($bookings)) return;
        
        $refund_amount = ($charge['amount_refunded'] ?? 0) / 100;
        $is_full_refund = $charge['refunded'] ?? false;
        
        foreach ($bookings as $booking) {
            $per_booking_refund = $refund_amount / count($bookings);
            
            PTP_Camps_Database::update_booking($booking->id, array(
                'status' => $is_full_refund ? 'refunded' : 'partial_refund',
                'refund_amount' => $per_booking_refund,
                'refund_reason' => 'Refunded via Stripe',
                'refunded_at' => current_time('mysql')
            ));
            
            // Trigger waitlist notification if spot opened
            PTP_Camps_Database::check_waitlist_trigger($booking->camp_id);
        }
        
        // Send refund notification email
        if (!empty($bookings[0]->customer_email)) {
            PTP_Camps_Emails::send_refund_notification(
                $bookings[0]->customer_email,
                array_column($bookings, 'id'),
                $refund_amount
            );
        }
    }
    
    /**
     * Handle dispute/chargeback
     */
    private function handle_dispute($dispute) {
        $charge_id = $dispute['charge'] ?? null;
        
        if (!$charge_id) return;
        
        // Retrieve the charge to get payment intent
        $stripe_sk = get_option('ptp_camps_stripe_sk', '');
        $response = wp_remote_get('https://api.stripe.com/v1/charges/' . $charge_id, array(
            'headers' => array('Authorization' => 'Bearer ' . $stripe_sk)
        ));
        
        if (is_wp_error($response)) return;
        
        $charge = json_decode(wp_remote_retrieve_body($response), true);
        $payment_intent_id = $charge['payment_intent'] ?? null;
        
        if (!$payment_intent_id) return;
        
        $bookings = PTP_Camps_Database::get_booking_by_payment($payment_intent_id);
        
        foreach ($bookings as $booking) {
            PTP_Camps_Database::update_booking($booking->id, array(
                'status' => 'disputed'
            ));
        }
        
        // Notify admin
        $admin_email = get_option('admin_email');
        wp_mail(
            $admin_email,
            'PTP Camps: Payment Dispute Received',
            'A chargeback has been filed for booking IDs: ' . implode(', ', array_column($bookings, 'id')) . "\n\n" .
            'Please review in your Stripe dashboard.',
            array('Content-Type: text/plain; charset=UTF-8')
        );
    }
}

new PTP_Camps_Webhooks();
