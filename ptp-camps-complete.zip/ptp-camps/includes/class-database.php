<?php
if (!defined('ABSPATH')) exit;

class PTP_Camps_Database {
    
    public static function create_tables() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ptp_camp_bookings (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            camp_id bigint(20) NOT NULL,
            stripe_payment_id varchar(255) DEFAULT NULL,
            customer_email varchar(255) NOT NULL,
            customer_name varchar(255) NOT NULL,
            customer_phone varchar(50) DEFAULT NULL,
            camper_name varchar(255) NOT NULL,
            camper_age int(11) DEFAULT NULL,
            camper_shirt varchar(10) DEFAULT NULL,
            emergency_contact varchar(255) DEFAULT NULL,
            emergency_phone varchar(50) DEFAULT NULL,
            medical_notes text DEFAULT NULL,
            amount_paid decimal(10,2) NOT NULL,
            discount_applied decimal(10,2) DEFAULT 0,
            coupon_code varchar(50) DEFAULT NULL,
            status varchar(50) DEFAULT 'pending',
            refund_amount decimal(10,2) DEFAULT 0,
            refund_reason text DEFAULT NULL,
            refunded_at datetime DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY camp_id (camp_id),
            KEY status (status),
            KEY customer_email (customer_email),
            KEY stripe_payment_id (stripe_payment_id)
        ) $charset;
        
        CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ptp_camp_coupons (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            code varchar(50) NOT NULL,
            description varchar(255) DEFAULT NULL,
            discount_type enum('percent','fixed') DEFAULT 'percent',
            discount_amount decimal(10,2) NOT NULL,
            minimum_spend decimal(10,2) DEFAULT 0,
            usage_limit int(11) DEFAULT 0,
            usage_count int(11) DEFAULT 0,
            expires_at datetime DEFAULT NULL,
            status enum('active','inactive') DEFAULT 'active',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY code (code),
            KEY status (status)
        ) $charset;
        
        CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ptp_camp_waitlist (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            camp_id bigint(20) NOT NULL,
            email varchar(255) NOT NULL,
            name varchar(255) DEFAULT NULL,
            phone varchar(50) DEFAULT NULL,
            notified_at datetime DEFAULT NULL,
            status enum('waiting','notified','registered','expired') DEFAULT 'waiting',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY camp_id (camp_id),
            KEY status (status),
            UNIQUE KEY camp_email (camp_id, email)
        ) $charset;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        update_option('ptp_camps_db_version', PTP_CAMPS_VERSION);
    }
    
    /**
     * Get bookings for a camp
     */
    public static function get_bookings($camp_id, $status = 'confirmed') {
        global $wpdb;
        
        if ($status === 'all') {
            return $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}ptp_camp_bookings WHERE camp_id = %d ORDER BY created_at DESC",
                $camp_id
            ));
        }
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_camp_bookings WHERE camp_id = %d AND status = %s ORDER BY created_at DESC",
            $camp_id, $status
        ));
    }
    
    /**
     * Count confirmed bookings for a camp
     */
    public static function count_bookings($camp_id) {
        global $wpdb;
        return (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}ptp_camp_bookings WHERE camp_id = %d AND status = 'confirmed'",
            $camp_id
        ));
    }
    
    /**
     * Insert a new booking
     */
    public static function insert_booking($data) {
        global $wpdb;
        $wpdb->insert("{$wpdb->prefix}ptp_camp_bookings", $data);
        return $wpdb->insert_id;
    }
    
    /**
     * Update a booking
     */
    public static function update_booking($id, $data) {
        global $wpdb;
        return $wpdb->update("{$wpdb->prefix}ptp_camp_bookings", $data, array('id' => $id));
    }
    
    /**
     * Get a single booking
     */
    public static function get_booking($id) {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_camp_bookings WHERE id = %d",
            $id
        ));
    }
    
    /**
     * Get booking by Stripe payment ID
     */
    public static function get_booking_by_payment($payment_id) {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_camp_bookings WHERE stripe_payment_id = %s",
            $payment_id
        ));
    }
    
    /**
     * Add to waitlist
     */
    public static function add_to_waitlist($camp_id, $email, $name = '', $phone = '') {
        global $wpdb;
        
        // Check if already on waitlist
        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}ptp_camp_waitlist WHERE camp_id = %d AND email = %s",
            $camp_id, $email
        ));
        
        if ($exists) {
            return array('success' => false, 'message' => 'Already on waitlist');
        }
        
        $result = $wpdb->insert("{$wpdb->prefix}ptp_camp_waitlist", array(
            'camp_id' => $camp_id,
            'email' => sanitize_email($email),
            'name' => sanitize_text_field($name),
            'phone' => sanitize_text_field($phone),
            'status' => 'waiting',
            'created_at' => current_time('mysql')
        ));
        
        return $result ? array('success' => true, 'id' => $wpdb->insert_id) : array('success' => false, 'message' => 'Database error');
    }
    
    /**
     * Get waitlist for a camp
     */
    public static function get_waitlist($camp_id, $status = 'waiting') {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_camp_waitlist WHERE camp_id = %d AND status = %s ORDER BY created_at ASC",
            $camp_id, $status
        ));
    }
    
    /**
     * Notify next person on waitlist when spot opens
     */
    public static function notify_waitlist($camp_id) {
        global $wpdb;
        
        // Get next person waiting
        $person = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_camp_waitlist WHERE camp_id = %d AND status = 'waiting' ORDER BY created_at ASC LIMIT 1",
            $camp_id
        ));
        
        if (!$person) return false;
        
        // Send notification email
        $sent = PTP_Camps_Emails::send_waitlist_notification($person->email, $camp_id);
        
        if ($sent) {
            $wpdb->update(
                "{$wpdb->prefix}ptp_camp_waitlist",
                array(
                    'status' => 'notified',
                    'notified_at' => current_time('mysql')
                ),
                array('id' => $person->id)
            );
            return true;
        }
        
        return false;
    }
    
    /**
     * Check and trigger waitlist when booking cancelled/refunded
     */
    public static function check_waitlist_trigger($camp_id) {
        $camp = PTP_Camps_Manager::get($camp_id);
        if ($camp && $camp['spots_left'] > 0) {
            self::notify_waitlist($camp_id);
        }
    }
}
