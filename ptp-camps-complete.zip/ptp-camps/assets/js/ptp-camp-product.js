/**
 * PTP Camp Product Page JavaScript
 * Handles all interactions on summer camp product pages
 * 
 * @version 2.0.0
 * @package PTP_Camps
 */

(function() {
    'use strict';
    
    document.addEventListener('DOMContentLoaded', function() {
        var wrapper = document.getElementById('ptp-camp-wrapper');
        if (!wrapper) return;
        
        // Configuration
        var productId = parseInt(wrapper.dataset.productId) || 0;
        var basePrice = parseFloat(wrapper.dataset.basePrice) || 399;
        var checkoutUrl = wrapper.dataset.checkoutUrl || '/ptp-checkout/';
        var ajaxUrl = typeof ptp_camps_vars !== 'undefined' ? ptp_camps_vars.ajax_url : '/wp-admin/admin-ajax.php';
        var nonce = typeof ptp_camps_vars !== 'undefined' ? ptp_camps_vars.nonce : '';
        
        // State
        var selectedWeeks = [productId];
        var addWorldCupJersey = false;
        var currentlyPlaying = null;
        
        // ================================================
        // HERO VIDEO SOUND TOGGLE
        // ================================================
        var heroVideo = document.getElementById('heroVideo');
        var heroSoundToggle = document.getElementById('heroSoundToggle');
        
        if (heroVideo && heroSoundToggle) {
            heroVideo.muted = true;
            heroVideo.play().catch(function() {});
            
            heroSoundToggle.addEventListener('click', function(e) {
                e.preventDefault();
                heroVideo.muted = !heroVideo.muted;
                this.classList.toggle('unmuted', !heroVideo.muted);
            });
        }
        
        // ================================================
        // VIDEO REELS
        // ================================================
        document.querySelectorAll('.ptp-reel-play').forEach(function(btn) {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                var videoId = this.dataset.videoId;
                var video = document.getElementById(videoId);
                var reel = this.closest('.ptp-reel');
                
                if (!video || !reel) return;
                
                if (reel.classList.contains('playing')) {
                    video.pause();
                    reel.classList.remove('playing');
                    currentlyPlaying = null;
                } else {
                    // Pause any currently playing video
                    if (currentlyPlaying && currentlyPlaying !== video) {
                        currentlyPlaying.pause();
                        var currentReel = currentlyPlaying.closest('.ptp-reel-wrap');
                        if (currentReel && currentReel.parentElement) {
                            currentReel.parentElement.classList.remove('playing');
                        }
                    }
                    
                    video.play().catch(function() {});
                    reel.classList.add('playing');
                    currentlyPlaying = video;
                }
            });
        });
        
        // ================================================
        // FAQ ACCORDION
        // ================================================
        var faqList = document.getElementById('faqList');
        
        if (faqList) {
            faqList.addEventListener('click', function(e) {
                var btn = e.target.closest('.ptp-faq-q');
                if (!btn) return;
                
                var item = btn.closest('.ptp-faq-item');
                var answer = item.querySelector('.ptp-faq-a');
                var wasOpen = item.classList.contains('open');
                
                // Close all FAQ items
                faqList.querySelectorAll('.ptp-faq-item').forEach(function(i) {
                    i.classList.remove('open');
                    i.querySelector('.ptp-faq-q').setAttribute('aria-expanded', 'false');
                    i.querySelector('.ptp-faq-a').style.display = 'none';
                });
                
                // Open clicked item if it wasn't already open
                if (!wasOpen) {
                    item.classList.add('open');
                    btn.setAttribute('aria-expanded', 'true');
                    answer.style.display = 'block';
                }
            });
        }
        
        // ================================================
        // MULTI-WEEK SELECTION
        // ================================================
        var weekSelector = document.getElementById('weekSelector');
        
        if (weekSelector) {
            var checkboxes = weekSelector.querySelectorAll('input[name="selected_weeks[]"]');
            var weekCountEl = document.getElementById('weekCount');
            var totalPriceEl = document.getElementById('totalPrice');
            var stickyPriceEl = document.getElementById('stickyPrice');
            
            function updateSelection() {
                selectedWeeks = [];
                checkboxes.forEach(function(cb) {
                    if (cb.checked) {
                        selectedWeeks.push(parseInt(cb.value));
                    }
                });
                
                var count = selectedWeeks.length || 1;
                
                // Discount logic (unified with training platform checkout)
                // 2-Camp Pack: 10% discount (0.90)
                // 3+ Camp Pack: 20% discount (0.80)
                var discount = count >= 3 ? 0.80 : (count >= 2 ? 0.90 : 1);
                var total = Math.round(basePrice * count * discount);
                
                // Update UI
                if (weekCountEl) weekCountEl.textContent = count;
                if (totalPriceEl) totalPriceEl.textContent = total.toLocaleString();
                if (stickyPriceEl) stickyPriceEl.textContent = '$' + total.toLocaleString();
            }
            
            // Attach event listeners
            checkboxes.forEach(function(cb) {
                cb.addEventListener('change', updateSelection);
            });
            
            // Initial update
            updateSelection();
        }
        
        // ================================================
        // WORLD CUP JERSEY ADD-ON
        // ================================================
        var jerseyCheckbox = document.getElementById('worldCupJersey');
        
        if (jerseyCheckbox) {
            jerseyCheckbox.addEventListener('change', function() {
                addWorldCupJersey = this.checked;
            });
        }
        
        // ================================================
        // STICKY FOOTER
        // ================================================
        var hero = document.querySelector('.ptp-hero-two-col');
        var stickyFooter = document.getElementById('stickyCta');
        
        function updateSticky() {
            if (!stickyFooter || !hero) return;
            
            // Hide on desktop
            if (window.innerWidth >= 768) {
                stickyFooter.classList.remove('visible');
                return;
            }
            
            var heroBottom = hero.getBoundingClientRect().bottom;
            stickyFooter.classList.toggle('visible', heroBottom < 50);
        }
        
        window.addEventListener('scroll', updateSticky, { passive: true });
        window.addEventListener('resize', updateSticky);
        updateSticky();
        
        // ================================================
        // CHECKOUT FUNCTION
        // ================================================
        function goToCheckout(e) {
            if (e && e.preventDefault) e.preventDefault();
            
            var btn = e && e.target ? e.target.closest('button') : null;
            if (btn) {
                btn.disabled = true;
                btn.style.opacity = '0.7';
                var originalText = btn.textContent;
                btn.textContent = 'Processing...';
            }
            
            // If no weeks selected, use current product
            if (selectedWeeks.length === 0) {
                selectedWeeks = [productId];
            }
            
            // Build form data
            var formData = new FormData();
            formData.append('nonce', nonce);
            
            if (selectedWeeks.length > 1) {
                // Multiple weeks - use multi-week handler
                formData.append('action', 'ptp_camps_add_multiple_weeks');
                formData.append('add_world_cup_jersey', addWorldCupJersey ? 'true' : 'false');
                selectedWeeks.forEach(function(id) {
                    formData.append('product_ids[]', id);
                });
            } else {
                // Single camp
                formData.append('action', 'ptp_camps_add_to_cart');
                formData.append('product_id', selectedWeeks[0]);
                formData.append('quantity', 1);
            }
            
            // Send AJAX request
            fetch(ajaxUrl, {
                method: 'POST',
                body: formData,
                credentials: 'same-origin'
            })
            .then(function(response) {
                return response.json();
            })
            .then(function(data) {
                if (data && data.success && data.data && data.data.redirect) {
                    window.location.href = data.data.redirect;
                } else {
                    // Fallback - redirect to checkout anyway
                    window.location.href = checkoutUrl;
                }
            })
            .catch(function(err) {
                console.error('Checkout error:', err);
                window.location.href = checkoutUrl;
            });
        }
        
        // Scroll to pricing section
        function scrollToPricing(e) {
            if (e) e.preventDefault();
            
            var pricingSection = document.getElementById('pricing');
            if (pricingSection) {
                var headerHeight = 56 + 60; // Header + quick nav
                var targetPosition = pricingSection.getBoundingClientRect().top + window.pageYOffset - headerHeight;
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        }
        
        // Bind CTA buttons
        ['heroCta', 'finalCta', 'stickyBtn'].forEach(function(id) {
            var btn = document.getElementById(id);
            if (btn) {
                btn.addEventListener('click', scrollToPricing);
            }
        });
        
        // Checkout button
        var checkoutBtn = document.getElementById('checkoutBtn');
        if (checkoutBtn) {
            checkoutBtn.addEventListener('click', goToCheckout);
        }
        
        // ================================================
        // SMOOTH SCROLL FOR ANCHOR LINKS
        // ================================================
        document.querySelectorAll('a[href^="#"]').forEach(function(anchor) {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                var targetId = this.getAttribute('href');
                var target = document.querySelector(targetId);
                
                if (target) {
                    var headerHeight = 56 + 60;
                    var targetPosition = target.getBoundingClientRect().top + window.pageYOffset - headerHeight;
                    window.scrollTo({
                        top: targetPosition,
                        behavior: 'smooth'
                    });
                }
            });
        });
        
        // ================================================
        // EARLY BIRD COUNTDOWN TIMER
        // ================================================
        var timerEl = document.getElementById('earlyBirdTimer');
        
        if (timerEl && typeof ptp_camps_vars !== 'undefined' && ptp_camps_vars.early_bird_deadline) {
            var deadline = new Date(ptp_camps_vars.early_bird_deadline).getTime();
            
            function updateTimer() {
                var now = new Date().getTime();
                var distance = deadline - now;
                
                if (distance < 0) {
                    timerEl.textContent = 'Ended';
                    return;
                }
                
                var days = Math.floor(distance / (1000 * 60 * 60 * 24));
                var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                
                if (days > 0) {
                    timerEl.textContent = days + 'd ' + hours + 'h left';
                } else if (hours > 0) {
                    timerEl.textContent = hours + 'h ' + minutes + 'm left';
                } else {
                    timerEl.textContent = minutes + 'm left';
                }
            }
            
            updateTimer();
            setInterval(updateTimer, 60000); // Update every minute
        }
    });
})();
